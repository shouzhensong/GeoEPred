# DeepSecE Effector Prediction — Functional Validation Dataset

**Effector candidate predictions (T1SE–T6SE) by the DeepSecE deep-learning model for three bacterial genomes, with orthogonal dry-lab functional validation data (GO enrichment, KEGG categories, InterPro/Pfam domain enrichment, cross-validation analyses).**

> 本仓库为 DeepSecE 模型在三个细菌全基因组（铜绿假单胞菌 PAO1、鼠伤寒沙门氏菌 LT2、嗜肺军团菌）上预测的分泌型效应蛋白候选集，以及用 GO 富集、KEGG 通路、InterPro/Pfam 结构域富集、GO×Pfam 交叉验证等干实验方法对这些候选进行独立验证的全部数据与代码。

---

## Genomes and candidate sets

| Strain | Accession | Effector candidates | Candidate definition |
|---|---|---|---|
| *Pseudomonas aeruginosa* PAO1 | NC_002516.2 | 664 (T1SE 12, T2SE 113, T3SE 343, T4SE 33, T6SE 163) | All DeepSecE effector predictions |
| *Salmonella enterica* Typhimurium LT2 | NC_003197.2 | 577 (T1SE 8, T2SE 112, T3SE 183, T4SE 147, T6SE 127) | All predictions **excluding** 38 experimentally confirmed T3SE (`Exp. = 1` in features) and non-effectors |
| *Legionella pneumophila* | NC_002942.5 | 224 (T1SE 3, T2SE 46, T3SE 14, T4SE 144, T6SE 17) | All predictions **excluding** 307 experimentally confirmed T4SE (`Exp. = 1`) and non-effectors |

## Validation experiments (dry-lab)

| Experiment | PAO1 | NC_003197.2 | NC_002942.5 |
|---|---|---|---|
| GO enrichment (BP/MF/CC) | ✅ 77 significant terms | ✅ 50 significant terms | ❌ genome GO coverage 19 % → not feasible |
| KEGG enrichment | — | ✅ 1 significant pathway (aa-tRNA biosynthesis) | ❌ sparse annotation |
| NCBI functional category | — | — | ✅ 1 significant category |
| Pfam domain enrichment | ✅ 5 significant domains | ✅ 16 significant domains | ✅ 2 significant domains |
| Effector signature domain scan | ✅ | ✅ | ✅ (Sel1: 39 T4SE-exclusive proteins) |
| GO × Pfam cross-validation | — | ✅ biofilm GO ↔ curli/GGDEF/EAL; secretion GO ↔ T3SS needle | — |

**Key conclusions**
1. DeepSecE predictions are not random: 127 significant GO terms and 22 significant Pfam domains across the three genomes all point to secretion/virulence/biofilm functions — zero housekeeping enrichment.
2. Same secretion types enrich the same Pfam domains across genomes (e.g. phage-tail/baseplate domains in T6SE of both PAO1 and Salmonella; Sel1 in T4SE of both Salmonella and Legionella).
3. Pfam domain enrichment works where GO fails (Legionella, 19 % GO coverage), making it the method of choice for under-annotated species.

## Repository structure

```
├── 01_predictions/          DeepSecE raw outputs (per-protein class probabilities)
│     PAO1_predictions_time.csv
│     NC_003197.2_nonExp_predictions.csv
│     NC_002942.5_nonExp_predictions.csv
├── 02_genome_features/      Genome annotation tables (locus tags, Exp. column, coordinates)
├── 03_gene_lists/           Candidate / background gene ID lists (analysis input format)
├── 04_GO_KEGG_enrichment/
│     PAO1/                  GO BP/MF/CC: all results, significant, significant with fold enrichment
│     NC_003197.2/           same layout
│     NC_002942.5/           GO (empty — see below), KEGG, NCBI functional categories, QuickGO GAF files
├── 05_InterPro_domains/
│     raw_tsv_PAO1/          InterProScan v5 web output (15-column TSV)
│     raw_tsv_NC_003197.2/
│     raw_tsv_NC_002942.5/
│     Pfam_enrichment/       Per-strain per-secretion-type Pfam hypergeometric enrichment (clusterProfiler)
│     InterPro_three_genomes_combined.csv   Master table (163 rows: strain × secretion type × domain)
│     annotation_counts_by_category.csv     Per-category annotation coverage
├── 06_fasta/                Candidate protein FASTA files submitted to InterProScan
├── 07_figures/              Publication-style figures (PDF/PNG/SVG/TIFF + Source_Data CSVs)
├── 08_scripts/              All R / Python analysis scripts (see below)
└── 09_docs/                 Workflow description and cross-validation summary
```

## How to reproduce

- **R version**: R 4.5.3. Packages: `clusterProfiler`, `ggplot2`, `dplyr`, `tidyr`, `patchwork` (figure scripts also use `ragg`; GO enrichment additionally uses `GO.db`, `GOSemSim`).
- Scripts are numbered/self-contained and read relative paths from the project root (`setwd()` at the top of each script).
- Pipeline order:
  1. `NC_003197.2_GO_enrichment.R`, `NC_002942.5_GO_enrichment.R` — GO/KEGG enrichment (clusterProfiler `enricher` with custom TERM2GENE, GO ancestor expansion, BH correction; thresholds p.adj < 0.05, q < 0.20).
  2. `PAO1_InterPro_domain_enrichment.R`, `NC_003197.2_InterPro_domain_enrichment.R`, `NC_002942.5_InterPro_domain_enrichment.R` — merge raw TSVs → Pfam table → `enricher` per secretion type (hypergeometric test, BH) + effector signature domain scan + GO×Pfam cross-validation.
  3. `compile_interpro_table.R` — master combined table; `count_annotation_by_category.R`, `count_PAO1_categories.R` — annotation coverage counts.
  4. `plot_*.R` / `plot_*.py` — the figures in `07_figures/`.

## Notes and caveats

- **Legionella GO failure**: only ~19 % of NC_002942.5 proteins have GO annotations (3/224 candidates), so GO enrichment has no statistical power. KEGG and NCBI categories are also sparse. The raw GAF files (`LEGPN_QuickGO.gaf`, downloaded from QuickGO, taxon 272624) document this. Pfam domain analysis is the viable alternative.
- **Enrichment universe**: the Pfam hypergeometric test uses all scanned proteins carrying ≥ 1 Pfam domain as background (PAO1: 237, Salmonella: 434, Legionella: 76) — standard clusterProfiler `enricher` behavior.
- **Raw InterProScan TSVs** are unmodified web-server output (InterProScan v5, run 2026-08-03); the 15th column (Reactome pathways) is large, hence the multi-MB file sizes.
- `plot_InterPro_multipanel_Nature.R` and `plot_GO_bubble_matrix.R` are provided for reproducibility; their rendered outputs were not archived, but the equivalent data is available in `InterPro_three_genomes_combined.csv` and the GO Source_Data CSVs.
- Prediction `PAO1_predictions_time.csv` embeds full protein sequences (raw model input/output); the Salmonella/Legionella files store per-class probabilities only.

## License

Data: CC BY 4.0. Code: MIT. Please cite the associated manuscript if you use this dataset.
