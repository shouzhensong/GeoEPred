from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "GO_three_panel_composite_python"
OUT.mkdir(exist_ok=True)

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def make_legend(transparent: bool = False):
    fig = plt.figure(figsize=(31 / 25.4, 19 / 25.4))
    ax = fig.add_axes([0.18, 0.35, 0.68, 0.18])
    cmap = LinearSegmentedColormap.from_list("fdr_blue", ["#E9EEF0", "#9BC8DD", "#4B95C3"])
    colorbar = fig.colorbar(
        mpl.cm.ScalarMappable(norm=Normalize(0, 30), cmap=cmap),
        cax=ax,
        orientation="horizontal",
    )
    colorbar.set_ticks([10, 20])
    colorbar.ax.tick_params(labelsize=7, length=0, pad=3)
    colorbar.outline.set_edgecolor("#5E7079")
    colorbar.outline.set_linewidth(0.7)
    fig.text(0.50, 0.78, r"$-\log_{10}$(FDR)", ha="center", va="center", fontsize=7.5)
    return fig


def make_vertical_legend():
    fig = plt.figure(figsize=(27 / 25.4, 40 / 25.4))
    ax = fig.add_axes([0.34, 0.14, 0.25, 0.64])
    cmap = LinearSegmentedColormap.from_list("fdr_blue", ["#E9EEF0", "#9BC8DD", "#4B95C3"])
    colorbar = fig.colorbar(
        mpl.cm.ScalarMappable(norm=Normalize(0, 30), cmap=cmap),
        cax=ax,
        orientation="vertical",
    )
    colorbar.set_ticks([10, 20])
    colorbar.ax.yaxis.set_ticks_position("right")
    colorbar.ax.tick_params(labelsize=7, length=0, pad=3)
    colorbar.outline.set_edgecolor("#5E7079")
    colorbar.outline.set_linewidth(0.7)
    # Build the subscript manually because Arial lacks Unicode subscript digits.
    fig.text(0.18, 0.89, "−log", ha="left", va="center", fontsize=7.5,
             fontfamily="Arial", fontweight="normal")
    fig.text(0.43, 0.865, "10", ha="left", va="center", fontsize=5.2,
             fontfamily="Arial", fontweight="normal")
    fig.text(0.55, 0.89, "(FDR)", ha="left", va="center", fontsize=7.5,
             fontfamily="Arial", fontweight="normal")
    for label in colorbar.ax.get_yticklabels():
        label.set_fontfamily("Arial")
        label.set_fontweight("normal")
    return fig


def main():
    stem = OUT / "FDR_colorbar_blue"
    fig = make_legend()
    fig.savefig(stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    fig = make_legend(transparent=True)
    fig.savefig(OUT / "FDR_colorbar_blue_transparent.png", dpi=300, transparent=True)
    plt.close(fig)

    vertical_stem = OUT / "FDR_colorbar_blue_vertical_Arial"
    fig = make_vertical_legend()
    fig.savefig(vertical_stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(vertical_stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(vertical_stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(vertical_stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(OUT / "FDR_colorbar_blue_vertical_Arial_transparent.png", dpi=300, transparent=True)
    plt.close(fig)
    print(f"Saved colorbar bundle to: {OUT}")


if __name__ == "__main__":
    main()
