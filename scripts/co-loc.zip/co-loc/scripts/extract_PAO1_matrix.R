setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(tidyr))

# Load PAO1 GO results
go_bp <- read.csv("GO_BP_significant_with_fold.csv", stringsAsFactors=FALSE)
go_mf <- read.csv("GO_MF_significant_with_fold.csv", stringsAsFactors=FALSE)
go_cc <- read.csv("GO_CC_significant_with_fold.csv", stringsAsFactors=FALSE)
go_bp$Ontology <- "BP"; go_mf$Ontology <- "MF"; go_cc$Ontology <- "CC"
go_all <- rbind(go_bp, go_mf, go_cc)

# PAO1 features: PA locus_tag -> NP protein_id
feat <- read.csv("PAO1的features.csv.csv", stringsAsFactors=FALSE)
pa_to_np <- setNames(feat$protein_id, feat$locus_tag)

# Extract secretion type from PAO1 InterPro TSV metadata
ipr_files <- list.files("INTERPRO/PAO", pattern="\\.tsv$", full.names=TRUE)
np_to_type <- c()
for(f in ipr_files) {
  first_col <- read.delim(f, header=FALSE, sep="\t", quote="", stringsAsFactors=FALSE)[,1]
  for(x in first_col) {
    np <- regmatches(x, regexpr("NP_[0-9]+\\.[0-9]+", x))
    st <- regmatches(x, regexpr("T[1-6]SE", x))
    if(length(np)>0 && length(st)>0) {
      np_to_type[np] <- st
    }
  }
}
np_to_type <- np_to_type[!duplicated(names(np_to_type))]
cat("NP -> Type mappings:", length(np_to_type), "\n")

# Build matrix
rows <- list()
for(i in seq_len(nrow(go_all))) {
  genes <- trimws(strsplit(go_all$geneID[i], "/")[[1]])
  # Clean PA locus tags (PA0032a -> PA0032)
  genes_clean <- unique(sub("([PA0-9]+).*", "\\1", genes))
  prots <- na.omit(sapply(genes_clean, function(pa) pa_to_np[[pa]]))
  types <- np_to_type[prots]; types <- types[!is.na(types)]
  if(length(types)==0) next
  for(st in names(table(types))) {
    cnt <- as.integer(table(types)[st])
    if(cnt > 0) {
      rows[[length(rows)+1]] <- data.frame(
        GO_ID=go_all$ID[i], GO_Desc=go_all$Description[i],
        Ontology=go_all$Ontology[i], SecType=st,
        GeneCount=cnt, FoldEnrich=go_all$FoldEnrichment[i],
        p.adjust=go_all$p.adjust[i], stringsAsFactors=FALSE)
    }
  }
}
mat <- do.call(rbind, rows)
cat("Matrix rows:", nrow(mat), "\n")

# Filter: terms with >=3 total genes, top 6 per ontology
term_cov <- mat %>% group_by(GO_ID) %>%
  summarise(n_types=n_distinct(SecType), total=sum(GeneCount), .groups="drop")
active <- term_cov %>% filter(total>=3) %>% pull(GO_ID)
top <- go_all %>% filter(ID %in% active) %>% group_by(Ontology) %>%
  slice_min(p.adjust, n=6) %>% pull(ID)
mat <- mat[mat$GO_ID %in% top, ]

cat("\n===== PAO1 X-axis (Secretion Types) =====\n")
for(st in sort(unique(mat$SecType))) {
  total <- sum(mat$GeneCount[mat$SecType==st])
  cat(sprintf("  %s: %d genes\n", st, total))
}

cat("\n===== PAO1 Y-axis (GO Terms) =====\n")
ts <- unique(mat[,c("GO_ID","GO_Desc","Ontology","p.adjust","FoldEnrich")])
ts <- ts[order(ts$Ontology, ts$p.adjust), ]
for(i in seq_len(nrow(ts))) {
  cat(sprintf("  [%s] %s | Fold=%.1f p=%.2e | %s\n",
      ts$Ontology[i], ts$GO_ID[i], ts$FoldEnrich[i], ts$p.adjust[i], ts$GO_Desc[i]))
}

cat("\n===== Matrix =====\n")
wide <- pivot_wider(mat[,c("GO_ID","SecType","GeneCount")],
                    names_from=SecType, values_from=GeneCount, values_fill=0)
wide <- wide[match(ts$GO_ID, wide$GO_ID), ]
print(as.data.frame(wide), row.names=FALSE)

cat("\nAxis labels: X='Type of secreted protein' | Y=(GO descriptions) | Facet=BP/MF/CC | Fill='Genes'\n")
