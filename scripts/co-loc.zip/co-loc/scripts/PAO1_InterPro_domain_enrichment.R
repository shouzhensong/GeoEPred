setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
})

output_dir <- "PAO1_InterPro_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

# 1. 合并所有 InterProScan TSV 文件 ==========================================
cat("=== PAO1 InterProScan Domain Analysis ===\n")
interpro_dir <- "INTERPRO/PAO"
tsv_files <- list.files(interpro_dir, pattern = "\\.tsv$", full.names = TRUE)

ipr_cols <- c("Protein", "MD5", "SeqLen", "Analysis", "SigAccession",
              "SigDesc", "Start", "Stop", "Score", "Status",
              "Date", "InterPro_ID", "InterPro_Desc", "GO", "Pathways")

all_ipr <- do.call(rbind, lapply(tsv_files, function(f) {
  read.delim(f, header = FALSE, sep = "\t", quote = "",
             stringsAsFactors = FALSE, col.names = ipr_cols, fill = TRUE)
}))
cat("Total hits:", nrow(all_ipr), "\n")

# 2. 提取蛋白 ID 和分泌类型 ================================================
# 文件名编码了分泌类型: T1SE, T2SE, T3SE, T4SE, T6SE
extract_np <- function(x) {
  m <- regexpr("NP_[0-9]+\\.[0-9]+", x)
  ifelse(m > 0, regmatches(x, m), NA_character_)
}
all_ipr$Protein_ID <- extract_np(all_ipr$Protein)

# 从文件名推断分泌类型
all_ipr$SourceFile <- basename(all_ipr$Protein)  # won't work, need different approach

# Parse secretion type from the Protein field metadata
# Format: NP_xxxxxx.x-0.95-T6SE(xxx) → T6SE
extract_type <- function(x) {
  m <- regmatches(x, regexpr("T[1-6]SE", x))
  ifelse(length(m) > 0, m, NA_character_)
}
all_ipr$SecType <- sapply(all_ipr$Protein, function(p) {
  m <- regmatches(p, regexpr("T[1-6]SE", p))
  if (length(m) > 0) m else NA_character_
})

cat("Unique proteins:", length(unique(all_ipr$Protein_ID[!is.na(all_ipr$Protein_ID)])), "\n")
cat("Secretion type distribution:\n")
type_counts <- table(all_ipr$SecType[!is.na(all_ipr$SecType) & !duplicated(paste(all_ipr$Protein_ID, all_ipr$SecType))])
print(type_counts)

# 3. Pfam 域分析 =============================================================
pfam <- all_ipr[all_ipr$Analysis == "Pfam" & !is.na(all_ipr$Protein_ID), ]
cat("\n=== Pfam Domain Analysis ===\n")
cat("Pfam hits:", nrow(pfam), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")

# 3a. 每个分泌类型的 Pfam 域使用
cat("\nPfam domains per secretion type:\n")
for (st in c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")) {
  pf_st <- pfam[pfam$SecType == st, ]
  n_prot <- length(unique(pf_st$Protein_ID))
  n_dom <- length(unique(pf_st$SigAccession))
  cat(sprintf("  %s: %d proteins, %d unique Pfam domains\n", st, n_prot, n_dom))
}

# 3b. 分泌物类型间共享和特有域
pfam_by_type <- split(pfam$SigAccession, pfam$SecType)
pfam_sets <- lapply(pfam_by_type, unique)

cat("\nPfam domain sharing:\n")
for (st in names(pfam_sets)) {
  shared_with <- sapply(setdiff(names(pfam_sets), st), function(other) {
    length(intersect(pfam_sets[[st]], pfam_sets[[other]]))
  })
  cat(sprintf("  %s: %d unique, shares %d with others\n",
              st, length(pfam_sets[[st]]), sum(shared_with)))
}

# 3c. 效应蛋白标志 Pfam 域扫描
cat("\n\n=== Effector Signature Pfam Domain Scan ===\n")
effector_pfams <- c(
  "PF08238" = "Sel1-like repeat (T4SE Legionella)",
  "PF05488" = "PAAR motif (T6SS spike)",
  "PF05591" = "T6SS sheath TssB/VipA",
  "PF05943" = "T6SS baseplate TssK",
  "PF05593" = "RHS repeat (T6SS effector)",
  "PF05592" = "T6SS VgrG protein",
  "PF07591" = "PA14 domain",
  "PF08897" = "T6SS effector DUF1820",
  "PF04717" = "Phage-baseplate injector OB (T6SS-like)",
  "PF03496" = "ADP-ribosyltransferase exoenzyme",
  "PF03545" = "Yersinia virulence YopE (T3SE GAP)",
  "PF00419" = "Fimbrial protein",
  "PF05954" = "Phage tail baseplate hub",
  "PF03466" = "LysR substrate binding domain",
  "PF17936" = "Bacterial Ig-like domain",
  "PF00561" = "alpha/beta hydrolase fold",
  "PF05506" = "Bacterial phospholipase C"
)

cat("\nDomain presence in PAO1 candidates by secretion type:\n")
cat(sprintf("%-12s %-45s %s\n", "Pfam", "Description", "Found In"))
cat(rep("-", 100), "\n")

for (pf_id in names(effector_pfams)) {
  present_in <- c()
  for (st in c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")) {
    pf_st <- pfam[pfam$SecType == st, ]
    if (pf_id %in% pf_st$SigAccession) {
      n <- sum(pf_st$SigAccession == pf_id)
      present_in <- c(present_in, paste0(st, "(", n, ")"))
    }
  }
  if (length(present_in) > 0) {
    cat(sprintf("%-12s %-45s %s\n", pf_id, effector_pfams[pf_id],
                paste(present_in, collapse = ", ")))
  }
}

# 4. 分泌物类型间 Pfam 域差异 ================================================
cat("\n\n=== Cross-Secretion-Type Domain Comparison ===\n")

# 构建蛋白-类型矩阵
prot_type <- unique(all_ipr[!is.na(all_ipr$Protein_ID) & !is.na(all_ipr$SecType),
                            c("Protein_ID", "SecType")])
prot_type <- prot_type[!duplicated(prot_type$Protein_ID), ]
cat("Proteins per type:\n")
print(table(prot_type$SecType))

# 5. 富集分析：每种分泌类型的 Pfam 域 (以所有扫描蛋白为背景) ================
cat("\n=== Pfam Enrichment by Secretion Type ===\n")

all_proteins <- unique(all_ipr$Protein_ID[!is.na(all_ipr$Protein_ID)])
pfam_term2gene <- unique(pfam[, c("SigAccession", "Protein_ID")])
colnames(pfam_term2gene) <- c("term", "gene")
pfam_term2name <- unique(pfam[, c("SigAccession", "SigDesc")])
colnames(pfam_term2name) <- c("term", "name")
pfam_term2name <- pfam_term2name[!duplicated(pfam_term2name$term), ]

for (st in c("T6SE", "T4SE", "T3SE", "T2SE", "T1SE")) {
  st_proteins <- prot_type$Protein_ID[prot_type$SecType == st]
  if (length(st_proteins) < 5) next

  cat(sprintf("\n--- %s (%d proteins) ---\n", st, length(st_proteins)))

  res <- tryCatch({
    clusterProfiler::enricher(
      gene          = st_proteins,
      universe      = all_proteins,
      TERM2GENE     = pfam_term2gene,
      TERM2NAME     = pfam_term2name,
      pAdjustMethod = "BH",
      pvalueCutoff  = 1, qvalueCutoff = 1,
      minGSSize = 2, maxGSSize = 500
    )
  }, error = function(e) NULL)

  if (!is.null(res)) {
    tab <- as.data.frame(res)
    tab <- tab[order(tab$p.adjust, tab$pvalue), ]
    sig <- tab[!is.na(tab$p.adjust) & tab$p.adjust < 0.05, ]

    if (nrow(sig) > 0) {
      cat(sprintf("  Significant domains (p.adj<0.05): %d\n", nrow(sig)))
      for (i in seq_len(min(10, nrow(sig)))) {
        cat(sprintf("    %-12s p=%.1e Fold=%s\n",
                    sig$ID[i], sig$p.adjust[i], sig$GeneRatio[i]))
      }
    } else {
      cat("  No significant domains at p.adj<0.05\n")
    }

    # Save all results
    tab$GeneRatio_num <- sapply(strsplit(tab$GeneRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$BgRatio_num <- sapply(strsplit(tab$BgRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$FoldEnrichment <- tab$GeneRatio_num / tab$BgRatio_num

    write.csv(tab, file.path(output_dir, paste0("Pfam_enrich_", st, ".csv")),
              row.names = FALSE)
  }
}

# 6. Top Pfam domains bubble plot ============================================
# 所有蛋白中 Pfam 域 Top30
pfam_counts <- sort(table(pfam$SigAccession), decreasing = TRUE)
top30 <- names(pfam_counts)[1:30]

# 每个域在各分泌类型中的分布
domain_matrix <- do.call(rbind, lapply(top30, function(pf) {
  data.frame(
    Pfam = pf,
    Desc = pfam_term2name$name[pfam_term2name$term == pf][1],
    T1SE = sum(pfam$SigAccession == pf & pfam$SecType == "T1SE"),
    T2SE = sum(pfam$SigAccession == pf & pfam$SecType == "T2SE"),
    T3SE = sum(pfam$SigAccession == pf & pfam$SecType == "T3SE"),
    T4SE = sum(pfam$SigAccession == pf & pfam$SecType == "T4SE"),
    T6SE = sum(pfam$SigAccession == pf & pfam$SecType == "T6SE"),
    stringsAsFactors = FALSE
  )
}))

domain_long <- domain_matrix %>%
  pivot_longer(cols = c(T1SE, T2SE, T3SE, T4SE, T6SE),
               names_to = "SecType", values_to = "Count") %>%
  mutate(SecType = factor(SecType, levels = c("T6SE", "T5SE", "T4SE", "T3SE", "T2SE", "T1SE")))

# 用短描述
domain_long$ShortDesc <- sapply(strwrap(domain_long$Desc, width = 40), paste, collapse = "\n")
domain_long$Pfam <- factor(domain_long$Pfam, levels = rev(top30))

p <- ggplot(domain_long, aes(SecType, Pfam, size = Count, fill = Count)) +
  geom_point(shape = 21, colour = "grey30", stroke = 0.3) +
  scale_size_continuous(range = c(0.5, 7), breaks = c(1, 5, 10, 20)) +
  scale_fill_viridis_c(option = "C", direction = 1) +
  labs(x = "Secretion type", y = NULL,
       title = "PAO1 Candidate Effector Pfam Domain Distribution") +
  theme_classic(base_size = 9) +
  theme(axis.text.x = element_text(angle = 0, size = 8, face = "bold"),
        axis.text.y = element_text(size = 7),
        plot.title = element_text(size = 11, face = "bold"),
        legend.position = "right")

ggsave(file.path(output_dir, "PAO1_Pfam_dotplot.pdf"), p, width = 9, height = 9, device = "pdf")
ggsave(file.path(output_dir, "PAO1_Pfam_dotplot.png"), p, width = 9, height = 9, dpi = 300)

# 7. Summary stats ===========================================================
cat("\n\n===== Final Summary =====\n")
cat("Total InterProScan hits:", nrow(all_ipr), "\n")
cat("Total unique proteins:", length(unique(all_ipr$Protein_ID[!is.na(all_ipr$Protein_ID)])), "\n")
cat("Proteins with Pfam:", length(unique(pfam$Protein_ID)), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")
cat("Unique InterPro domains:", length(unique(all_ipr$InterPro_ID[all_ipr$InterPro_ID != "" & !is.na(all_ipr$InterPro_ID)])), "\n")

# Proteins per secretion type
cat("\nProteins per secretion type:\n")
for (st in c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")) {
  p <- unique(all_ipr$Protein_ID[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  cat(sprintf("  %s: %d\n", st, length(p)))
}

cat("\nOutput directory:", output_dir, "\n")
cat("===== Done =====\n")
