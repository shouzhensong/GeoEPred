setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(ggplot2)
})

output_dir <- "NC_003197.2_InterPro_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

# 1. 合并所有 InterProScan TSV 文件 ==========================================
cat("=== NC_003197.2 (Salmonella) InterPro Domain Analysis ===\n")
tsv_dir <- "NC_003197.2_InterPro_results"
tsv_files <- list.files(tsv_dir, pattern = "\\.tsv$", full.names = TRUE)
cat("Files:", length(tsv_files), "\n")

ipr_cols <- c("Protein", "MD5", "SeqLen", "Analysis", "SigAccession",
              "SigDesc", "Start", "Stop", "Score", "Status",
              "Date", "InterPro_ID", "InterPro_Desc", "GO", "Pathways")

all_ipr <- do.call(rbind, lapply(tsv_files, function(f) {
  read.delim(f, header = FALSE, sep = "\t", quote = "",
             stringsAsFactors = FALSE, col.names = ipr_cols, fill = TRUE)
}))
cat("Total hits:", nrow(all_ipr), "\n")
cat("Unique proteins:", length(unique(all_ipr$Protein)), "\n")

# 2. 加载分泌类型映射 (从 nonExp predictions) ================================
pred <- read.csv("NC_003197.2_nonExp_predictions.csv", stringsAsFactors = FALSE)
cat("\nPrediction file:", nrow(pred), "rows\n")
cat("Classes:", paste(unique(pred$predicted_class), collapse=", "), "\n")

# Build protein_id -> type mapping
prot_type <- setNames(pred$predicted_class, pred$protein_id)
all_ipr$SecType <- prot_type[all_ipr$Protein]
n_mapped <- sum(!is.na(all_ipr$SecType))
cat("Rows with secretion type:", n_mapped, "/", nrow(all_ipr), "\n")

# Also load Exp. T3SE list for comparison
features <- read.csv("features_.csv", stringsAsFactors = FALSE)
exp_t3se <- features$protein_id[features$Exp. == 1]
cat("Experimentally confirmed T3SE:", length(exp_t3se), "\n")

# 3. Pfam 域分析 =============================================================
pfam <- all_ipr[all_ipr$Analysis == "Pfam", ]
cat("\n=== Pfam Domain Analysis ===\n")
cat("Pfam hits:", nrow(pfam), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")
cat("Proteins with Pfam:", length(unique(pfam$Protein)), "\n")

# 4. 分泌类型分布 ============================================================
cat("\nSecretion type distribution:\n")
for (st in c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")) {
  p <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  pp <- unique(pfam$Protein[pfam$SecType == st & !is.na(pfam$SecType)])
  cat(sprintf("  %s: %d proteins, %d with Pfam\n", st, length(p), length(pp)))
}

# 5. 候选 vs 背景：GO 富集显著蛋白的结构域特征 ===============================
# 从 GO_BP_significant_with_fold 中提取参与富集通路的基因
cat("\n=== Cross-Validation: GO vs Pfam Domain =====\n")
go_bp <- read.csv("NC_003197.2_results/GO_BP_significant_with_fold.csv",
                  stringsAsFactors = FALSE)

# 提取所有显著 GO 通路的基因
go_genes <- unique(unlist(strsplit(go_bp$geneID, "/")))
# Map locus_tag -> protein_id
locus_to_prot <- setNames(features$protein_id, features$locus_tag)
go_proteins <- unique(na.omit(sapply(go_genes, function(lt) locus_to_prot[[lt]])))
cat("Genes in significant GO BP terms:", length(go_genes), "\n")
cat("Mapped to NP_ IDs:", length(go_proteins), "\n")

# 这些 GO 显著基因 vs 非显著基因 的 Pfam 域差异
go_pfam <- pfam[pfam$Protein %in% go_proteins, ]
other_pfam <- pfam[!pfam$Protein %in% go_proteins &
                    pfam$Protein %in% all_ipr$Protein, ]
cat("GO-significant proteins with Pfam:", length(unique(go_pfam$Protein)), "\n")
cat("Non-GO-significant proteins with Pfam:", length(unique(other_pfam$Protein)), "\n")

# 6. 效应蛋白标志 Pfam 域扫描 ================================================
cat("\n=== Effector Signature Pfam Domain Scan ===\n")
effector_pfams <- c(
  "PF08238" = "Sel1 repeat (T4SE)",
  "PF05488" = "PAAR motif (T6SS spike)",
  "PF05591" = "T6SS sheath TssB/VipA",
  "PF05943" = "T6SS baseplate TssK",
  "PF05593" = "RHS repeat (T6SS effector)",
  "PF05592" = "T6SS VgrG",
  "PF04717" = "Phage-baseplate injector OB",
  "PF05954" = "Phage tail baseplate hub",
  "PF03496" = "ADP-ribosyltransferase exotoxin",
  "PF03545" = "YopE GAP domain (T3SE)",
  "PF00419" = "Fimbrial protein",
  "PF22178" = "Phage T4 gp5 trimerization",
  "PF05506" = "Bacterial phospholipase C",
  "PF13662" = "T4SS VirB4",
  "PF07591" = "PA14 domain",
  "PF00023" = "Ankyrin repeat",
  "PF01582" = "TIR domain",
  "PF00646" = "F-box",
  "PF00397" = "WW/Ub ligase domain",
  "PF04932" = "WXG100 T7SS effector"
)

cat(sprintf("\n%-12s %-38s %s\n", "Pfam", "Description", "Secretion Types"))
cat(rep("-", 90), "\n")
for (pf_id in names(effector_pfams)) {
  pf_st <- pfam[pfam$SigAccession == pf_id & !is.na(pfam$SecType), ]
  if (nrow(pf_st) > 0) {
    types <- sort(table(pf_st$SecType), decreasing = TRUE)
    type_str <- paste(names(types), "(", types, ")", sep = "", collapse = ", ")
    cat(sprintf("%-12s %-38s %s\n", pf_id, effector_pfams[pf_id], type_str))
  }
}

# 7. Pfam 富集分析：以所有扫描蛋白为背景，按分泌类型 ========================
cat("\n\n=== Pfam Enrichment by Secretion Type ===\n")
all_scan_prots <- unique(all_ipr$Protein)
pfam_t2g <- unique(pfam[, c("SigAccession", "Protein")])
colnames(pfam_t2g) <- c("term", "gene")
pfam_t2n <- unique(pfam[, c("SigAccession", "SigDesc")])
colnames(pfam_t2n) <- c("term", "name")
pfam_t2n <- pfam_t2n[!duplicated(pfam_t2n$term), ]

all_sig_results <- list()
for (st in c("T6SE", "T4SE", "T3SE", "T2SE", "T1SE")) {
  st_prots <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  if (length(st_prots) < 5) next
  cat(sprintf("\n--- %s (%d proteins) ---\n", st, length(st_prots)))

  res <- tryCatch({
    clusterProfiler::enricher(
      gene = st_prots, universe = all_scan_prots,
      TERM2GENE = pfam_t2g, TERM2NAME = pfam_t2n,
      pAdjustMethod = "BH", pvalueCutoff = 1, qvalueCutoff = 1,
      minGSSize = 2, maxGSSize = 500
    )
  }, error = function(e) NULL)

  if (!is.null(res)) {
    tab <- as.data.frame(res)
    tab <- tab[order(tab$p.adjust, tab$pvalue), ]
    sig <- tab[!is.na(tab$p.adjust) & tab$p.adjust < 0.05, ]
    if (nrow(sig) > 0) {
      cat(sprintf("  Significant (p.adj<0.05): %d\n", nrow(sig)))
      for (i in seq_len(min(8, nrow(sig)))) {
        cat(sprintf("    %-12s p=%.1e  genes=%s\n",
            sig$ID[i], sig$p.adjust[i], sig$GeneRatio[i]))
      }
    } else {
      cat("  No significant domains\n")
    }

    tab$GeneRatio_num <- sapply(strsplit(tab$GeneRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$BgRatio_num <- sapply(strsplit(tab$BgRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$FoldEnrichment <- tab$GeneRatio_num / tab$BgRatio_num
    tab$SecType <- st
    all_sig_results[[st]] <- tab

    write.csv(tab, file.path(output_dir, paste0("Pfam_enrich_", st, ".csv")),
              row.names = FALSE)
  }
}

# 8. GO vs Pfam 交叉验证 ======================================================
cat("\n===========================================\n")
cat("===== Cross-Validation =====\n")
cat("===========================================\n")

# Biofilm GO terms → what Pfam domains?
biofilm_terms <- go_bp[grepl("biofilm|adhesion|aggregation", go_bp$Description, ignore.case = TRUE), ]
if (nrow(biofilm_terms) > 0) {
  biofilm_genes <- unique(unlist(strsplit(biofilm_terms$geneID, "/")))
  biofilm_prots <- unique(na.omit(sapply(biofilm_genes, function(lt) locus_to_prot[[lt]])))
  biofilm_pfam <- pfam[pfam$Protein %in% biofilm_prots, ]
  cat(sprintf("\nBiofilm/adhesion GO: %d terms, %d genes → %d with Pfam\n",
              nrow(biofilm_terms), length(biofilm_genes),
              length(unique(biofilm_pfam$Protein))))

  # Top Pfam domains in biofilm genes
  bf_counts <- sort(table(biofilm_pfam$SigAccession), decreasing = TRUE)
  cat("Top Pfam domains in biofilm-associated genes:\n")
  for (i in seq_len(min(10, length(bf_counts)))) {
    desc <- pfam_t2n$name[pfam_t2n$term == names(bf_counts)[i]][1]
    cat(sprintf("  %-12s (%d) - %s\n", names(bf_counts)[i], bf_counts[i], desc))
  }
}

# Secretion GO terms → Pfam
secretion_terms <- go_bp[grepl("secretion|transport|export|localization", go_bp$Description, ignore.case = TRUE), ]
if (nrow(secretion_terms) > 0) {
  sec_genes <- unique(unlist(strsplit(secretion_terms$geneID, "/")))
  sec_prots <- unique(na.omit(sapply(sec_genes, function(lt) locus_to_prot[[lt]])))
  sec_pfam <- pfam[pfam$Protein %in% sec_prots, ]
  cat(sprintf("\nSecretion/transport GO: %d terms, %d genes → %d with Pfam\n",
              nrow(secretion_terms), length(sec_genes),
              length(unique(sec_pfam$Protein))))

  sec_counts <- sort(table(sec_pfam$SigAccession), decreasing = TRUE)
  cat("Top Pfam domains in secretion-associated genes:\n")
  for (i in seq_len(min(10, length(sec_counts)))) {
    desc <- pfam_t2n$name[pfam_t2n$term == names(sec_counts)[i]][1]
    cat(sprintf("  %-12s (%d) - %s\n", names(sec_counts)[i], sec_counts[i], desc))
  }
}

# 9. Top Pfam 域汇总表 =======================================================
cat("\n\n===== Top 30 Pfam Domains Overall =====\n")
pfam_all_counts <- sort(table(pfam$SigAccession), decreasing = TRUE)
for (i in seq_len(min(30, length(pfam_all_counts)))) {
  pf_id <- names(pfam_all_counts)[i]
  desc <- pfam_t2n$name[pfam_t2n$term == pf_id][1]
  # distribution across secretion types
  dist <- sapply(c("T1SE","T2SE","T3SE","T4SE","T6SE"), function(st) {
    sum(pfam$SigAccession == pf_id & pfam$SecType == st & !is.na(pfam$SecType))
  })
  cat(sprintf("%2d. %-12s (%3d) %-45s [%s]\n",
      i, pf_id, pfam_all_counts[i], desc,
      paste(sprintf("%s:%d", names(dist), dist), collapse=" ")))
}

# 10. Summary & Export =======================================================
cat("\n\n===== Final Summary =====\n")
cat("Total InterPro hits:", nrow(all_ipr), "\n")
cat("Total proteins:", length(unique(all_ipr$Protein)), "\n")
cat("Proteins with Pfam:", length(unique(pfam$Protein)), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")

# Proteins per type with Pfam
cat("\nProteins with Pfam domains per type:\n")
for (st in c("T1SE","T2SE","T3SE","T4SE","T6SE")) {
  p_all <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  p_pfam <- unique(pfam$Protein[pfam$SecType == st & !is.na(pfam$SecType)])
  cat(sprintf("  %s: %d/%d (%.0f%%) have Pfam\n",
      st, length(p_pfam), length(p_all),
      100*length(p_pfam)/max(1,length(p_all))))
}

cat("\nOutput:", output_dir, "\n===== Done =====\n")
