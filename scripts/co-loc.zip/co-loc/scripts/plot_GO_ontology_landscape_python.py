from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "GO_nature_multipanel" / "Source_Data_panel_b_ontology_summary.csv"
OUT = ROOT / "GO_ontology_landscape_python"
OUT.mkdir(exist_ok=True)

# Colors sampled/approximated from the user-provided swatches, in BP–MF–CC order.
COLORS = {"BP": "#438FBE", "MF": "#5BB6B1", "CC": "#8D7CAF"}
ORDER = ["BP", "MF", "CC"]

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "font.size": 7,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def load_data() -> pd.DataFrame:
    data = pd.read_csv(SOURCE)
    required = {"Ontology", "SignificantTerms", "EnrichedGenes"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    data = data.set_index("Ontology").loc[ORDER].reset_index()
    return data


def plot(data: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(89 / 25.4, 64 / 25.4))
    y = list(range(len(data)))
    bars = ax.barh(
        y,
        data["SignificantTerms"],
        height=0.56,
        color=[COLORS[o] for o in data["Ontology"]],
        edgecolor="none",
    )

    ax.set_yticks(y)
    # Explicitly normal weight as requested.
    ax.set_yticklabels(data["Ontology"], fontsize=7.5, fontweight="normal")
    ax.invert_yaxis()
    ax.set_xlim(0, 66)
    ax.set_xticks([0, 20, 40, 60])
    ax.set_xlabel("Significant GO terms", fontsize=7.5, labelpad=5)
    ax.tick_params(axis="x", labelsize=7, width=0.7, length=3)
    ax.tick_params(axis="y", width=0, length=0, pad=2)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color("#24323A")

    for bar, terms, genes in zip(bars, data["SignificantTerms"], data["EnrichedGenes"]):
        ax.text(
            bar.get_width() + 1.0,
            bar.get_y() + bar.get_height() / 2,
            f"{int(terms)} terms\n{int(genes)} genes",
            ha="left",
            va="center",
            fontsize=6.7,
            linespacing=1.05,
            color="#152832",
        )

    ax.set_title("Ontology landscape", loc="left", fontsize=8.5, fontweight="bold", pad=7)
    fig.subplots_adjust(left=0.13, right=0.98, top=0.86, bottom=0.22)
    return fig


def main() -> None:
    data = load_data()
    data.to_csv(OUT / "Source_Data_GO_ontology_landscape.csv", index=False, encoding="utf-8-sig")
    fig = plot(data)
    stem = OUT / "PAO1_GO_ontology_landscape_new_colors"
    fig.savefig(stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
