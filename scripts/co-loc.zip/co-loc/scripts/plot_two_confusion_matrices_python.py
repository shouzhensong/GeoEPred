from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "confusion_matrices_python"
OUT.mkdir(exist_ok=True)

LABELS = ["Non-Effector", "T1SE", "T2SE", "T3SE", "T4SE", "T6SE"]

SEQUENCE_SEMANTICS = np.array(
    [
        [110, 0, 15, 2, 21, 2],
        [0, 17, 0, 1, 2, 0],
        [0, 0, 9, 1, 0, 0],
        [1, 0, 0, 27, 2, 0],
        [0, 0, 0, 1, 29, 0],
        [0, 0, 0, 1, 1, 18],
    ],
    dtype=int,
)

GEOEPRED = np.array(
    [
        [135, 0, 10, 1, 4, 0],
        [0, 19, 0, 1, 0, 0],
        [0, 0, 9, 1, 0, 0],
        [1, 0, 0, 28, 1, 0],
        [0, 0, 0, 0, 30, 0],
        [0, 0, 0, 0, 0, 20],
    ],
    dtype=int,
)

mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.titleweight": "normal",
        "axes.labelweight": "normal",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def draw_matrix(ax, matrix, title, norm, cmap):
    image = ax.imshow(matrix, cmap=cmap, norm=norm, interpolation="nearest", aspect="equal")
    ax.set_title(title, fontsize=9, fontweight="normal", pad=7)
    ax.set_xticks(np.arange(len(LABELS)))
    ax.set_yticks(np.arange(len(LABELS)))
    ax.set_xticklabels(LABELS, rotation=45, ha="right", rotation_mode="anchor",
                       fontsize=5.8, fontweight="normal")
    ax.set_yticklabels(LABELS, rotation=0, ha="right", va="center",
                       fontsize=5.8, fontweight="normal")
    ax.set_xlabel("Predicted label", fontsize=6.5, fontweight="normal", labelpad=5)
    ax.set_ylabel("True label", fontsize=6.5, fontweight="normal", labelpad=4)
    ax.tick_params(axis="both", length=2.5, width=0.55, color="#4B5960", pad=2)

    for spine in ax.spines.values():
        spine.set_linewidth(0.65)
        spine.set_color("#4B5960")

    threshold = norm.vmax * 0.50
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            value = int(matrix[row, col])
            ax.text(
                col,
                row,
                str(value),
                ha="center",
                va="center",
                fontsize=5.8,
                fontfamily="Arial",
                fontweight="normal",
                color="white" if value > threshold else "#25343B",
            )
    return image


def main():
    vmax = float(max(SEQUENCE_SEMANTICS.max(), GEOEPRED.max()))
    norm = mpl.colors.Normalize(vmin=0, vmax=vmax)
    cmap = mpl.colormaps["Blues"]

    fig = plt.figure(figsize=(183 / 25.4, 86 / 25.4))
    grid = fig.add_gridspec(
        1,
        5,
        width_ratios=[1.0, 0.045, 0.20, 1.0, 0.045],
        wspace=0.08,
        left=0.075,
        right=0.945,
        top=0.88,
        bottom=0.22,
    )
    ax_a = fig.add_subplot(grid[0, 0])
    cax_a = fig.add_subplot(grid[0, 1])
    spacer = fig.add_subplot(grid[0, 2])
    spacer.axis("off")
    ax_b = fig.add_subplot(grid[0, 3])
    cax_b = fig.add_subplot(grid[0, 4])

    image_a = draw_matrix(ax_a, SEQUENCE_SEMANTICS, "Sequence Semantics", norm, cmap)
    image_b = draw_matrix(ax_b, GEOEPRED, "GeoEPred", norm, cmap)

    ticks = [0, 30, 60, 90, 120]
    for image, cax in [(image_a, cax_a), (image_b, cax_b)]:
        cb = fig.colorbar(image, cax=cax, orientation="vertical", ticks=ticks)
        cb.ax.tick_params(labelsize=5.8, width=0.5, length=2.5)
        cb.outline.set_linewidth(0.6)
        for label in cb.ax.get_yticklabels():
            label.set_fontfamily("Arial")
            label.set_fontweight("normal")

    fig.text(0.018, 0.94, "A", fontsize=9, fontfamily="Arial", fontweight="normal", va="top")
    fig.text(0.505, 0.94, "B", fontsize=9, fontfamily="Arial", fontweight="normal", va="top")

    pd.DataFrame(SEQUENCE_SEMANTICS, index=LABELS, columns=LABELS).to_csv(
        OUT / "Source_Data_Sequence_Semantics.csv", encoding="utf-8-sig"
    )
    pd.DataFrame(GEOEPRED, index=LABELS, columns=LABELS).to_csv(
        OUT / "Source_Data_GeoEPred.csv", encoding="utf-8-sig"
    )

    stem = OUT / "Sequence_Semantics_GeoEPred_confusion_matrices"
    fig.savefig(f"{stem}.png", dpi=300, facecolor="white")
    fig.savefig(f"{stem}.svg", facecolor="white")
    fig.savefig(f"{stem}.pdf", facecolor="white")
    fig.savefig(f"{stem}.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
