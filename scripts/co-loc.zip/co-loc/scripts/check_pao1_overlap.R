setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
ipr_cols <- c("Protein","MD5","SeqLen","Analysis","SigAccession",
              "SigDesc","Start","Stop","Score","Status",
              "Date","InterPro_ID","InterPro_Desc","GO","Pathways")
tsvP <- do.call(rbind, lapply(list.files("INTERPRO/PAO", "\\.tsv$", full.names = TRUE),
  function(f) read.delim(f, header = FALSE, sep = "\t", quote = "",
                         stringsAsFactors = FALSE, col.names = ipr_cols, fill = TRUE)))
extract_np <- function(x) {
  m <- regexpr("NP_[0-9]+\\.[0-9]+", x)
  ml <- attr(m, "match.length")
  v <- rep(NA_character_, length(x))
  ok <- !is.na(m) & m > 0
  v[ok] <- substring(x[ok], m[ok], m[ok] + ml[ok] - 1)
  v
}
tsvP$np <- extract_np(tsvP$Protein)
tsvP$SecType <- sapply(tsvP$Protein, function(x) {
  m <- regmatches(x, regexpr("T[1-6]SE", x)); if (length(m) > 0) m else NA_character_ })

per_class <- lapply(c("T1SE","T2SE","T3SE","T4SE","T6SE"), function(st) {
  unique(tsvP$np[tsvP$SecType == st & !is.na(tsvP$SecType)])
})
names(per_class) <- c("T1SE","T2SE","T3SE","T4SE","T6SE")
cat("unique NP per class:\n")
print(sapply(per_class, length))
cat("\nClass overlap matrix (rows/cols = classes):\n")
m <- sapply(per_class, function(a) sapply(per_class, function(b) length(intersect(a,b))))
print(m)
cat("\nTotal unique NP across all classes:", length(unique(unlist(per_class))), "\n")

# Which TSV NP ids are NOT in the prediction file?
predP <- read.csv("running_time_figure/PAO1_predictions_time.csv", stringsAsFactors = FALSE)
predP$np <- extract_np(predP$protein_id)
all_np <- unique(tsvP$np[!is.na(tsvP$np)])
miss <- setdiff(all_np, predP$np)
cat("\nTSV NP ids not in prediction file:", length(miss), "\n")
if (length(miss)) print(miss)
