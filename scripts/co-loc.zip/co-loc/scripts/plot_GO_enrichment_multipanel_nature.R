#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(patchwork)
  library(scales)
  library(svglite)
  library(ragg)
})

args <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args, value = TRUE)
script_dir <- if (length(script_arg)) {
  dirname(normalizePath(sub("^--file=", "", script_arg[1]), winslash = "/"))
} else {
  normalizePath(getwd(), winslash = "/")
}
setwd(script_dir)

out_dir <- file.path(script_dir, "GO_nature_multipanel")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

input_files <- c(
  BP = "GO_BP_significant_with_fold.csv",
  MF = "GO_MF_significant_with_fold.csv",
  CC = "GO_CC_significant_with_fold.csv"
)

read_go <- function(path, ontology) {
  dat <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  required <- c("ID", "Description", "FoldEnrichment", "Count", "p.adjust", "geneID")
  missing <- setdiff(required, names(dat))
  if (length(missing)) stop(path, " is missing: ", paste(missing, collapse = ", "))
  dat$Ontology <- ontology
  dat
}

go_all <- bind_rows(Map(read_go, input_files, names(input_files))) %>%
  mutate(
    FoldEnrichment = as.numeric(FoldEnrichment),
    Count = as.numeric(Count),
    p.adjust = as.numeric(p.adjust),
    NegLog10FDR = -log10(pmax(p.adjust, .Machine$double.xmin))
  )

ontology_levels <- c("BP", "MF", "CC")
ontology_names <- c(BP = "Biological process", MF = "Molecular function", CC = "Cellular component")
ontology_cols <- c(BP = "#356C7D", MF = "#806A93", CC = "#C98545")
neutral_dark <- "#26343C"
neutral_mid <- "#6F7B82"
neutral_light <- "#D9E0E3"

genes_by_ontology <- lapply(ontology_levels, function(ont) {
  x <- go_all$geneID[go_all$Ontology == ont]
  sort(unique(unlist(strsplit(x[!is.na(x) & nzchar(x)], "/", fixed = TRUE))))
})
names(genes_by_ontology) <- ontology_levels

ontology_summary <- bind_rows(lapply(ontology_levels, function(ont) {
  data.frame(
    Ontology = ont,
    SignificantTerms = sum(go_all$Ontology == ont),
    EnrichedGenes = length(genes_by_ontology[[ont]]),
    MedianFold = median(go_all$FoldEnrichment[go_all$Ontology == ont], na.rm = TRUE)
  )
})) %>%
  mutate(
    Ontology = factor(Ontology, levels = rev(ontology_levels)),
    Label = paste0(SignificantTerms, " terms\n", EnrichedGenes, " genes")
  )

all_genes <- sort(unique(unlist(genes_by_ontology)))
membership <- data.frame(
  Gene = all_genes,
  BP = all_genes %in% genes_by_ontology$BP,
  MF = all_genes %in% genes_by_ontology$MF,
  CC = all_genes %in% genes_by_ontology$CC
) %>%
  mutate(
    Combination = paste0(ifelse(BP, "B", ""), ifelse(MF, "M", ""), ifelse(CC, "C", ""))
  )

intersection_summary <- membership %>%
  count(Combination, name = "Genes") %>%
  filter(Combination != "") %>%
  arrange(desc(Genes), Combination) %>%
  mutate(
    Combination = factor(Combination, levels = Combination),
    X = seq_len(n())
  )

matrix_data <- tidyr::expand_grid(
  Combination = levels(intersection_summary$Combination),
  Ontology = ontology_levels
) %>%
  mutate(
    Combination = factor(Combination, levels = levels(intersection_summary$Combination)),
    X = as.numeric(Combination),
    Active = mapply(
      function(code, ont) substr(ont, 1, 1) %in% strsplit(as.character(code), "", fixed = TRUE)[[1]],
      as.character(Combination), Ontology
    ),
    Ontology = factor(Ontology, levels = rev(ontology_levels))
  )

matrix_segments <- matrix_data %>%
  filter(Active) %>%
  group_by(Combination, X) %>%
  summarise(
    ymin = min(as.numeric(Ontology)), ymax = max(as.numeric(Ontology)),
    .groups = "drop"
  ) %>%
  filter(ymin != ymax)

representative_ids <- c(
  "GO:0009306", "GO:0071806", "GO:0030254", "GO:0043952",
  "GO:0015628", "GO:0033103", "GO:0044419", "GO:0042710",
  "GO:0016788", "GO:0016298", "GO:0008237", "GO:0004620", "GO:1990404",
  "GO:0005576", "GO:0009289", "GO:0033104", "GO:0042597", "GO:0030257"
)

plot_data <- go_all %>%
  filter(ID %in% representative_ids) %>%
  mutate(
    Ontology = factor(Ontology, levels = ontology_levels),
    TermLabel = vapply(
      Description,
      function(x) paste(strwrap(x, width = 34), collapse = "\n"),
      character(1)
    )
  ) %>%
  arrange(Ontology, FoldEnrichment, p.adjust) %>%
  mutate(
    TermKey = paste(Ontology, ID, sep = "__"),
    TermKey = factor(TermKey, levels = unique(TermKey))
  )

term_labels <- setNames(plot_data$TermLabel, as.character(plot_data$TermKey))
facet_labels <- c(BP = "BP", MF = "MF", CC = "CC")

theme_pub <- function(base_size = 6.6) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.32, colour = neutral_dark),
      axis.ticks = element_line(linewidth = 0.3, colour = neutral_dark),
      axis.text = element_text(size = base_size - 0.3, colour = neutral_dark),
      axis.title = element_text(size = base_size, colour = neutral_dark),
      plot.title = element_text(size = 7.2, face = "bold", colour = neutral_dark, margin = margin(b = 3)),
      plot.tag = element_text(size = 8, face = "bold", colour = "black"),
      plot.tag.position = c(0, 1),
      legend.title = element_text(size = 6.1, face = "bold"),
      legend.text = element_text(size = 5.8),
      legend.background = element_blank(),
      panel.grid = element_blank(),
      plot.margin = margin(4, 4, 4, 4)
    )
}

# a | Hero panel: non-redundant terms retain the biological narrative.
p_terms <- ggplot(plot_data, aes(FoldEnrichment, TermKey)) +
  geom_vline(xintercept = 1, linetype = "22", linewidth = 0.3, colour = "#B9C0C4") +
  geom_segment(
    aes(x = 1, xend = FoldEnrichment, yend = TermKey),
    colour = neutral_light, linewidth = 0.42, lineend = "round"
  ) +
  geom_point(
    aes(size = Count, fill = NegLog10FDR),
    shape = 21, colour = neutral_dark, stroke = 0.25
  ) +
  facet_grid(
    Ontology ~ ., scales = "free_y", space = "free_y", switch = "y",
    labeller = labeller(Ontology = facet_labels)
  ) +
  scale_y_discrete(labels = term_labels) +
  scale_x_continuous(
    breaks = c(1, 5, 10, 15), expand = expansion(mult = c(0.01, 0.05))
  ) +
  scale_size_continuous(
    name = "Genes", range = c(1.8, 5.7), breaks = c(10, 30, 50)
  ) +
  scale_fill_gradientn(
    name = expression(-log[10](FDR)),
    colours = c("#E1EBF0", "#69A1B3", "#153F5C"),
    values = rescale(c(min(plot_data$NegLog10FDR), 8, max(plot_data$NegLog10FDR)))
  ) +
  guides(
    fill = guide_colourbar(
      title.position = "top", direction = "horizontal", order = 1,
      barwidth = grid::unit(28, "pt"), barheight = grid::unit(4, "pt"),
      frame.colour = neutral_mid, ticks.colour = neutral_mid
    ),
    size = guide_legend(
      title.position = "top", direction = "horizontal", order = 2,
      nrow = 1, override.aes = list(fill = "#79A6B5")
    )
  ) +
  labs(
    x = "Fold enrichment", y = NULL,
    title = "Representative enriched terms", tag = "a"
  ) +
  theme_pub(6.4) +
  theme(
    axis.line.y = element_blank(), axis.ticks.y = element_blank(),
    axis.text.y = element_text(size = 5.9, lineheight = 0.9, margin = margin(r = 3)),
    strip.placement = "outside",
    strip.background = element_rect(fill = "#EEF2F3", colour = NA),
    strip.text.y.left = element_text(
      angle = 0, face = "bold", size = 6.2, colour = neutral_dark,
      margin = margin(4, 5, 4, 5)
    ),
    panel.spacing.y = grid::unit(3.5, "pt"),
    legend.position = "bottom", legend.box = "horizontal",
    legend.spacing.x = grid::unit(8, "pt"),
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(4, 5, 2, 2)
  )

# b | Overview answers how large each ontology-level signal is.
p_overview <- ggplot(ontology_summary, aes(SignificantTerms, Ontology, fill = Ontology)) +
  geom_col(width = 0.56, colour = NA) +
  geom_text(
    aes(label = Label), hjust = -0.08, size = 1.9, lineheight = 0.9,
    family = "Arial", colour = neutral_dark
  ) +
  scale_fill_manual(values = ontology_cols, guide = "none") +
  scale_y_discrete(labels = c(CC = "CC", MF = "MF", BP = "BP")) +
  scale_x_continuous(
    limits = c(0, max(ontology_summary$SignificantTerms) * 1.52),
    breaks = c(0, 20, 40), expand = c(0, 0)
  ) +
  labs(x = "Significant GO terms", y = NULL, title = "Ontology landscape", tag = "b") +
  theme_pub(6.2) +
  theme(
    axis.line.y = element_blank(), axis.ticks.y = element_blank(),
    axis.text.y = element_text(face = "bold"),
    plot.margin = margin(4, 6, 2, 3)
  )

# c | Compact UpSet-like panel shows exact ontology membership of enriched genes.
p_intersection_bar <- ggplot(intersection_summary, aes(Combination, Genes)) +
  geom_col(width = 0.62, fill = "#456F7E") +
  geom_text(aes(label = Genes), vjust = -0.35, size = 2.0, family = "Arial", colour = neutral_dark) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.16)), breaks = pretty_breaks(n = 3)) +
  labs(x = NULL, y = "Genes", title = "Shared enriched genes", tag = "c") +
  theme_pub(6.2) +
  theme(
    axis.text.x = element_blank(), axis.ticks.x = element_blank(),
    plot.margin = margin(4, 4, 0, 3)
  )

p_intersection_matrix <- ggplot(matrix_data, aes(X, Ontology)) +
  geom_segment(
    data = matrix_segments,
    aes(x = X, xend = X, y = ymin, yend = ymax),
    inherit.aes = FALSE, linewidth = 0.55, colour = neutral_mid
  ) +
  geom_point(aes(fill = Active), shape = 21, size = 2.4, stroke = 0.25, colour = neutral_mid) +
  scale_fill_manual(values = c(`FALSE` = "#E4E8EA", `TRUE` = "#314F5A"), guide = "none") +
  scale_x_continuous(breaks = intersection_summary$X, labels = rep("", nrow(intersection_summary))) +
  scale_y_discrete(labels = c(CC = "CC", MF = "MF", BP = "BP")) +
  labs(x = NULL, y = NULL) +
  theme_void(base_family = "Arial", base_size = 6.2) +
  theme(
    axis.text.y = element_text(size = 6, face = "bold", colour = neutral_dark, margin = margin(r = 3)),
    plot.margin = margin(0, 4, 3, 3)
  )

p_intersection <- p_intersection_bar / p_intersection_matrix +
  plot_layout(heights = c(2.15, 0.9))

right_column <- (p_overview / p_intersection) + plot_layout(heights = c(0.78, 1.35))
figure <- (p_terms | right_column) + plot_layout(widths = c(1.92, 1))

write.csv(
  plot_data %>%
    select(Ontology, ID, Description, GeneRatio, BgRatio, FoldEnrichment, Count, p.adjust, NegLog10FDR, geneID),
  file.path(out_dir, "Source_Data_panel_a_representative_terms.csv"), row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(ontology_summary, file.path(out_dir, "Source_Data_panel_b_ontology_summary.csv"), row.names = FALSE)
write.csv(membership, file.path(out_dir, "Source_Data_panel_c_gene_membership.csv"), row.names = FALSE)
write.csv(intersection_summary, file.path(out_dir, "Source_Data_panel_c_intersections.csv"), row.names = FALSE)

width_mm <- 183
height_mm <- 128
w <- width_mm / 25.4
h <- height_mm / 25.4
base_name <- file.path(out_dir, "PAO1_GO_enrichment_compact_multipanel")

svglite::svglite(
  paste0(base_name, ".svg"), width = w, height = h, bg = "white",
  system_fonts = list(sans = "Arial")
)
print(figure)
dev.off()

grDevices::cairo_pdf(
  paste0(base_name, ".pdf"), width = w, height = h,
  family = "Arial", bg = "white", onefile = TRUE
)
print(figure)
dev.off()

ragg::agg_tiff(
  paste0(base_name, ".tiff"), width = w, height = h, units = "in",
  res = 600, compression = "lzw", background = "white"
)
print(figure)
dev.off()

ragg::agg_png(
  paste0(base_name, ".png"), width = w, height = h, units = "in",
  res = 300, background = "white"
)
print(figure)
dev.off()

legend_text <- c(
  "GO enrichment of the PAO1 candidate-gene set.",
  "a, Representative non-redundant terms across biological process (BP), molecular function (MF) and cellular component (CC). Point area indicates the candidate-gene count and colour indicates −log10(FDR).",
  "b, Number of significant terms and unique genes represented among significant terms in each ontology.",
  "c, Exact overlap of genes represented by significant BP, MF and CC terms; bars show intersection sizes and the matrix indicates ontology membership.",
  "FDR values are Benjamini–Hochberg adjusted P values."
)
writeLines(legend_text, file.path(out_dir, "Figure_legend.txt"), useBytes = TRUE)

message("Compact multipanel figure written to: ", out_dir)
