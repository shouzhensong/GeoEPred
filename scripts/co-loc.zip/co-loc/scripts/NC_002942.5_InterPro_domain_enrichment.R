setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(ggplot2)
})

output_dir <- "NC_002942.5_InterPro_results"

# 1. 合并 InterProScan TSV ==================================================
cat("=== NC_002942.5 (Legionella) InterPro Domain Analysis ===\n")
tsv_dir <- "NC_002942.5_InterPro_results"
tsv_files <- list.files(tsv_dir, pattern = "\\.tsv$", full.names = TRUE)
cat("Files:", length(tsv_files), "\n")

ipr_cols <- c("Protein", "MD5", "SeqLen", "Analysis", "SigAccession",
              "SigDesc", "Start", "Stop", "Score", "Status",
              "Date", "InterPro_ID", "InterPro_Desc", "GO", "Pathways")

all_ipr <- do.call(rbind, lapply(tsv_files, function(f) {
  read.delim(f, header = FALSE, sep = "\t", quote = "",
             stringsAsFactors = FALSE, col.names = ipr_cols, fill = TRUE)
}))
cat("Total hits:", nrow(all_ipr), "\n")
cat("Unique proteins:", length(unique(all_ipr$Protein)), "\n")

# 2. 加载分泌类型 ============================================================
pred <- read.csv("NC_002942.5_T4SE/NC_002942.5_nonExp_predictions.csv",
                 stringsAsFactors = FALSE)
cat("Prediction file:", nrow(pred), "rows\n")
cat("Classes:", paste(sort(unique(pred$predicted_class)), collapse=", "), "\n")

prot_type <- setNames(pred$predicted_class, pred$protein_id)
all_ipr$SecType <- prot_type[all_ipr$Protein]
n_mapped <- sum(!is.na(all_ipr$SecType))
cat("Rows with secretion type:", n_mapped, "/", nrow(all_ipr), "\n")

# 3. Pfam 域分析 =============================================================
pfam <- all_ipr[all_ipr$Analysis == "Pfam", ]
cat("\n=== Pfam Domain Analysis ===\n")
cat("Pfam hits:", nrow(pfam), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")
cat("Proteins with Pfam:", length(unique(pfam$Protein)), "\n")

cat("\nSecretion type distribution:\n")
for (st in c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")) {
  p_all <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  p_pfam <- unique(pfam$Protein[pfam$SecType == st & !is.na(pfam$SecType)])
  cat(sprintf("  %s: %d proteins, %d with Pfam (%.0f%%)\n",
      st, length(p_all), length(p_pfam),
      100*length(p_pfam)/max(1,length(p_all))))
}

# 4. 效应蛋白标志域扫描 =====================================================
cat("\n\n=== Effector Signature Pfam Domain Scan ===\n")
effector_pfams <- c(
  "PF08238" = "Sel1 repeat (T4SE — Legionella hallmark)",
  "PF00023" = "Ankyrin repeat (T4SE)",
  "PF12796" = "Ankyrin repeat (variant)",
  "PF13637" = "Ankyrin repeat (variant)",
  "PF05488" = "PAAR motif (T6SS spike)",
  "PF05591" = "T6SS sheath TssB/VipA",
  "PF05943" = "T6SS baseplate TssK",
  "PF05593" = "RHS repeat (T6SS effector)",
  "PF05592" = "T6SS VgrG",
  "PF04717" = "Phage-baseplate injector OB",
  "PF05954" = "Phage tail baseplate hub",
  "PF03496" = "ADP-ribosyltransferase exotoxin",
  "PF03545" = "YopE GAP domain (T3SE)",
  "PF01582" = "TIR domain (host immune evasion)",
  "PF00646" = "F-box (host ubiquitin hijacking)",
  "PF00397" = "WW/Ub ligase domain",
  "PF00419" = "Fimbrial protein",
  "PF22178" = "Phage T4 gp5 trimerization",
  "PF13662" = "T4SS VirB4",
  "PF04932" = "WXG100 T7SS effector",
  "PF00665" = "Integrase core (mobile element)",
  "PF05506" = "Bacterial phospholipase C",
  "PF07591" = "PA14 domain",
  "PF00561" = "alpha/beta hydrolase fold (effector enzymes)"
)

cat(sprintf("\n%-12s %-42s %s\n", "Pfam", "Description", "Secretion Types (count)"))
cat(rep("-", 95), "\n")
for (pf_id in names(effector_pfams)) {
  pf_st <- pfam[pfam$SigAccession == pf_id & !is.na(pfam$SecType), ]
  if (nrow(pf_st) > 0) {
    types <- sort(table(pf_st$SecType), decreasing = TRUE)
    type_str <- paste(names(types), "(", types, ")", sep = "", collapse = ", ")
    cat(sprintf("%-12s %-42s %s\n", pf_id, effector_pfams[pf_id], type_str))
  }
}

# Also scan IPR-level effector domains
cat("\n=== InterPro-level Effector Domains ===\n")
ipr_effector <- c(
  "IPR002110" = "Ankyrin repeat",
  "IPR036770" = "Ankyrin repeat superfamily",
  "IPR006597" = "Sel1-like repeat",
  "IPR011990" = "Tetratricopeptide-like helical",
  "IPR000157" = "TIR domain",
  "IPR001810" = "F-box domain",
  "IPR036047" = "F-box-like domain superfamily",
  "IPR008312" = "T6SS sheath TssB1",
  "IPR017735" = "T6SS VgrG",
  "IPR013117" = "T6SS VgrG/PAAR"
)

ipr_all <- all_ipr[all_ipr$InterPro_ID != "" & !is.na(all_ipr$InterPro_ID) &
                    !is.na(all_ipr$SecType), ]
for (ipr_id in names(ipr_effector)) {
  ipr_st <- ipr_all[ipr_all$InterPro_ID == ipr_id, ]
  if (nrow(ipr_st) > 0) {
    types <- sort(table(ipr_st$SecType), decreasing = TRUE)
    type_str <- paste(names(types), "(", types, ")", sep = "", collapse = ", ")
    cat(sprintf("%-12s %-38s %s\n", ipr_id, ipr_effector[ipr_id], type_str))
  }
}

# 5. Pfam 富集分析 ==========================================================
cat("\n\n=== Pfam Enrichment by Secretion Type ===\n")
all_scan_prots <- unique(all_ipr$Protein)
pfam_t2g <- unique(pfam[, c("SigAccession", "Protein")])
colnames(pfam_t2g) <- c("term", "gene")
pfam_t2n <- unique(pfam[, c("SigAccession", "SigDesc")])
colnames(pfam_t2n) <- c("term", "name")
pfam_t2n <- pfam_t2n[!duplicated(pfam_t2n$term), ]

for (st in c("T6SE", "T4SE", "T3SE", "T2SE", "T1SE")) {
  st_prots <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  if (length(st_prots) < 5) next
  cat(sprintf("\n--- %s (%d proteins) ---\n", st, length(st_prots)))

  res <- tryCatch({
    clusterProfiler::enricher(
      gene = st_prots, universe = all_scan_prots,
      TERM2GENE = pfam_t2g, TERM2NAME = pfam_t2n,
      pAdjustMethod = "BH", pvalueCutoff = 1, qvalueCutoff = 1,
      minGSSize = 2, maxGSSize = 500
    )
  }, error = function(e) NULL)

  if (!is.null(res)) {
    tab <- as.data.frame(res)
    tab <- tab[order(tab$p.adjust, tab$pvalue), ]
    sig <- tab[!is.na(tab$p.adjust) & tab$p.adjust < 0.05, ]

    if (nrow(sig) > 0) {
      cat(sprintf("  Significant (p.adj<0.05): %d\n", nrow(sig)))
      for (i in seq_len(min(12, nrow(sig)))) {
        cat(sprintf("    %-12s p=%.1e  %s  genes=%s\n",
            sig$ID[i], sig$p.adjust[i], sig$Description[i], sig$GeneRatio[i]))
      }
    } else {
      cat("  No significant domains\n")
    }

    # Show top 5 even if not significant
    if (nrow(tab) >= 1 && nrow(sig) == 0) {
      cat("  Top 5:\n")
      for (i in seq_len(min(5, nrow(tab)))) {
        cat(sprintf("    %-12s p=%.1e  %s\n",
            tab$ID[i], tab$p.adjust[i], tab$Description[i]))
      }
    }

    tab$GeneRatio_num <- sapply(strsplit(tab$GeneRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$BgRatio_num <- sapply(strsplit(tab$BgRatio, "/"),
      function(p) as.numeric(p[1])/as.numeric(p[2]))
    tab$FoldEnrichment <- tab$GeneRatio_num / tab$BgRatio_num

    write.csv(tab, file.path(output_dir, paste0("Pfam_enrich_", st, ".csv")),
              row.names = FALSE)
  }
}

# 6. Top Pfam 域 + 分泌类型矩阵 ================================================
cat("\n\n===== Top 30 Pfam Domains — Secretion Type Distribution =====\n")
pfam_all_counts <- sort(table(pfam$SigAccession), decreasing = TRUE)
cat(sprintf("%-4s %-12s %5s %-40s %s\n", "Rank", "Pfam", "Count", "Description", "Type Distribution"))
cat(rep("-", 110), "\n")
for (i in seq_len(min(30, length(pfam_all_counts)))) {
  pf_id <- names(pfam_all_counts)[i]
  desc <- pfam_t2n$name[pfam_t2n$term == pf_id][1]
  if (is.na(desc) || desc == "") desc <- "(no description)"
  dist <- sapply(c("T1SE","T2SE","T3SE","T4SE","T6SE"), function(st) {
    sum(pfam$SigAccession == pf_id & pfam$SecType == st & !is.na(pfam$SecType))
  })
  cat(sprintf("%-4d %-12s %5d %-40s %s\n",
      i, pf_id, pfam_all_counts[i],
      substring(desc, 1, 40),
      paste(sprintf("%s:%d", names(dist), dist), collapse=" ")))
}

# 7. Summary ==================================================================
cat("\n\n===== Final Summary =====\n")
cat("Total InterPro hits:", nrow(all_ipr), "\n")
cat("Total proteins:", length(unique(all_ipr$Protein)), "\n")
cat("Proteins with Pfam:", length(unique(pfam$Protein)), "\n")
cat("Unique Pfam domains:", length(unique(pfam$SigAccession)), "\n")
cat("Unique InterPro entries:", length(unique(all_ipr$InterPro_ID[all_ipr$InterPro_ID != "" & !is.na(all_ipr$InterPro_ID)])), "\n")

cat("\nProteins with Pfam domains per type:\n")
for (st in c("T1SE","T2SE","T3SE","T4SE","T6SE")) {
  p_all <- unique(all_ipr$Protein[all_ipr$SecType == st & !is.na(all_ipr$SecType)])
  p_pfam <- unique(pfam$Protein[pfam$SecType == st & !is.na(pfam$SecType)])
  cat(sprintf("  %s: %d/%d (%.0f%%)\n",
      st, length(p_pfam), length(p_all),
      100*length(p_pfam)/max(1,length(p_all))))
}

cat("\nOutput:", output_dir, "\n===== Done =====\n")
