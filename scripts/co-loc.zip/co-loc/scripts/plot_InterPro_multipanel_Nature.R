setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(patchwork)
  library(scales)
  library(ragg)
})

output_dir <- "Nature_InterPro_multipanel"
if (!dir.exists(output_dir)) dir.create(output_dir)

# =========================================================================
# Nature-level colors (validated palette)
# =========================================================================
strain_cols <- c(
  "PAO1"              = "#356C7D",
  "NC_003197.2"       = "#C98545",
  "NC_002942.5"       = "#806A93"
)
sec_cols <- c(
  "T1SE" = "#7BA7BC", "T2SE" = "#8EB89C", "T3SE" = "#D4A76A",
  "T4SE" = "#C07B8B", "T6SE" = "#7A8DB8"
)
neutral_dark  <- "#26343C"
neutral_mid   <- "#6F7B82"
neutral_light <- "#D9E0E3"
bg_grey       <- "#F5F6F7"

# =========================================================================
# Load & merge all three InterPro enrichment results
# =========================================================================
read_enrich <- function(dir, strain) {
  files <- list.files(dir, pattern = "Pfam_enrich_.*\\.csv$", full.names = TRUE)
  if (length(files) == 0) return(NULL)
  do.call(rbind, lapply(files, function(f) {
    tab <- read.csv(f, stringsAsFactors = FALSE)
    # Harmonize: ensure SecType column exists
    if (!"SecType" %in% names(tab)) {
      sec <- gsub(".*Pfam_enrich_(.+)\\.csv$", "\\1", basename(f))
      tab$SecType <- sec
    }
    tab$Strain <- strain
    common <- intersect(c("ID","Description","GeneRatio","BgRatio","FoldEnrichment",
                          "pvalue","p.adjust","qvalue","geneID","Count",
                          "GeneRatio_num","BgRatio_num","SecType","Strain"), names(tab))
    tab[, common, drop = FALSE]
  }))
}

pao1_e   <- read_enrich("PAO1_InterPro_results", "PAO1")
nc003_e  <- read_enrich("NC_003197.2_InterPro_results", "NC_003197.2")
nc002_e  <- read_enrich("NC_002942.5_InterPro_results", "NC_002942.5")

all_enrich <- rbind(pao1_e, nc003_e, nc002_e)
if (is.null(all_enrich) || nrow(all_enrich) == 0) {
  stop("No enrichment data found")
}

# Normalize column names: clusterProfiler uses "ID" for domain accession
if ("ID" %in% names(all_enrich) && !"term" %in% names(all_enrich)) {
  all_enrich$term <- all_enrich$ID
}
if ("Count" %in% names(all_enrich) && !"Count" %in% names(all_enrich)) {
  # Count is fine
}
# Ensure numeric types
all_enrich$FoldEnrichment <- as.numeric(all_enrich$FoldEnrichment)
all_enrich$p.adjust <- as.numeric(all_enrich$p.adjust)
all_enrich$Count <- as.numeric(all_enrich$Count)

# Compute -log10(FDR)
all_enrich$NegLog10FDR <- -log10(pmax(all_enrich$p.adjust, 1e-30))
all_enrich$SigLabel <- ifelse(all_enrich$p.adjust < 0.05, "*", "")
all_enrich$SigLabel <- ifelse(all_enrich$p.adjust < 0.01, "**", all_enrich$SigLabel)
all_enrich$SigLabel <- ifelse(all_enrich$p.adjust < 0.001, "***", all_enrich$SigLabel)

all_enrich$Strain <- factor(all_enrich$Strain, levels = c("PAO1", "NC_003197.2", "NC_002942.5"))
all_enrich$SecType <- factor(all_enrich$SecType, levels = c("T6SE", "T4SE", "T3SE", "T2SE", "T1SE"))

# =========================================================================
# Panel A: Top effector-associated Pfam domains dot plot
# =========================================================================
cat("Building Panel A...\n")

# Select known effector-associated Pfam domains across all three strains
effector_pfams <- c(
  "PF08238", "PF05488", "PF05591", "PF05943", "PF05593", "PF05592",
  "PF04717", "PF05954", "PF03496", "PF03545", "PF01582", "PF00646",
  "PF00665", "PF00419", "PF07591", "PF08897", "PF13662", "PF04932",
  "PF00023", "PF12796", "PF05506", "PF00126", "PF03466",
  "PF05638", "PF00353", "PF01447", "PF02868", "PF22178",
  "PF05935", "PF07338", "PF17936", "PF16263"
)

panel_a <- all_enrich %>%
  filter(term %in% effector_pfams & !is.na(FoldEnrichment)) %>%
  mutate(PfamLabel = paste0(term, ": ", substr(Description, 1, 35)))

if (nrow(panel_a) == 0) {
  panel_a <- all_enrich %>%
    filter(!is.na(FoldEnrichment)) %>%
    group_by(SecType, Strain) %>%
    slice_min(p.adjust, n = 2) %>%
    ungroup() %>%
    mutate(PfamLabel = paste0(term, ": ", substr(Description, 1, 35)))
}

# Order by domain
panel_a$PfamLabel <- factor(panel_a$PfamLabel, levels = rev(sort(unique(panel_a$PfamLabel))))

p_a <- ggplot(panel_a, aes(SecType, PfamLabel)) +
  geom_point(aes(size = Count, fill = Strain, alpha = NegLog10FDR),
             shape = 21, colour = neutral_dark, stroke = 0.25) +
  scale_fill_manual(values = strain_cols, name = NULL) +
  scale_size_continuous(range = c(1.5, 6), breaks = c(2, 5, 10, 20, 40),
                        name = "Genes") +
  scale_alpha_continuous(range = c(0.25, 1), name = expression(-log[10](FDR))) +
  facet_grid(Strain ~ ., scales = "free_y", space = "free_y", switch = "y") +
  labs(x = "Secretion type", y = NULL,
       title = "Effector-associated Pfam domains",
       tag = "a") +
  theme_classic(base_size = 7) +
  theme(
    axis.text.x = element_text(size = 6.5, face = "bold", colour = neutral_dark),
    axis.text.y = element_text(size = 5.8, colour = neutral_dark, lineheight = 0.9),
    axis.line = element_line(linewidth = 0.3, colour = neutral_dark),
    axis.ticks = element_line(linewidth = 0.25, colour = neutral_dark),
    strip.placement = "outside",
    strip.background = element_rect(fill = "#EEF2F3", colour = NA),
    strip.text.y.left = element_text(angle = 0, size = 6.5, face = "bold",
                                     colour = neutral_dark),
    legend.position = "bottom", legend.box = "horizontal",
    legend.title = element_text(size = 6), legend.text = element_text(size = 5.5),
    legend.key.size = unit(8, "pt"),
    plot.title = element_text(size = 8, face = "bold", colour = neutral_dark),
    plot.tag = element_text(size = 9, face = "bold"),
    panel.spacing.y = unit(4, "pt"),
    plot.margin = margin(4, 4, 2, 2)
  ) +
  guides(
    fill = guide_legend(override.aes = list(size = 3, alpha = 1), nrow = 1),
    size = guide_legend(nrow = 1),
    alpha = guide_legend(nrow = 1)
  )

# =========================================================================
# Panel B: Domain-type segregation matrix
# =========================================================================
cat("Building Panel B...\n")

# Count unique Pfam domains per secretion type per strain
domain_counts <- all_enrich %>%
  filter(!is.na(FoldEnrichment)) %>%
  group_by(Strain, SecType) %>%
  summarise(
    n_sig = sum(p.adjust < 0.05, na.rm = TRUE),
    n_total = n(),
    top_domain = if (n() > 0) term[which.min(p.adjust)] else NA,
    .groups = "drop"
  )

p_b <- ggplot(domain_counts, aes(SecType, Strain)) +
  geom_tile(aes(fill = n_sig), colour = "white", linewidth = 0.6) +
  geom_text(aes(label = ifelse(n_sig > 0, n_sig, "")),
            size = 4.5, fontface = "bold", colour = neutral_dark) +
  scale_fill_gradientn(
    colours = c("#EEF2F5", "#8AB5C4", "#1A4A5E"),
    name = "Significant\nPfam domains",
    breaks = c(0, 3, 6, 9)
  ) +
  labs(x = "Secretion type", y = NULL, title = "Significant Pfam domains",
       tag = "b") +
  theme_classic(base_size = 7) +
  theme(
    axis.text = element_text(size = 7, colour = neutral_dark),
    axis.text.y = element_text(face = "bold"),
    axis.line = element_blank(), axis.ticks = element_blank(),
    legend.position = "right",
    legend.title = element_text(size = 6), legend.text = element_text(size = 5.5),
    plot.title = element_text(size = 8, face = "bold"),
    plot.tag = element_text(size = 9, face = "bold"),
    plot.margin = margin(4, 4, 2, 2)
  )

# =========================================================================
# Panel C: Strain summary overview
# =========================================================================
cat("Building Panel C...\n")

summary_data <- all_enrich %>%
  filter(!is.na(FoldEnrichment)) %>%
  group_by(Strain) %>%
  summarise(
    TotalTerms = n(),
    SigTerms = sum(p.adjust < 0.05, na.rm = TRUE),
    TopTerm = if (n() > 0) Description[which.min(p.adjust)] else "",
    .groups = "drop"
  ) %>%
  mutate(
    Label = paste0(TotalTerms, " terms\n", SigTerms, " significant"),
    Strain = factor(Strain, levels = rev(c("PAO1", "NC_003197.2", "NC_002942.5")))
  )

p_c <- ggplot(summary_data, aes(TotalTerms, Strain, fill = Strain)) +
  geom_col(width = 0.55) +
  geom_text(aes(label = Label), hjust = -0.05, size = 2.3, lineheight = 0.9,
            colour = neutral_dark) +
  scale_fill_manual(values = strain_cols, guide = "none") +
  scale_x_continuous(limits = c(0, max(summary_data$TotalTerms) * 1.5),
                     expand = c(0, 0)) +
  labs(x = "Enriched Pfam domains", y = NULL,
       title = "Domain enrichment overview", tag = "c") +
  theme_classic(base_size = 7) +
  theme(
    axis.line.y = element_blank(), axis.ticks.y = element_blank(),
    axis.text.y = element_text(size = 7, face = "bold", colour = neutral_dark),
    axis.text.x = element_text(size = 6, colour = neutral_dark),
    plot.title = element_text(size = 8, face = "bold"),
    plot.tag = element_text(size = 9, face = "bold"),
    plot.margin = margin(4, 4, 2, 2)
  )

# =========================================================================
# Panel D: Key effector domain detail (Sel1, Ankyrin, PAAR, RHS, etc.)
# =========================================================================
cat("Building Panel D...\n")

key_effector <- data.frame(
  Domain = c("Sel1 repeat", "Ankyrin repeat", "RHS repeat", "PAAR motif",
             "T6SS Hcp", "T3SS needle", "Fimbrial", "RTX repeat",
             "YopE GAP", "ADP-ribosyl", "TIR domain", "F-box"),
  Pfam = c("PF08238", "PF00023", "PF05593", "PF05488",
           "PF05638", "PF09392", "PF00419", "PF00353",
           "PF03545", "PF03496", "PF01582", "PF00646"),
  Target = c("T4SE", "T4SE", "T6SE", "T6SE",
             "T6SE", "T3SE", "T2SE", "T1SE",
             "T3SE", "T3SE", "T3SE/T4SE", "T3SE"),
  stringsAsFactors = FALSE
)

# Find which strains have each domain
domain_strain <- do.call(rbind, lapply(seq_len(nrow(key_effector)), function(i) {
  pf <- key_effector$Pfam[i]
  strains_found <- c()
  for (s in c("PAO1", "NC_003197.2", "NC_002942.5")) {
    se <- all_enrich[all_enrich$Strain == s & all_enrich$term == pf &
                     !is.na(all_enrich$Count), ]
    if (nrow(se) > 0 && max(se$Count, na.rm = TRUE) > 0) {
      strains_found <- c(strains_found, s)
    }
  }
  data.frame(
    Domain = key_effector$Domain[i],
    Pfam = pf,
    Target = key_effector$Target[i],
    PAO1 = "PAO1" %in% strains_found,
    NC_003197.2 = "NC_003197.2" %in% strains_found,
    NC_002942.5 = "NC_002942.5" %in% strains_found,
    stringsAsFactors = FALSE
  )
}))

domain_long <- domain_strain %>%
  pivot_longer(cols = c(PAO1, NC_003197.2, NC_002942.5),
               names_to = "Strain", values_to = "Present") %>%
  mutate(
    Domain = factor(Domain, levels = rev(key_effector$Domain)),
    Strain = factor(Strain, levels = c("PAO1", "NC_003197.2", "NC_002942.5"))
  )

p_d <- ggplot(domain_long, aes(Strain, Domain)) +
  geom_point(aes(fill = Present, size = Present),
             shape = 21, colour = neutral_mid, stroke = 0.3) +
  scale_fill_manual(values = c(`TRUE` = "#2E5C6E", `FALSE` = "#E4E8EA"),
                    guide = "none") +
  scale_size_manual(values = c(`TRUE` = 3, `FALSE` = 1.5), guide = "none") +
  labs(x = NULL, y = NULL,
       title = "Effector signature domains",
       subtitle = "Cross-strain presence of canonical effector domains",
       tag = "d") +
  theme_classic(base_size = 7) +
  theme(
    axis.text = element_text(size = 6.5, colour = neutral_dark),
    axis.text.y = element_text(face = "bold"),
    axis.line = element_line(linewidth = 0.3, colour = neutral_dark),
    axis.ticks = element_line(linewidth = 0.25, colour = neutral_dark),
    plot.title = element_text(size = 8, face = "bold"),
    plot.subtitle = element_text(size = 6, colour = neutral_mid),
    plot.tag = element_text(size = 9, face = "bold"),
    plot.margin = margin(4, 4, 2, 2)
  )

# =========================================================================
# Assemble figure
# =========================================================================
cat("Assembling figure...\n")
left_col  <- (p_a / p_c) + plot_layout(heights = c(2.5, 1))
right_col <- (p_b / p_d) + plot_layout(heights = c(1, 1.4))
figure    <- left_col | right_col

# Export
width_mm  <- 183
height_mm <- 180
w <- width_mm / 25.4
h <- height_mm / 25.4
base <- file.path(output_dir, "InterPro_Multipanel_Nature")

cat("Saving...\n")
ggsave(paste0(base, ".pdf"), figure, width = w, height = h,
       device = "pdf", bg = "white")
ragg::agg_tiff(paste0(base, ".tiff"), width = w, height = h, units = "in",
               res = 600, compression = "lzw", background = "white")
ragg::agg_png(paste0(base, ".png"), width = w, height = h, units = "in",
              res = 300, background = "white")

cat("\nFigure saved to:", output_dir, "\n")
cat("===== Done =====\n")
