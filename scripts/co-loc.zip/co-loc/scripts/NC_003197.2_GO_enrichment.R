# ============================================================================
# GO富集分析 — NC_003197.2 (Salmonella Typhimurium LT2)
# 基于 PAO1 实验流程改写：
#   候选集: candidate_genes_effector.txt  (筛除实验T3SE后的效应蛋白)
#   背景集: background_genes_all.txt     (全基因组基因)
# ============================================================================

# 0. 环境设置 ================================================================
setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")

# 创建结果输出文件夹
output_dir <- "NC_003197.2_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

# 安装/加载必要包
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("clusterProfiler", quietly = TRUE)) BiocManager::install("clusterProfiler")
if (!requireNamespace("GO.db", quietly = TRUE)) BiocManager::install("GO.db")
if (!requireNamespace("enrichplot", quietly = TRUE)) BiocManager::install("enrichplot")
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
if (!requireNamespace("GOSemSim", quietly = TRUE)) BiocManager::install("GOSemSim")

library(clusterProfiler)
library(GO.db)
library(AnnotationDbi)
library(enrichplot)
library(ggplot2)
library(GOSemSim)

# 1. 加载候选基因和背景基因 =================================================
candidate_ids <- readLines("candidate_genes_effector.txt", warn = FALSE)
background_ids <- readLines("background_genes_all.txt", warn = FALSE)

# 清洗: 去空白、去重复、转大写
candidate_ids <- unique(toupper(trimws(candidate_ids)))
candidate_ids <- candidate_ids[!is.na(candidate_ids) & candidate_ids != ""]

background_ids <- unique(toupper(trimws(background_ids)))
background_ids <- background_ids[!is.na(background_ids) & background_ids != ""]

cat("候选基因数:", length(candidate_ids), "\n")
cat("背景基因数:", length(background_ids), "\n")
cat("前5个候选:", head(candidate_ids, 5), "\n")

# 清理后缀 (STM0306a -> STM0306, 与 PAO1 流程相同的逻辑)
clean_candidates <- unique(sub("([STM0-9]+).*", "\\1", candidate_ids))
clean_background <- unique(sub("([STM0-9]+).*", "\\1", background_ids))

cat("清洗后候选基因数:", length(clean_candidates), "\n")
cat("清洗后背景基因数:", length(clean_background), "\n")
cat("候选不在背景中的数量:", length(setdiff(clean_candidates, clean_background)), "(应为0)\n")

# 2. 下载 Salmonella Typhimurium GO 注释文件 =================================
# GO consortium: 5字母代码 SALTY = Salmonella typhimurium
gaf_url <- paste0(
  "https://current.geneontology.org/",
  "annotations/gaf/SALTY-uniprot.gaf.gz"
)

gpi_url <- paste0(
  "https://current.geneontology.org/",
  "annotations/gpi/SALTY-uniprot.gpi.gz"
)

download.file(url = gaf_url, destfile = file.path(output_dir, "SALTY-uniprot.gaf.gz"), mode = "wb", method = "libcurl")
download.file(url = gpi_url, destfile = file.path(output_dir, "SALTY-uniprot.gpi.gz"), mode = "wb", method = "libcurl")

cat("GAF/GPI 下载完成\n")
file.info(file.path(output_dir, c("SALTY-uniprot.gaf.gz", "SALTY-uniprot.gpi.gz")))[, c("size", "mtime")]

# 3. 解析 GAF 文件 ============================================================
gaf_columns <- c(
  "DB", "DB_Object_ID", "DB_Object_Symbol", "Qualifier",
  "GO_ID", "DB_Reference", "Evidence_Code", "With_From",
  "Aspect", "DB_Object_Name", "DB_Object_Synonym",
  "DB_Object_Type", "Taxon", "Date", "Assigned_By",
  "Annotation_Extension", "Gene_Product_Form_ID"
)

salty_gaf <- read.delim(
  gzfile(file.path(output_dir, "SALTY-uniprot.gaf.gz")),
  comment.char       = "!",
  header             = FALSE,
  sep                = "\t",
  quote              = "",
  fill               = TRUE,
  stringsAsFactors   = FALSE,
  col.names          = gaf_columns,
  check.names        = FALSE
)

cat("GAF 总行数:", nrow(salty_gaf), "\n")
cat("GO分支分布:\n")
print(table(salty_gaf$Aspect))

# 4. 从 GAF 中提取 STM locus tag =============================================
# Salmonella 的 DB_Object_Symbol 和 Synonym 字段中包含 STMxxxx 格式的 locus tag
extract_stm_locus <- function(gene_symbol, synonyms) {

  gene_symbol <- ifelse(is.na(gene_symbol), "", gene_symbol)
  synonyms    <- ifelse(is.na(synonyms),    "", synonyms)

  tokens <- unlist(strsplit(paste(gene_symbol, synonyms, sep = "|"), "\\|"))
  tokens <- trimws(tokens)

  # 匹配 STM0001、STM0306a、STM1112b、STM1552.1 等格式
  stm_hits <- tokens[grepl("^STM[0-9]{4}([A-Z]+|\\.[0-9]+)?$", tokens, ignore.case = TRUE)]

  if (length(stm_hits) == 0) return(NA_character_)
  toupper(stm_hits[1])
}

salty_gaf$locus_tag <- mapply(
  FUN         = extract_stm_locus,
  gene_symbol = salty_gaf$DB_Object_Symbol,
  synonyms    = salty_gaf$DB_Object_Synonym,
  USE.NAMES   = FALSE
)

cat("成功提取 locus_tag 的注释数:", sum(!is.na(salty_gaf$locus_tag)), "/", nrow(salty_gaf), "\n")
cat("唯一的 locus_tag 数:", length(unique(na.omit(salty_gaf$locus_tag))), "\n")

# 5. 筛选正向注释 (去除 NOT 否定注释) =========================================
qualifier_text <- ifelse(is.na(salty_gaf$Qualifier), "", salty_gaf$Qualifier)
is_not_annotation <- grepl("(^|\\|)NOT($|\\|)", qualifier_text, ignore.case = TRUE)

salty_gaf_positive <- salty_gaf[
  !is_not_annotation &
    !is.na(salty_gaf$locus_tag) &
    salty_gaf$locus_tag != "" &
    grepl("^GO:[0-9]{7}$", salty_gaf$GO_ID) &
    salty_gaf$Aspect %in% c("P", "F", "C"),
  c("locus_tag", "GO_ID", "Aspect", "Evidence_Code", "DB_Object_ID", "DB_Object_Symbol"),
  drop = FALSE
]

salty_gaf_positive <- unique(salty_gaf_positive)
cat("正向注释数:", nrow(salty_gaf_positive), "\n")
cat("分支分布:\n")
print(table(salty_gaf_positive$Aspect))
cat("注释到的唯一 locus_tag:", length(unique(salty_gaf_positive$locus_tag)), "\n")

# 6. 候选/背景基因与 GO 注释的映射统计 =======================================
annotated_locus_tags <- unique(salty_gaf_positive$locus_tag)

candidate_mapped <- intersect(clean_candidates, annotated_locus_tags)
background_mapped <- intersect(clean_background, annotated_locus_tags)
candidate_unmapped <- setdiff(clean_candidates, annotated_locus_tags)
background_unmapped <- setdiff(clean_background, annotated_locus_tags)

mapping_summary <- data.frame(
  Dataset    = c("Candidate", "Background"),
  Total      = c(length(clean_candidates), length(clean_background)),
  GO_mapped  = c(length(candidate_mapped), length(background_mapped)),
  GO_unmapped = c(length(candidate_unmapped), length(background_unmapped))
)
mapping_summary$Mapping_rate_percent <- round(100 * mapping_summary$GO_mapped / mapping_summary$Total, 2)
print(mapping_summary)

# 分本体论统计
aspect_codes <- c(BP = "P", MF = "F", CC = "C")
aspect_mapping_summary <- do.call(rbind, lapply(names(aspect_codes), function(ontology_name) {
  aspect_code <- aspect_codes[ontology_name]
  aspect_genes <- unique(salty_gaf_positive$locus_tag[salty_gaf_positive$Aspect == aspect_code])
  data.frame(
    Ontology          = ontology_name,
    Candidate_total   = length(clean_candidates),
    Candidate_mapped  = length(intersect(clean_candidates, aspect_genes)),
    Background_total  = length(clean_background),
    Background_mapped = length(intersect(clean_background, aspect_genes))
  )
}))
aspect_mapping_summary$Candidate_rate_percent  <- round(100 * aspect_mapping_summary$Candidate_mapped  / aspect_mapping_summary$Candidate_total,  2)
aspect_mapping_summary$Background_rate_percent <- round(100 * aspect_mapping_summary$Background_mapped / aspect_mapping_summary$Background_total, 2)
rownames(aspect_mapping_summary) <- NULL
print(aspect_mapping_summary)

# 7. 构建直接 GO 映射表 ======================================================
go_direct_mapping <- unique(
  salty_gaf_positive[, c("GO_ID", "locus_tag", "Aspect")]
)
cat("直接 GO 映射行数:", nrow(go_direct_mapping), "\n")

# 8. 构建 term2gene 和 term2name (展开祖先条目) ==============================
build_term2gene <- function(direct_mapping, aspect_code) {

  direct_subset <- unique(
    direct_mapping[direct_mapping$Aspect == aspect_code, c("GO_ID", "locus_tag"), drop = FALSE]
  )
  colnames(direct_subset) <- c("direct_term", "gene")

  ancestor_database <- switch(
    aspect_code,
    P = GO.db::GOBPANCESTOR,
    F = GO.db::GOMFANCESTOR,
    C = GO.db::GOCCANCESTOR,
    stop("aspect_code必须是P、F或C")
  )

  ancestor_list <- as.list(ancestor_database)
  direct_terms  <- unique(direct_subset$direct_term)

  expansion_list <- lapply(direct_terms, function(current_term) {
    ancestors <- ancestor_list[[current_term]]
    if (is.null(ancestors)) ancestors <- character(0)
    ancestors <- ancestors[!is.na(ancestors)]
    data.frame(
      direct_term = current_term,
      term        = unique(c(current_term, ancestors)),
      stringsAsFactors = FALSE
    )
  })

  term_expansion  <- do.call(rbind, expansion_list)
  expanded_mapping <- merge(direct_subset, term_expansion, by = "direct_term", all.x = TRUE)

  result <- unique(expanded_mapping[, c("term", "gene")])
  result <- result[!is.na(result$term) & result$term != "" &
                   !is.na(result$gene) & result$gene != "", , drop = FALSE]
  rownames(result) <- NULL
  return(result)
}

build_term2name <- function(term2gene, ontology_code) {
  go_ids <- unique(term2gene$term)
  go_information <- AnnotationDbi::select(
    GO.db::GO.db, keys = go_ids, keytype = "GOID",
    columns = c("TERM", "ONTOLOGY")
  )
  go_information <- go_information[
    !is.na(go_information$TERM) & go_information$ONTOLOGY == ontology_code,
    , drop = FALSE
  ]
  term2name <- unique(data.frame(
    term = go_information$GOID,
    name = go_information$TERM,
    stringsAsFactors = FALSE
  ))
  rownames(term2name) <- NULL
  return(term2name)
}

term2gene_bp <- build_term2gene(go_direct_mapping, "P")
term2gene_mf <- build_term2gene(go_direct_mapping, "F")
term2gene_cc <- build_term2gene(go_direct_mapping, "C")

term2name_bp <- build_term2name(term2gene_bp, "BP")
term2name_mf <- build_term2name(term2gene_mf, "MF")
term2name_cc <- build_term2name(term2gene_cc, "CC")

cat("term2gene 维度: BP", dim(term2gene_bp), "MF", dim(term2gene_mf), "CC", dim(term2gene_cc), "\n")
cat("term2name 维度: BP", dim(term2name_bp), "MF", dim(term2name_mf), "CC", dim(term2name_cc), "\n")

# 9. 运行 GO 富集分析 ========================================================
# 使用 pvalueCutoff=1, qvalueCutoff=1 输出全部结果，后续再筛选
run_go_enrichment <- function(candidate_ids, background_ids, term2gene, term2name) {
  clusterProfiler::enricher(
    gene          = candidate_ids,
    universe      = background_ids,
    TERM2GENE     = term2gene,
    TERM2NAME     = term2name,
    pAdjustMethod = "BH",
    pvalueCutoff  = 1,
    qvalueCutoff  = 1,
    minGSSize     = 5,
    maxGSSize     = 500
  )
}

go_bp_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_bp, term2name_bp)
go_mf_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_mf, term2name_mf)
go_cc_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_cc, term2name_cc)

# 转为 data.frame 并按 p.adjust 排序
go_bp_table <- as.data.frame(go_bp_result)
go_mf_table <- as.data.frame(go_mf_result)
go_cc_table <- as.data.frame(go_cc_result)

go_bp_table <- go_bp_table[order(go_bp_table$p.adjust, go_bp_table$pvalue), ]
go_mf_table <- go_mf_table[order(go_mf_table$p.adjust, go_mf_table$pvalue), ]
go_cc_table <- go_cc_table[order(go_cc_table$p.adjust, go_cc_table$pvalue), ]

cat("全部分析结果: BP", nrow(go_bp_table), "MF", nrow(go_mf_table), "CC", nrow(go_cc_table), "\n")

# 10. 筛选显著条目 (p.adjust < 0.05, qvalue < 0.20) ==========================
select_significant <- function(result_table) {
  result_table[
    !is.na(result_table$p.adjust) & result_table$p.adjust < 0.05 &
    !is.na(result_table$qvalue)  & result_table$qvalue  < 0.20,
    , drop = FALSE
  ]
}

go_bp_significant <- select_significant(go_bp_table)
go_mf_significant <- select_significant(go_mf_table)
go_cc_significant <- select_significant(go_cc_table)

cat("显著条目: BP", nrow(go_bp_significant), "MF", nrow(go_mf_significant), "CC", nrow(go_cc_significant), "\n")

# 11. 导出全部结果和显著结果 CSV ==============================================
write.csv(go_bp_table, file.path(output_dir, "GO_BP_all_results.csv"), row.names = FALSE)
write.csv(go_mf_table, file.path(output_dir, "GO_MF_all_results.csv"), row.names = FALSE)
write.csv(go_cc_table, file.path(output_dir, "GO_CC_all_results.csv"), row.names = FALSE)

write.csv(go_bp_significant, file.path(output_dir, "GO_BP_significant.csv"), row.names = FALSE)
write.csv(go_mf_significant, file.path(output_dir, "GO_MF_significant.csv"), row.names = FALSE)
write.csv(go_cc_significant, file.path(output_dir, "GO_CC_significant.csv"), row.names = FALSE)

cat("基础结果已导出\n")

# 12. 添加 Fold Enrichment 并导出 =============================================
parse_ratio <- function(ratio_vector) {
  vapply(strsplit(as.character(ratio_vector), "/", fixed = TRUE),
         function(parts) as.numeric(parts[1]) / as.numeric(parts[2]),
         numeric(1))
}

add_enrichment_metrics <- function(result_table) {
  if (nrow(result_table) == 0) return(result_table)
  result_table$GeneRatio_numeric <- parse_ratio(result_table$GeneRatio)
  result_table$BgRatio_numeric    <- parse_ratio(result_table$BgRatio)
  result_table$FoldEnrichment     <- result_table$GeneRatio_numeric / result_table$BgRatio_numeric
  result_table <- result_table[order(result_table$p.adjust, -result_table$FoldEnrichment), ]
  rownames(result_table) <- NULL
  result_table
}

go_bp_significant <- add_enrichment_metrics(go_bp_significant)
go_mf_significant <- add_enrichment_metrics(go_mf_significant)
go_cc_significant <- add_enrichment_metrics(go_cc_significant)

write.csv(go_bp_significant, file.path(output_dir, "GO_BP_significant_with_fold.csv"), row.names = FALSE)
write.csv(go_mf_significant, file.path(output_dir, "GO_MF_significant_with_fold.csv"), row.names = FALSE)
write.csv(go_cc_significant, file.path(output_dir, "GO_CC_significant_with_fold.csv"), row.names = FALSE)

cat("含Fold Enrichment的显著结果已导出\n")

# 13. 前15条BP结果预览 =======================================================
result_columns <- c("ID", "Description", "GeneRatio", "BgRatio", "FoldEnrichment",
                    "pvalue", "p.adjust", "qvalue", "Count")
if (nrow(go_bp_significant) > 0) {
  cat("\n===== BP显著富集前15条 =====\n")
  print(head(go_bp_significant[, intersect(result_columns, colnames(go_bp_significant))], 15))
}

# 14. 语义简化 (GOSemSim, Wang measure, cutoff=0.70) ==========================
make_significant_object <- function(full_result, significant_table, ontology) {
  result_object <- full_result
  keep_rows <- result_object@result$ID %in% significant_table$ID
  result_object@result <- result_object@result[keep_rows, , drop = FALSE]
  result_object@ontology <- ontology
  return(result_object)
}

bp_significant_object <- make_significant_object(go_bp_result, go_bp_significant, "BP")
mf_significant_object <- make_significant_object(go_mf_result, go_mf_significant, "MF")
cc_significant_object <- make_significant_object(go_cc_result, go_cc_significant, "CC")

bp_simplified <- clusterProfiler::simplify(
  bp_significant_object, cutoff = 0.70, by = "p.adjust",
  select_fun = min, measure = "Wang"
)
mf_simplified <- clusterProfiler::simplify(
  mf_significant_object, cutoff = 0.70, by = "p.adjust",
  select_fun = min, measure = "Wang"
)
cc_simplified <- clusterProfiler::simplify(
  cc_significant_object, cutoff = 0.70, by = "p.adjust",
  select_fun = min, measure = "Wang"
)

cat("\n语义简化结果:\n")
simplify_stats <- data.frame(
  Ontology = c("BP", "MF", "CC"),
  Before   = c(nrow(go_bp_significant), nrow(go_mf_significant), nrow(go_cc_significant)),
  After    = c(nrow(as.data.frame(bp_simplified)), nrow(as.data.frame(mf_simplified)), nrow(as.data.frame(cc_simplified)))
)
print(simplify_stats)

# 15. 可视化 — 气泡图 =========================================================
ratio_to_numeric <- function(x) {
  vapply(strsplit(as.character(x), "/", fixed = TRUE),
         function(parts) as.numeric(parts[1]) / as.numeric(parts[2]),
         numeric(1))
}

prepare_top_terms <- function(enrichment_object, ontology, number) {
  result <- as.data.frame(enrichment_object)
  if (nrow(result) == 0) return(NULL)

  result$GeneRatio_numeric <- ratio_to_numeric(result$GeneRatio)
  result$BgRatio_numeric    <- ratio_to_numeric(result$BgRatio)
  result$FoldEnrichment     <- result$GeneRatio_numeric / result$BgRatio_numeric
  result$NegLog10FDR        <- -log10(pmax(result$p.adjust, .Machine$double.xmin))

  result <- result[order(result$p.adjust, -result$FoldEnrichment), , drop = FALSE]
  result <- head(result, number)
  result$Ontology <- ontology
  return(result)
}

bp_plot_data <- prepare_top_terms(bp_simplified, "BP", 8)
mf_plot_data <- prepare_top_terms(mf_simplified, "MF", 8)
cc_plot_data <- prepare_top_terms(cc_simplified, "CC", 6)

plot_data <- do.call(rbind, list(bp_plot_data, mf_plot_data, cc_plot_data))
rownames(plot_data) <- NULL

wrap_go_description <- function(description, width = 46) {
  vapply(description, function(txt) {
    paste(strwrap(txt, width = width), collapse = "\n")
  }, character(1))
}

plot_data$Ontology <- factor(plot_data$Ontology, levels = c("BP", "MF", "CC"))
plot_data <- plot_data[order(plot_data$Ontology, plot_data$FoldEnrichment), , drop = FALSE]
plot_data$TermKey <- paste(plot_data$Ontology, plot_data$ID, sep = "_")
plot_data$TermKey <- factor(plot_data$TermKey, levels = unique(plot_data$TermKey))

term_labels <- setNames(
  wrap_go_description(plot_data$Description),
  as.character(plot_data$TermKey)
)

go_bubble_plot <- ggplot(plot_data, aes(x = FoldEnrichment, y = TermKey)) +
  geom_vline(xintercept = 1, linewidth = 0.35, linetype = "dashed", colour = "grey70") +
  geom_point(aes(size = Count, fill = NegLog10FDR),
             shape = 21, colour = "grey15", stroke = 0.30, alpha = 0.95) +
  facet_grid(Ontology ~ ., scales = "free_y", space = "free_y", switch = "y") +
  scale_y_discrete(labels = term_labels) +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.12))) +
  scale_size_continuous(name = "Candidate\ngenes", range = c(3, 9)) +
  scale_fill_viridis_c(name = expression(-log[10]("FDR")), option = "C", direction = 1) +
  labs(x = "Fold enrichment", y = NULL) +
  theme_classic(base_size = 10) +
  theme(
    axis.title.x       = element_text(size = 10, colour = "black", margin = margin(t = 8)),
    axis.text.x        = element_text(size = 8.5, colour = "black"),
    axis.text.y        = element_text(size = 8.2, colour = "black", lineheight = 0.92),
    axis.line.y        = element_blank(),
    axis.ticks.y       = element_blank(),
    strip.placement    = "outside",
    strip.background   = element_rect(fill = "#EAF0F5", colour = NA),
    strip.text.y.left  = element_text(angle = 0, face = "bold", size = 9, colour = "#203040"),
    panel.spacing.y    = unit(0.7, "lines"),
    legend.position    = "right",
    legend.title       = element_text(size = 8.5),
    legend.text        = element_text(size = 8),
    plot.margin        = margin(8, 12, 8, 8)
  )

# print(go_bubble_plot)  # 跳过Rscript中的交互式打印

# 16. 保存图表 ================================================================
figure_height <- max(6.5, 0.31 * nrow(plot_data) + 1.8)

ggsave(file.path(output_dir, "NC_003197.2_GO_enrichment_bubble.pdf"),
       plot = go_bubble_plot, width = 7.5, height = figure_height,
       units = "in", device = "pdf", bg = "white")

ggsave(file.path(output_dir, "NC_003197.2_GO_enrichment_bubble.tiff"),
       plot = go_bubble_plot, width = 7.5, height = figure_height,
       units = "in", dpi = 600, compression = "lzw", bg = "white")

ggsave(file.path(output_dir, "NC_003197.2_GO_enrichment_bubble.png"),
       plot = go_bubble_plot, width = 7.5, height = figure_height,
       units = "in", dpi = 600, bg = "white")

cat("\n===== 分析完成 =====\n")
cat("输出文件:\n")
cat("  GO_BP_all_results.csv, GO_MF_all_results.csv, GO_CC_all_results.csv\n")
cat("  GO_BP_significant.csv, GO_MF_significant.csv, GO_CC_significant.csv\n")
cat("  GO_BP_significant_with_fold.csv, GO_MF_significant_with_fold.csv, GO_CC_significant_with_fold.csv\n")
cat("  NC_003197.2_GO_enrichment_bubble.pdf / .tiff / .png\n")
