setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")

ipr_cols <- c("Protein","MD5","SeqLen","Analysis","SigAccession",
              "SigDesc","Start","Stop","Score","Status",
              "Date","InterPro_ID","InterPro_Desc","GO","Pathways")

read_tsv <- function(f) read.delim(f, header=FALSE, sep="\t", quote="",
    stringsAsFactors=FALSE, col.names=ipr_cols, fill=TRUE)

report <- function(genome, tsv, pred_map, pred_totals) {
  tsv$SecType <- pred_map[tsv$Protein]
  has_ann <- tsv$Analysis != "-" & tsv$Analysis != "" & !is.na(tsv$Analysis)
  ann_prots  <- unique(tsv$Protein[has_ann])
  pfam_prots <- unique(tsv$Protein[tsv$Analysis == "Pfam"])
  cat(sprintf("\n========== %s ==========\n", genome))
  cat(sprintf("TSV unique proteins: %d | zero-hit '-' rows: %d\n",
      length(unique(tsv$Protein)), sum(!has_ann)))
  cat(sprintf("%-6s %8s %10s %6s %10s %6s\n",
      "Class","Total","Ann(any)","%","Ann(Pfam)","%"))
  for (st in c("T1SE","T2SE","T3SE","T4SE","T6SE")) {
    tot <- pred_totals[st]
    if (is.na(tot)) tot <- NA
    a <- length(unique(tsv$Protein[has_ann & tsv$SecType == st & !is.na(tsv$SecType)]))
    p <- length(unique(tsv$Protein[tsv$Analysis == "Pfam" & tsv$SecType == st & !is.na(tsv$SecType)]))
    pa <- if (is.na(tot)) "NA" else sprintf("%.0f", 100*a/tot)
    pp <- if (is.na(tot)) "NA" else sprintf("%.0f", 100*p/tot)
    cat(sprintf("%-6s %8s %10d %6s %10d %6s\n",
        st, if(is.na(tot)) "?" else tot, a, pa, p, pp))
  }
  cat(sprintf("TOTAL  %8s %10d        %10d\n",
      if(any(is.na(pred_totals))) "?" else sum(pred_totals, na.rm=TRUE),
      length(ann_prots), length(pfam_prots)))
  invisible(NULL)
}

# ---- NC_003197.2 (Salmonella) ----
pred3 <- read.csv("NC_003197.2_nonExp_predictions.csv", stringsAsFactors=FALSE)
tot3 <- table(pred3$predicted_class)
tsv3 <- do.call(rbind, lapply(
  list.files("NC_003197.2_InterPro_results", "\\.tsv$", full.names=TRUE), read_tsv))
map3 <- setNames(pred3$predicted_class, pred3$protein_id)
report("NC_003197.2 (Salmonella)", tsv3, map3, tot3)

# ---- NC_002942.5 (Legionella) ----
pred2 <- read.csv("NC_002942.5_T4SE/NC_002942.5_nonExp_predictions.csv", stringsAsFactors=FALSE)
tot2 <- table(pred2$predicted_class)
tsv2 <- do.call(rbind, lapply(
  list.files("NC_002942.5_InterPro_results", "\\.tsv$", full.names=TRUE), read_tsv))
map2 <- setNames(pred2$predicted_class, pred2$protein_id)
report("NC_002942.5 (Legionella)", tsv2, map2, tot2)

# ---- PAO1 (type parsed from Protein field) ----
tsvP <- do.call(rbind, lapply(
  list.files("INTERPRO/PAO", "\\.tsv$", full.names=TRUE), read_tsv))
tsvP$SecType <- sapply(tsvP$Protein, function(x) {
  m <- regmatches(x, regexpr("T[1-6]SE", x)); if (length(m) > 0) m else NA_character_ })
# class totals unknown locally -> use table over UNIQUE proteins parsed from TSV
# (zero-hit proteins absent from web TSV output, so these are annotated totals)
cat("\n========== PAO1 (parsed from TSV Protein field) ==========\n")
cat(sprintf("TSV unique proteins: %d | zero-hit '-' rows: %d\n",
    length(unique(tsvP$Protein)), sum(tsvP$Analysis == "-" | tsvP$Analysis == "")))
cat("(PAO1 submitted-total per class not in workspace; counts below = proteins WITH >=1 hit)\n")
cat(sprintf("%-6s %10s %10s\n", "Class", "Ann(any)", "Ann(Pfam)"))
for (st in c("T1SE","T2SE","T3SE","T4SE","T6SE")) {
  sub <- tsvP[tsvP$SecType == st & !is.na(tsvP$SecType), ]
  a <- length(unique(sub$Protein[sub$Analysis != "-" & sub$Analysis != "" & !is.na(sub$Analysis)]))
  p <- length(unique(sub$Protein[sub$Analysis == "Pfam"]))
  cat(sprintf("%-6s %10d %10d\n", st, a, p))
}
cat("Saved table: annotation_counts_by_category.csv\n")
