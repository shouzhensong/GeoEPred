from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "GO_nature_multipanel" / "Source_Data_panel_a_representative_terms.csv"
OUT = ROOT / "GO_compact_bubble_python"
OUT.mkdir(exist_ok=True)

SHORT_LABELS = {
    "GO:0042710": "biofilm formation",
    "GO:0033103": "type VI secretion",
    "GO:0009306": "protein secretion",
    "GO:0071806": "transmembrane protein transport",
    "GO:0015628": "type II secretion",
    "GO:0044419": "interspecies interaction",
    "GO:0030254": "type III secretion",
    "GO:0043952": "Sec-dependent protein transport",
    "GO:0016788": "ester-bond hydrolase activity",
    "GO:0008237": "metallopeptidase activity",
    "GO:0016298": "lipase activity",
    "GO:0004620": "phospholipase activity",
    "GO:1990404": "NAD+ ADP-ribosyltransferase",
    "GO:0042597": "periplasmic space",
    "GO:0009289": "pilus",
    "GO:0030257": "type III secretion complex",
    "GO:0005576": "extracellular region",
    "GO:0033104": "type VI secretion complex",
}

GROUP_ORDER = ["BP", "MF", "CC"]
GROUP_NAMES = {"BP": "BP", "MF": "MF", "CC": "CC"}

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "font.size": 7,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def prepare_data() -> pd.DataFrame:
    data = pd.read_csv(SOURCE)
    required = {"Ontology", "ID", "Description", "FoldEnrichment", "Count", "p.adjust", "NegLog10FDR"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Missing source-data columns: {sorted(missing)}")
    unknown = set(data["ID"]).difference(SHORT_LABELS)
    if unknown:
        raise ValueError(f"No short label defined for: {sorted(unknown)}")
    data["DisplayTerm"] = data["ID"].map(SHORT_LABELS)
    data["Ontology"] = pd.Categorical(data["Ontology"], GROUP_ORDER, ordered=True)
    data = data.sort_values(["Ontology", "FoldEnrichment"], ascending=[True, False], kind="stable")
    return data.reset_index(drop=True)


def bubble_size(count):
    # Area in pt^2. Kept deliberately small enough that adjacent rows never overlap.
    return 14 + np.asarray(count, dtype=float) * 1.8


def plot(data: pd.DataFrame) -> plt.Figure:
    # Compact three-column layout: facet strip, single-line terms, quantitative axis.
    fig = plt.figure(figsize=(86 / 25.4, 106 / 25.4))
    gs = fig.add_gridspec(1, 3, width_ratios=[0.42, 3.15, 1.65], wspace=0.025)
    ax_strip = fig.add_subplot(gs[0, 0])
    ax_label = fig.add_subplot(gs[0, 1])
    ax = fig.add_subplot(gs[0, 2])

    gap = 0.48
    records = []
    bounds = {}
    cursor = 0.0
    for ontology in GROUP_ORDER:
        subset = data[data["Ontology"] == ontology]
        start = cursor
        for _, row in subset.iterrows():
            records.append((cursor, row))
            cursor += 1.0
        bounds[ontology] = (start - 0.43, cursor - 0.57)
        cursor += gap

    y = np.array([item[0] for item in records])
    ordered = pd.DataFrame([item[1] for item in records]).reset_index(drop=True)
    x = ordered["FoldEnrichment"].to_numpy(float)
    counts = ordered["Count"].to_numpy(float)

    ax.hlines(y, 1.0, x, color="#D7E0E4", linewidth=1.15, zorder=1)
    ax.scatter(
        x,
        y,
        s=bubble_size(counts),
        color="#4B95C3",
        edgecolor="#19313D",
        linewidth=0.45,
        zorder=3,
    )

    xmin, xmax = 1.0, max(17.6, float(x.max()) + 0.7)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(-0.55, y.max() + 0.55)
    ax.invert_yaxis()
    ax.set_xticks([1, 5, 10, 15])
    ax.set_xlabel("Fold enrichment", fontsize=8, labelpad=4)
    ax.set_yticks([])
    ax.tick_params(axis="x", labelsize=7, width=0.7, length=3)
    ax.spines["left"].set_color("#9EADB4")
    ax.spines["left"].set_linestyle((0, (2, 3)))
    ax.spines["left"].set_linewidth(0.7)
    ax.spines["bottom"].set_color("#26343B")

    ax_label.set_xlim(0, 1)
    ax_label.set_ylim(ax.get_ylim())
    ax_label.axis("off")
    for yi, term in zip(y, ordered["DisplayTerm"]):
        ax_label.text(0.985, yi, term, ha="right", va="center", fontsize=5.8, color="#13242D")

    ax_strip.set_xlim(0, 1)
    ax_strip.set_ylim(ax.get_ylim())
    ax_strip.axis("off")
    for ontology in GROUP_ORDER:
        start, end = bounds[ontology]
        ax_strip.axhspan(start, end, xmin=0.08, xmax=0.94, color="#EAF0F2", ec="none")
        ax_strip.text(
            0.51,
            (start + end) / 2,
            GROUP_NAMES[ontology],
            ha="center",
            va="center",
            fontsize=7.5,
            fontweight="bold",
            color="#1A3850",
        )

    ax.set_title("Enriched GO terms", loc="left", fontsize=7.5, fontweight="bold", pad=8)

    legend_counts = [10, 30]
    handles = [
        ax.scatter([], [], s=bubble_size(v), facecolor="#4B95C3", edgecolor="#19313D", linewidth=0.45)
        for v in legend_counts
    ]
    leg = ax.legend(
        handles,
        [str(v) for v in legend_counts],
        title="Genes",
        loc="upper left",
        bbox_to_anchor=(0.02, -0.125),
        ncol=2,
        frameon=False,
        fontsize=6.5,
        title_fontsize=6.8,
        handletextpad=0.5,
        columnspacing=1.0,
        borderaxespad=0,
    )
    leg.get_title().set_fontweight("bold")

    fig.text(0.012, 0.975, "a", fontsize=9, fontweight="bold", va="top")
    fig.subplots_adjust(left=0.015, right=0.99, top=0.93, bottom=0.20)
    return fig


def main() -> None:
    data = prepare_data()
    data.to_csv(OUT / "Source_Data_GO_compact_bubble.csv", index=False, encoding="utf-8-sig")
    fig = plot(data)
    stem = OUT / "PAO1_GO_compact_bubble_half_axis_blue"
    fig.savefig(stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
