setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages(library(dplyr))

read_pfam <- function(dir, strain) {
  files <- list.files(dir, pattern="Pfam_enrich_.*\\.csv$", full.names=TRUE)
  do.call(rbind, lapply(files, function(f) {
    tab <- read.csv(f, stringsAsFactors=FALSE)
    if (!"SecType" %in% names(tab)) {
      tab$SecType <- gsub(".*Pfam_enrich_(.+)\\.csv$", "\\1", basename(f))
    }
    tab$Strain <- strain
    tab$Pfam_ID <- if("ID" %in% names(tab)) tab$ID else tab$term
    tab$Domain_Description <- tab$Description
    tab$Fold_Enrichment <- round(as.numeric(tab$FoldEnrichment), 2)
    tab$P_value <- formatC(as.numeric(tab$pvalue), format="e", digits=2)
    tab$P_adjust <- formatC(as.numeric(tab$p.adjust), format="e", digits=2)
    tab$Gene_Count <- tab$Count
    tab[, c("Strain","SecType","Pfam_ID","Domain_Description",
            "Fold_Enrichment","P_value","P_adjust","Gene_Count",
            "GeneRatio","BgRatio","geneID")]
  }))
}

pao1  <- read_pfam("PAO1_InterPro_results", "PAO1")
nc003 <- read_pfam("NC_003197.2_InterPro_results", "NC_003197.2")
nc002 <- read_pfam("NC_002942.5_InterPro_results", "NC_002942.5")

all <- rbind(pao1, nc003, nc002) %>%
  arrange(Strain, SecType, P_adjust)

write.csv(all, "InterPro_three_genomes_combined.csv", row.names=FALSE)

cat(sprintf("Total rows: %d\n", nrow(all)))
cat(sprintf("PAO1: %d | NC_003197.2: %d | NC_002942.5: %d\n",
    sum(all$Strain=="PAO1"), sum(all$Strain=="NC_003197.2"), sum(all$Strain=="NC_002942.5")))
cat("Columns: Strain, SecType, Pfam_ID, Domain_Description, Fold_Enrichment, P_value, P_adjust, Gene_Count, GeneRatio, BgRatio, geneID\n")
cat("Saved: InterPro_three_genomes_combined.csv\n")
