# ============================================================================
# GO富集分析 — NC_002942.5 (Legionella pneumophila Philadelphia-1)
# GO注释来源: QuickGO API (taxonId=272624)
# 候选集: NC_002942.5_T4SE/candidate_genes_effector.txt
# 背景集: NC_002942.5_T4SE/background_genes_all.txt
# ============================================================================

# 0. 环境设置 ================================================================
setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")

output_dir <- "NC_002942.5_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("clusterProfiler", quietly = TRUE)) BiocManager::install("clusterProfiler")
if (!requireNamespace("GO.db", quietly = TRUE)) BiocManager::install("GO.db")
if (!requireNamespace("enrichplot", quietly = TRUE)) BiocManager::install("enrichplot")
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
if (!requireNamespace("GOSemSim", quietly = TRUE)) BiocManager::install("GOSemSim")

library(clusterProfiler)
library(GO.db)
library(AnnotationDbi)
library(enrichplot)
library(ggplot2)
library(GOSemSim)

# 1. 加载候选基因和背景基因 =================================================
candidate_ids <- readLines("NC_002942.5_T4SE/candidate_genes_effector.txt", warn = FALSE)
background_ids <- readLines("NC_002942.5_T4SE/background_genes_all.txt", warn = FALSE)

candidate_ids <- unique(toupper(trimws(candidate_ids)))
candidate_ids <- candidate_ids[!is.na(candidate_ids) & candidate_ids != ""]

background_ids <- unique(toupper(trimws(background_ids)))
background_ids <- background_ids[!is.na(background_ids) & background_ids != ""]

cat("候选基因数:", length(candidate_ids), "\n")
cat("背景基因数:", length(background_ids), "\n")
cat("前5个候选:", head(candidate_ids, 5), "\n")

# 清理后缀
clean_candidates <- unique(sub("([LPGRS0-9_]+).*", "\\1", candidate_ids))
clean_background <- unique(sub("([LPGRS0-9_]+).*", "\\1", background_ids))

cat("清洗后候选基因数:", length(clean_candidates), "\n")
cat("清洗后背景基因数:", length(clean_background), "\n")
cat("候选不在背景中的数量:", length(setdiff(clean_candidates, clean_background)), "(应为0)\n")

# 2. 构建基因符号 → locus_tag 映射 ===========================================
# QuickGO GAF 使用基因符号 (speA, dnaA...)，需通过 features_.csv 映射到 LPG_RS
features <- read.csv("NC_002942.5_T4SE/features_.csv", stringsAsFactors = FALSE)

# 基因符号到 locus_tag 的映射
gene_to_locus <- list()
for (i in seq_len(nrow(features))) {
  g <- features$gene[i]
  lt <- features$locus_tag[i]
  if (!is.na(g) && nchar(g) > 0 && !is.na(lt)) {
    existing <- gene_to_locus[[toupper(g)]]
    if (is.null(existing)) {
      gene_to_locus[[toupper(g)]] <- lt
    }
  }
}
cat("gene -> locus_tag 映射数:", length(gene_to_locus), "\n")

# 也建立 protein_id 到 locus_tag 的直接映射 (WP_ 格式)
wp_to_locus <- setNames(features$locus_tag, features$protein_id)

# 3. 解析 QuickGO GAF 文件 ====================================================
cat("\n解析 QuickGO GAF...\n")
gaf_file <- file.path(output_dir, "LEGPN_QuickGO.gaf")
gaf_lines <- readLines(gaf_file, warn = FALSE)

# 跳过注释行 (!)
data_lines <- gaf_lines[!grepl("^!", gaf_lines)]
cat("注释行数:", length(data_lines), "\n")

# 解析 GAF 列 (标准 17 列)
parse_gaf <- function(lines) {
  parts_list <- strsplit(lines, "\t")
  data.frame(
    DB                  = sapply(parts_list, `[`, 1),
    DB_Object_ID        = sapply(parts_list, `[`, 2),
    DB_Object_Symbol    = sapply(parts_list, `[`, 3),
    Qualifier           = sapply(parts_list, `[`, 4),
    GO_ID               = sapply(parts_list, `[`, 5),
    DB_Reference        = sapply(parts_list, `[`, 6),
    Evidence_Code       = sapply(parts_list, `[`, 7),
    With_From           = sapply(parts_list, `[`, 8),
    Aspect              = sapply(parts_list, `[`, 9),
    DB_Object_Name      = sapply(parts_list, `[`, 10),
    DB_Object_Synonym   = sapply(parts_list, `[`, 11),
    DB_Object_Type      = sapply(parts_list, `[`, 12),
    Taxon               = sapply(parts_list, `[`, 13),
    Date                = sapply(parts_list, `[`, 14),
    Assigned_By         = sapply(parts_list, `[`, 15),
    Annotation_Extension = sapply(parts_list, `[`, 16),
    Gene_Product_Form_ID = sapply(parts_list, `[`, 17),
    stringsAsFactors    = FALSE
  )
}

lpn_gaf <- parse_gaf(data_lines)
cat("解析完成:", nrow(lpn_gaf), "行\n")

# 从 DB_Object_Symbol 映射到 LPG_RS locus_tag
map_symbol_to_locus <- function(symbols) {
  result <- character(length(symbols))
  for (i in seq_along(symbols)) {
    sym <- toupper(trimws(symbols[i]))
    if (!is.na(sym) && sym != "") {
      lt <- gene_to_locus[[sym]]
      if (!is.null(lt)) {
        result[i] <- lt
      } else {
        # 尝试部分匹配 (有些符号带后缀)
        lt <- gene_to_locus[[sub("_.*", "", sym)]]
        if (!is.null(lt)) {
          result[i] <- lt
        } else {
          result[i] <- NA_character_
        }
      }
    } else {
      result[i] <- NA_character_
    }
  }
  result
}

lpn_gaf$locus_tag <- map_symbol_to_locus(lpn_gaf$DB_Object_Symbol)

cat("成功映射到 locus_tag 的注释数:", sum(!is.na(lpn_gaf$locus_tag)), "/", nrow(lpn_gaf), "\n")
cat("唯一 locus_tag 数:", length(unique(na.omit(lpn_gaf$locus_tag))), "\n")

# 4. 筛选正向注释 ============================================================
qualifier_text <- ifelse(is.na(lpn_gaf$Qualifier), "", lpn_gaf$Qualifier)
is_not_annotation <- grepl("(^|\\|)NOT($|\\|)", qualifier_text, ignore.case = TRUE)

lpn_gaf_positive <- lpn_gaf[
  !is_not_annotation &
    !is.na(lpn_gaf$locus_tag) &
    lpn_gaf$locus_tag != "" &
    grepl("^GO:[0-9]{7}$", lpn_gaf$GO_ID) &
    lpn_gaf$Aspect %in% c("P", "F", "C"),
  c("locus_tag", "GO_ID", "Aspect", "Evidence_Code", "DB_Object_ID", "DB_Object_Symbol"),
  drop = FALSE
]

lpn_gaf_positive <- unique(lpn_gaf_positive)
cat("正向注释数:", nrow(lpn_gaf_positive), "\n")
cat("分支分布:\n")
print(table(lpn_gaf_positive$Aspect))
cat("注释到的唯一 locus_tag:", length(unique(lpn_gaf_positive$locus_tag)), "\n")

# 5. 映射统计 ================================================================
annotated_locus_tags <- unique(lpn_gaf_positive$locus_tag)

candidate_mapped <- intersect(clean_candidates, annotated_locus_tags)
background_mapped <- intersect(clean_background, annotated_locus_tags)
candidate_unmapped <- setdiff(clean_candidates, annotated_locus_tags)
background_unmapped <- setdiff(clean_background, annotated_locus_tags)

mapping_summary <- data.frame(
  Dataset    = c("Candidate", "Background"),
  Total      = c(length(clean_candidates), length(clean_background)),
  GO_mapped  = c(length(candidate_mapped), length(background_mapped)),
  GO_unmapped = c(length(candidate_unmapped), length(background_unmapped))
)
mapping_summary$Mapping_rate_percent <- round(100 * mapping_summary$GO_mapped / mapping_summary$Total, 2)
print(mapping_summary)

# 分本体论统计
aspect_codes <- c(BP = "P", MF = "F", CC = "C")
aspect_mapping_summary <- do.call(rbind, lapply(names(aspect_codes), function(ontology_name) {
  aspect_code <- aspect_codes[ontology_name]
  aspect_genes <- unique(lpn_gaf_positive$locus_tag[lpn_gaf_positive$Aspect == aspect_code])
  data.frame(
    Ontology          = ontology_name,
    Candidate_total   = length(clean_candidates),
    Candidate_mapped  = length(intersect(clean_candidates, aspect_genes)),
    Background_total  = length(clean_background),
    Background_mapped = length(intersect(clean_background, aspect_genes))
  )
}))
aspect_mapping_summary$Candidate_rate_percent  <- round(100 * aspect_mapping_summary$Candidate_mapped  / aspect_mapping_summary$Candidate_total,  2)
aspect_mapping_summary$Background_rate_percent <- round(100 * aspect_mapping_summary$Background_mapped / aspect_mapping_summary$Background_total, 2)
rownames(aspect_mapping_summary) <- NULL
print(aspect_mapping_summary)

# 6. 构建直接 GO 映射表 ======================================================
go_direct_mapping <- unique(
  lpn_gaf_positive[, c("GO_ID", "locus_tag", "Aspect")]
)
cat("直接 GO 映射行数:", nrow(go_direct_mapping), "\n")

# 7. 构建 term2gene 和 term2name =============================================
build_term2gene <- function(direct_mapping, aspect_code) {
  direct_subset <- unique(
    direct_mapping[direct_mapping$Aspect == aspect_code, c("GO_ID", "locus_tag"), drop = FALSE]
  )
  colnames(direct_subset) <- c("direct_term", "gene")

  ancestor_database <- switch(
    aspect_code,
    P = GO.db::GOBPANCESTOR,
    F = GO.db::GOMFANCESTOR,
    C = GO.db::GOCCANCESTOR,
    stop("aspect_code必须是P、F或C")
  )

  ancestor_list <- as.list(ancestor_database)
  direct_terms  <- unique(direct_subset$direct_term)

  expansion_list <- lapply(direct_terms, function(current_term) {
    ancestors <- ancestor_list[[current_term]]
    if (is.null(ancestors)) ancestors <- character(0)
    ancestors <- ancestors[!is.na(ancestors)]
    data.frame(
      direct_term = current_term,
      term        = unique(c(current_term, ancestors)),
      stringsAsFactors = FALSE
    )
  })

  term_expansion   <- do.call(rbind, expansion_list)
  expanded_mapping <- merge(direct_subset, term_expansion, by = "direct_term", all.x = TRUE)

  result <- unique(expanded_mapping[, c("term", "gene")])
  result <- result[!is.na(result$term) & result$term != "" &
                   !is.na(result$gene) & result$gene != "", , drop = FALSE]
  rownames(result) <- NULL
  return(result)
}

build_term2name <- function(term2gene, ontology_code) {
  go_ids <- unique(term2gene$term)
  go_information <- AnnotationDbi::select(
    GO.db::GO.db, keys = go_ids, keytype = "GOID",
    columns = c("TERM", "ONTOLOGY")
  )
  go_information <- go_information[
    !is.na(go_information$TERM) & go_information$ONTOLOGY == ontology_code,
    , drop = FALSE
  ]
  term2name <- unique(data.frame(
    term = go_information$GOID,
    name = go_information$TERM,
    stringsAsFactors = FALSE
  ))
  rownames(term2name) <- NULL
  return(term2name)
}

term2gene_bp <- build_term2gene(go_direct_mapping, "P")
term2gene_mf <- build_term2gene(go_direct_mapping, "F")
term2gene_cc <- build_term2gene(go_direct_mapping, "C")

term2name_bp <- build_term2name(term2gene_bp, "BP")
term2name_mf <- build_term2name(term2gene_mf, "MF")
term2name_cc <- build_term2name(term2gene_cc, "CC")

cat("term2gene 维度: BP", dim(term2gene_bp), "MF", dim(term2gene_mf), "CC", dim(term2gene_cc), "\n")
cat("term2name 维度: BP", dim(term2name_bp), "MF", dim(term2name_mf), "CC", dim(term2name_cc), "\n")

# 8. 运行 GO 富集分析 ========================================================
run_go_enrichment <- function(candidate_ids, background_ids, term2gene, term2name) {
  clusterProfiler::enricher(
    gene          = candidate_ids,
    universe      = background_ids,
    TERM2GENE     = term2gene,
    TERM2NAME     = term2name,
    pAdjustMethod = "BH",
    pvalueCutoff  = 1,
    qvalueCutoff  = 1,
    minGSSize     = 5,
    maxGSSize     = 500
  )
}

go_bp_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_bp, term2name_bp)
go_mf_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_mf, term2name_mf)
go_cc_result <- run_go_enrichment(clean_candidates, clean_background, term2gene_cc, term2name_cc)

go_bp_table <- as.data.frame(go_bp_result)
go_mf_table <- as.data.frame(go_mf_result)
go_cc_table <- as.data.frame(go_cc_result)

go_bp_table <- go_bp_table[order(go_bp_table$p.adjust, go_bp_table$pvalue), ]
go_mf_table <- go_mf_table[order(go_mf_table$p.adjust, go_mf_table$pvalue), ]
go_cc_table <- go_cc_table[order(go_cc_table$p.adjust, go_cc_table$pvalue), ]

cat("全部分析结果: BP", nrow(go_bp_table), "MF", nrow(go_mf_table), "CC", nrow(go_cc_table), "\n")

# 9. 筛选显著条目 ============================================================
select_significant <- function(result_table) {
  result_table[
    !is.na(result_table$p.adjust) & result_table$p.adjust < 0.05 &
    !is.na(result_table$qvalue)  & result_table$qvalue  < 0.20,
    , drop = FALSE
  ]
}

go_bp_significant <- select_significant(go_bp_table)
go_mf_significant <- select_significant(go_mf_table)
go_cc_significant <- select_significant(go_cc_table)

cat("显著条目: BP", nrow(go_bp_significant), "MF", nrow(go_mf_significant), "CC", nrow(go_cc_significant), "\n")

# 10. 导出基础 CSV ===========================================================
write.csv(go_bp_table, file.path(output_dir, "GO_BP_all_results.csv"), row.names = FALSE)
write.csv(go_mf_table, file.path(output_dir, "GO_MF_all_results.csv"), row.names = FALSE)
write.csv(go_cc_table, file.path(output_dir, "GO_CC_all_results.csv"), row.names = FALSE)

write.csv(go_bp_significant, file.path(output_dir, "GO_BP_significant.csv"), row.names = FALSE)
write.csv(go_mf_significant, file.path(output_dir, "GO_MF_significant.csv"), row.names = FALSE)
write.csv(go_cc_significant, file.path(output_dir, "GO_CC_significant.csv"), row.names = FALSE)

cat("基础结果已导出\n")

# 11. 添加 Fold Enrichment 并导出 ============================================
parse_ratio <- function(ratio_vector) {
  vapply(strsplit(as.character(ratio_vector), "/", fixed = TRUE),
         function(parts) as.numeric(parts[1]) / as.numeric(parts[2]),
         numeric(1))
}

add_enrichment_metrics <- function(result_table) {
  if (nrow(result_table) == 0) return(result_table)
  result_table$GeneRatio_numeric <- parse_ratio(result_table$GeneRatio)
  result_table$BgRatio_numeric    <- parse_ratio(result_table$BgRatio)
  result_table$FoldEnrichment     <- result_table$GeneRatio_numeric / result_table$BgRatio_numeric
  result_table <- result_table[order(result_table$p.adjust, -result_table$FoldEnrichment), ]
  rownames(result_table) <- NULL
  result_table
}

go_bp_significant <- add_enrichment_metrics(go_bp_significant)
go_mf_significant <- add_enrichment_metrics(go_mf_significant)
go_cc_significant <- add_enrichment_metrics(go_cc_significant)

write.csv(go_bp_significant, file.path(output_dir, "GO_BP_significant_with_fold.csv"), row.names = FALSE)
write.csv(go_mf_significant, file.path(output_dir, "GO_MF_significant_with_fold.csv"), row.names = FALSE)
write.csv(go_cc_significant, file.path(output_dir, "GO_CC_significant_with_fold.csv"), row.names = FALSE)

cat("含Fold Enrichment的显著结果已导出\n")
cat("输出文件夹:", output_dir, "\n")
