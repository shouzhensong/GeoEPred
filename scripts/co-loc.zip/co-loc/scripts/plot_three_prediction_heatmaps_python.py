from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "prediction_heatmaps_python"
OUT.mkdir(exist_ok=True)

ROWS = ["Non-effector", "T1SE", "T2SE", "T3SE", "T4SE", "T6SE"]

PANELS = {
    "T3SE": {
        "columns": ["GeoEPred", "DeepSecE", "MoCETSE", "T3SEpp", "Bastion3", "BastionX"],
        "xlabel": "Predicted T3SEs",
        "colors": ["#F1F4F6", "#9FC0DA", "#4B95C3"],
        "values": np.array(
            [
                [0, 4, 4, np.nan, 8, 14],
                [0, np.nan, np.nan, np.nan, 9, 12],
                [1, np.nan, np.nan, np.nan, np.nan, 2],
                [28, 28, 29, 21, 30, 30],
                [1, 1, np.nan, 3, 12, 30],
                [np.nan, 2, 2, np.nan, np.nan, 9],
            ]
        ),
    },
    "T4SE": {
        "columns": ["GeoEPred", "DeepSecE", "MoCETSE", "Bastion4", "BastionX", "T4SEfinder", "T4SEpp"],
        "xlabel": "Predicted T4SEs",
        "colors": ["#F0F5F4", "#A7D3CF", "#5BB6B1"],
        "values": np.array(
            [
                [3, 3, 6, 6, 15, 4, np.nan],
                [np.nan, np.nan, np.nan, 1, 9, 6, 2],
                [np.nan, 1, np.nan, np.nan, 2, np.nan, np.nan],
                [1, 1, np.nan, 3, 26, 21, 4],
                [29, 29, 30, 29, 30, 28, 30],
                [np.nan, np.nan, np.nan, np.nan, 8, 7, 2],
            ]
        ),
    },
    "T6SE": {
        "columns": ["GeoEPred", "DeepSecE", "MoCETSE", "Bastion6", "BastionX"],
        "xlabel": "Predicted T6SEs",
        "colors": ["#F3F1F5", "#BDB2CF", "#8D7CAF"],
        "values": np.array(
            [
                [2, 1, np.nan, 12, 20],
                [np.nan, 1, 1, 11, 17],
                [np.nan, np.nan, np.nan, 4, np.nan],
                [np.nan, np.nan, np.nan, 16, 14],
                [np.nan, np.nan, np.nan, 20, 3],
                [20, 17, 18, 19, 20],
            ]
        ),
    },
}

mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.labelweight": "normal",
        "axes.titleweight": "normal",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def draw_panel(ax, name, panel, show_ylabels):
    values = panel["values"]
    cmap = LinearSegmentedColormap.from_list(f"{name}_map", panel["colors"])
    cmap.set_bad("white")
    norm = Normalize(vmin=0, vmax=30)
    ax.imshow(np.ma.masked_invalid(values), cmap=cmap, norm=norm, interpolation="nearest", aspect="equal")

    ax.set_xticks(np.arange(values.shape[1]))
    ax.set_xticklabels(
        panel["columns"], rotation=45, ha="left", rotation_mode="anchor",
        fontsize=6.2, fontfamily="Arial", fontweight="normal"
    )
    ax.xaxis.tick_top()
    ax.tick_params(axis="x", top=True, bottom=False, length=0, pad=4)

    ax.set_yticks(np.arange(values.shape[0]))
    if show_ylabels:
        ax.set_yticklabels(ROWS, fontsize=6.5, fontfamily="Arial", fontweight="normal")
    else:
        ax.set_yticklabels([])
    ax.tick_params(axis="y", length=0, pad=3)

    ax.set_xlabel(panel["xlabel"], fontsize=7.2, fontfamily="Arial", fontweight="normal", labelpad=3)

    ax.set_xticks(np.arange(-0.5, values.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, values.shape[0], 1), minor=True)
    ax.grid(which="minor", color="#D8DDE0", linewidth=0.45)
    ax.tick_params(which="minor", bottom=False, left=False)
    for spine in ax.spines.values():
        spine.set_linewidth(0.55)
        spine.set_color("#B4BCC0")

    for row in range(values.shape[0]):
        for col in range(values.shape[1]):
            raw_value = values[row, col]
            if np.isnan(raw_value):
                continue
            value = int(raw_value)
            ax.text(
                col,
                row,
                str(value),
                ha="center",
                va="center",
                fontsize=6.3,
                fontfamily="Arial",
                fontweight="normal",
                color="white" if value >= 16 else "#303A3F",
            )


def main():
    fig = plt.figure(figsize=(183 / 25.4, 74 / 25.4))
    grid = fig.add_gridspec(
        1,
        3,
        width_ratios=[6, 7, 5],
        wspace=0.18,
        left=0.105,
        right=0.985,
        top=0.78,
        bottom=0.13,
    )

    for index, (name, panel) in enumerate(PANELS.items()):
        ax = fig.add_subplot(grid[0, index])
        draw_panel(ax, name, panel, show_ylabels=index == 0)
        pd.DataFrame(panel["values"], index=ROWS, columns=panel["columns"]).to_csv(
            OUT / f"Source_Data_{name}.csv", encoding="utf-8-sig"
        )

    stem = OUT / "T3SE_T4SE_T6SE_prediction_heatmaps_updated_data"
    fig.savefig(f"{stem}.png", dpi=300, facecolor="white")
    fig.savefig(f"{stem}.svg", facecolor="white")
    fig.savefig(f"{stem}.pdf", facecolor="white")
    fig.savefig(f"{stem}.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
