"""Draw cumulative inference time from an editable prediction-time CSV."""

import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# -----------------------------------------------------------------------------
# Editable input settings
# -----------------------------------------------------------------------------
INPUT_CSV = Path("running_time_figure/PAO1_predictions_time.csv")
TIME_COLUMN = "prediction_time_ms"
CHECKPOINT_INTERVAL = 1000

OUTPUT_DIR = Path("running_time_figure")
OUTPUT_NAME = "running_time_vs_protein_count"


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.labelweight": "normal",
        "axes.titleweight": "normal",
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.major.size": 3.0,
        "ytick.major.size": 3.0,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def load_cumulative_data(
    input_csv: Path, requested_checkpoints: list[int] | None = None
) -> pd.DataFrame:
    """Return cumulative elapsed time at regular protein-count checkpoints."""
    raw = pd.read_csv(input_csv)
    if TIME_COLUMN not in raw.columns:
        raise KeyError(f"Required column not found: {TIME_COLUMN}")

    times_ms = pd.to_numeric(raw[TIME_COLUMN], errors="coerce")
    if times_ms.isna().any() or (times_ms < 0).any():
        raise ValueError(f"{TIME_COLUMN} must contain non-negative numeric values")

    cumulative_seconds = times_ms.cumsum().to_numpy() / 1000.0
    total_count = len(raw)
    checkpoints = (
        [n for n in requested_checkpoints if 0 < n <= total_count]
        if requested_checkpoints
        else list(range(CHECKPOINT_INTERVAL, total_count + 1, CHECKPOINT_INTERVAL))
    )
    if requested_checkpoints:
        # Add the true dataset endpoint only when the requested range extends
        # beyond the available rows; never extrapolate a missing checkpoint.
        if total_count < max(requested_checkpoints) and (
            not checkpoints or checkpoints[-1] != total_count
        ):
            checkpoints.append(total_count)
    elif not checkpoints or checkpoints[-1] != total_count:
        checkpoints.append(total_count)

    return pd.DataFrame(
        {
            "Protein count": checkpoints,
            "Running time (s)": [cumulative_seconds[n - 1] for n in checkpoints],
        }
    )


def build_figure(
    data: pd.DataFrame,
    x_ticks: list[int] | None = None,
    y_ticks: list[float] | None = None,
) -> plt.Figure:
    """Create the compact single-panel trend plot."""
    fig, ax = plt.subplots(figsize=(65 / 25.4, 58 / 25.4))

    orange = "#D86B16"
    pale_orange = "#F3D8C3"

    ax.plot(
        data["Protein count"],
        data["Running time (s)"],
        color=pale_orange,
        linewidth=2.0,
        zorder=1,
    )
    ax.scatter(
        data["Protein count"],
        data["Running time (s)"],
        s=38,
        facecolor=orange,
        edgecolor="#F5C69F",
        linewidth=1.0,
        zorder=2,
    )

    max_count = float(data["Protein count"].max())
    max_time = float(data["Running time (s)"].max())
    x_upper = np.ceil(max_count / 1000) * 1000
    y_upper = np.ceil(max_time / 10) * 10
    ax.set_xlim(0, x_upper * 1.025)
    ax.set_ylim(0, y_upper)
    if x_ticks:
        stagger_labels = len(x_ticks) > 1 and min(np.diff(sorted(x_ticks))) < 300
        ax.set_xticks(x_ticks)
        ax.set_xticklabels([])
        for i, tick in enumerate(x_ticks):
            # Stagger dense early-count labels while preserving a linear axis.
            y_pos = (-0.055 if i % 2 == 0 else -0.105) if stagger_labels else -0.055
            ax.text(
                tick,
                y_pos,
                f"{tick}",
                transform=ax.get_xaxis_transform(),
                ha="center",
                va="top",
                fontsize=6.5,
                fontweight="normal",
                color="#333333",
                clip_on=False,
            )
    else:
        ax.set_xticks(np.arange(0, x_upper + 1, 1000))
    ax.set_yticks(y_ticks if y_ticks else np.arange(0, y_upper + 1, 10))
    ax.set_xlabel(
        "Protein count",
        fontsize=10,
        labelpad=20 if x_ticks and stagger_labels else (12 if x_ticks else 6),
    )
    ax.set_ylabel("Running time (s)", fontsize=10, labelpad=6)
    ax.tick_params(axis="both", labelsize=7.5, colors="#333333")
    ax.spines["left"].set_color("#333333")
    ax.spines["bottom"].set_color("#333333")
    ax.margins(x=0)

    fig.subplots_adjust(
        left=0.22,
        right=0.97,
        bottom=0.29 if x_ticks and stagger_labels else 0.25,
        top=0.96,
    )
    return fig


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=INPUT_CSV)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--output-name", default=OUTPUT_NAME)
    parser.add_argument(
        "--checkpoints",
        default="",
        help="Comma-separated protein counts, for example 100,300,500,1000",
    )
    parser.add_argument(
        "--y-ticks",
        default="",
        help="Comma-separated y-axis ticks, for example 1,2,3,4,5",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_stem = args.output_dir / args.output_name
    requested = (
        [int(value.strip()) for value in args.checkpoints.split(",") if value.strip()]
        if args.checkpoints
        else None
    )
    requested_y_ticks = (
        [float(value.strip()) for value in args.y_ticks.split(",") if value.strip()]
        if args.y_ticks
        else None
    )
    data = load_cumulative_data(args.input, requested)
    data.to_csv(
        args.output_dir / f"Source_Data_{args.output_name}.csv", index=False
    )

    fig = build_figure(data, requested, requested_y_ticks)
    fig.savefig(output_stem.with_suffix(".png"), dpi=600, facecolor="white")
    fig.savefig(output_stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(output_stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(
        output_stem.with_suffix(".tiff"),
        dpi=600,
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


if __name__ == "__main__":
    main()
