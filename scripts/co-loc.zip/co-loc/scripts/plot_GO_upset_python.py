from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "GO_nature_multipanel" / "Source_Data_panel_c_intersections.csv"
OUT = ROOT / "GO_upset_python"
OUT.mkdir(exist_ok=True)

ACCENT = "#4B95C3"
EMPTY = "#E9EEF0"
EDGE = "#5E7079"
ROWS = [("BP", "B"), ("MF", "M"), ("CC", "C")]

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "font.size": 7,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def load_data() -> pd.DataFrame:
    data = pd.read_csv(SOURCE).sort_values("X", kind="stable")
    required = {"Combination", "Genes", "X"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    return data


def plot(data: pd.DataFrame) -> plt.Figure:
    fig = plt.figure(figsize=(89 / 25.4, 94 / 25.4))
    gs = fig.add_gridspec(2, 1, height_ratios=[3.35, 1.10], hspace=0.0)
    ax_bar = fig.add_subplot(gs[0])
    ax_mat = fig.add_subplot(gs[1], sharex=ax_bar)

    x = data["X"].to_numpy()
    genes = data["Genes"].to_numpy()
    ax_bar.bar(x, genes, width=0.62, color=ACCENT, edgecolor="none", zorder=2)
    for xi, value in zip(x, genes):
        ax_bar.text(xi, value + 0.65, str(int(value)), ha="center", va="bottom", fontsize=7, color="#152832")

    ax_bar.set_ylim(0, 37)
    ax_bar.set_yticks([0, 10, 20, 30])
    ax_bar.set_ylabel("Genes", fontsize=7.5, labelpad=5)
    ax_bar.tick_params(axis="y", labelsize=7, width=0.7, length=3)
    ax_bar.tick_params(axis="x", bottom=False, labelbottom=False)
    ax_bar.spines["left"].set_color("#26343B")
    ax_bar.spines["bottom"].set_color("#26343B")

    row_y = {"B": 2, "M": 1, "C": 0}
    for xi, combination in zip(x, data["Combination"]):
        active_y = [row_y[code] for code in "BMC" if code in combination]
        if len(active_y) > 1:
            ax_mat.plot([xi, xi], [min(active_y), max(active_y)], color=ACCENT, linewidth=1.2, zorder=1)
        for _, code in ROWS:
            active = code in combination
            ax_mat.scatter(
                xi,
                row_y[code],
                s=47,
                facecolor=ACCENT if active else EMPTY,
                edgecolor=EDGE,
                linewidth=0.5,
                zorder=2,
            )

    ax_mat.set_ylim(-0.5, 2.5)
    ax_mat.set_yticks([2, 1, 0])
    # Explicit regular font weight, as requested.
    ax_mat.set_yticklabels(["BP", "MF", "CC"], fontsize=7.5, fontweight="normal")
    ax_mat.set_xticks([])
    ax_mat.tick_params(axis="y", width=0, length=0, pad=4)
    for spine in ax_mat.spines.values():
        spine.set_visible(False)

    ax_bar.set_xlim(0.4, float(x.max()) + 0.6)
    fig.subplots_adjust(left=0.16, right=0.98, top=0.96, bottom=0.08)
    return fig


def main() -> None:
    data = load_data()
    data.to_csv(OUT / "Source_Data_GO_upset.csv", index=False, encoding="utf-8-sig")
    fig = plot(data)
    stem = OUT / "PAO1_GO_upset_blue"
    fig.savefig(stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
