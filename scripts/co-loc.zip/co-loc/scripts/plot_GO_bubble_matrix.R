setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(scales)
  library(ragg)
})

output_dir <- "Nature_GO_bubble"
if (!dir.exists(output_dir)) dir.create(output_dir)

sec_levels <- c("T1SE", "T2SE", "T3SE", "T4SE", "T6SE")
ontology_levels <- c("BP", "MF", "CC")

# =========================================================================
# Template theme
# =========================================================================
theme_template <- theme_minimal(base_size = 8) +
  theme(
    panel.grid = element_blank(),
    axis.title.x = element_text(size = 8, colour = "black", margin = margin(t = 7)),
    axis.text.x = element_text(size = 7.5, colour = "black", margin = margin(t = 3)),
    axis.text.y = element_text(size = 6.5, colour = "black", lineheight = 0.9, margin = margin(r = 4)),
    axis.ticks = element_blank(),
    legend.position = "right",
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 6),
    plot.tag = element_text(size = 10, face = "bold", colour = "black"),
    plot.tag.position = c(0, 1),
    plot.margin = margin(t = 5, r = 4, b = 3, l = 3)
  )

# =========================================================================
# Helper: build gene→secretion type lookup from protein IDs
# =========================================================================
build_prot_to_type <- function(mapping_source, strain) {
  if (strain == "NC_003197.2") {
    pred <- read.csv("NC_003197.2_nonExp_predictions.csv", stringsAsFactors = FALSE)
    setNames(pred$predicted_class, pred$protein_id)
  } else if (strain == "PAO1") {
    # PAO1 secretion type from InterPro TSV metadata
    ipr_files <- list.files("INTERPRO/PAO", pattern = "\\.tsv$", full.names = TRUE)
    all_ids <- c()
    all_types <- c()
    for (f in ipr_files) {
      first_col <- read.delim(f, header = FALSE, sep = "\t", quote = "",
                              stringsAsFactors = FALSE)[, 1]
      for (x in first_col) {
        np <- regmatches(x, regexpr("NP_[0-9]+\\.[0-9]+", x))
        st <- regmatches(x, regexpr("T[1-6]SE", x))
        if (length(np) > 0 && length(st) > 0) {
          all_ids <- c(all_ids, np)
          all_types <- c(all_types, st)
        }
      }
    }
    # Deduplicate: keep first occurrence
    df <- unique(data.frame(id = all_ids, type = all_types, stringsAsFactors = FALSE))
    df <- df[!duplicated(df$id), ]
    setNames(df$type, df$id)
  } else if (strain == "NC_002942.5") {
    pred <- read.csv("NC_002942.5_T4SE/NC_002942.5_nonExp_predictions.csv",
                     stringsAsFactors = FALSE)
    setNames(pred$predicted_class, pred$protein_id)
  } else {
    character(0)
  }
}

# =========================================================================
# Main builder
# =========================================================================
build_bubble <- function(strain, go_prefix, features_file, tag) {
  cat(sprintf("\n===== %s =====\n", strain))

  go_bp <- read.csv(paste0(go_prefix, "BP_significant_with_fold.csv"), stringsAsFactors = FALSE)
  go_mf <- read.csv(paste0(go_prefix, "MF_significant_with_fold.csv"), stringsAsFactors = FALSE)
  go_cc <- read.csv(paste0(go_prefix, "CC_significant_with_fold.csv"), stringsAsFactors = FALSE)

  if (nrow(go_bp) == 0 && nrow(go_mf) == 0 && nrow(go_cc) == 0) {
    cat("  No significant GO terms\n")
    return(NULL)
  }

  go_bp$Ontology <- "BP"; go_mf$Ontology <- "MF"; go_cc$Ontology <- "CC"
  go_all <- rbind(go_bp, go_mf, go_cc)
  go_all$Ontology <- factor(go_all$Ontology, levels = ontology_levels)

  cat(sprintf("  BP:%d MF:%d CC:%d significant\n", nrow(go_bp), nrow(go_mf), nrow(go_cc)))

  prot_to_type <- build_prot_to_type(NULL, strain)

  feat <- read.csv(features_file, stringsAsFactors = FALSE)
  locus_to_prot <- setNames(feat$protein_id, feat$locus_tag)

  # Build GO term × secretion type matrix
  rows <- list()
  for (i in seq_len(nrow(go_all))) {
    genes <- trimws(strsplit(go_all$geneID[i], "/")[[1]])
    prots <- na.omit(sapply(genes, function(g) locus_to_prot[[g]]))
    names(prots) <- NULL
    types <- prot_to_type[prots]
    types <- types[!is.na(types)]
    if (length(types) == 0) next
    tc <- table(types)
    for (st in names(tc)) {
      if (st %in% sec_levels && tc[st] > 0) {
        rows[[length(rows) + 1]] <- data.frame(
          GO_ID = go_all$ID[i], GO_Desc = go_all$Description[i],
          Ontology = go_all$Ontology[i], SecType = st,
          GeneCount = as.integer(tc[st]),
          FoldEnrich = go_all$FoldEnrichment[i],
          p.adjust = go_all$p.adjust[i], stringsAsFactors = FALSE
        )
      }
    }
  }

  mat <- do.call(rbind, rows)
  if (is.null(mat) || nrow(mat) == 0) { cat("  No data\n"); return(NULL) }

  # Only keep GO terms that actually have genes from at least 2 secretion types
  # and remove empty/irrelevant rows
  term_coverage <- mat %>%
    group_by(GO_ID) %>%
    summarise(n_types = n_distinct(SecType), total_genes = sum(GeneCount), .groups = "drop")

  # Keep terms with genes from >= 1 secretion type, and at least 3 total genes
  active_terms <- term_coverage %>%
    filter(n_types >= 1 & total_genes >= 3) %>%
    pull(GO_ID)

  # Per ontology, keep top 6 by p.adjust
  top_per_ont <- go_all %>%
    filter(ID %in% active_terms) %>%
    group_by(Ontology) %>%
    slice_min(p.adjust, n = 6) %>%
    pull(ID)

  mat <- mat[mat$GO_ID %in% top_per_ont, ]
  if (nrow(mat) == 0) { cat("  No enriched terms to show\n"); return(NULL) }

  mat$GO_Label <- sapply(mat$GO_Desc, function(d) paste(strwrap(d, 38), collapse = "\n"))
  term_order <- go_all %>% filter(ID %in% unique(mat$GO_ID)) %>%
    arrange(Ontology, p.adjust) %>% pull(ID)
  mat$GO_ID <- factor(mat$GO_ID, levels = rev(term_order))

  # Drop secretion types with zero genes across all remaining terms
  type_totals <- mat %>% group_by(SecType) %>%
    summarise(total = sum(GeneCount), .groups = "drop")
  active_types <- type_totals$SecType[type_totals$total > 0]
  mat <- mat[mat$SecType %in% active_types, ]
  mat$SecType <- factor(mat$SecType, levels = intersect(sec_levels, active_types))

  max_count <- max(mat$GeneCount, 1)

  p <- ggplot(mat, aes(x = SecType, y = GO_ID)) +
    geom_vline(xintercept = seq_along(sec_levels), colour = "#D9D9D9", linewidth = 0.28) +
    geom_hline(yintercept = seq_along(levels(mat$GO_ID)), colour = "#D9D9D9", linewidth = 0.28) +
    geom_point(aes(size = GeneCount, fill = GeneCount),
               shape = 21, colour = "#D5E0E8", stroke = 0.15) +
    scale_size_continuous(range = c(2.0, 9.0), limits = c(0, max_count), guide = "none") +
    scale_fill_gradientn(
      colours = c("#F4F8FC", "#DCEAF4", "#9ECAE1", "#4292C6", "#08519C", "#082B59"),
      limits = c(0, max_count), breaks = pretty_breaks(n = 5),
      name = "Genes",
      guide = guide_colourbar(title.position = "top", title.hjust = 0,
        barwidth = grid::unit(5, "pt"), barheight = grid::unit(65, "pt"),
        frame.colour = NA, ticks.colour = "#333333")
    ) +
    scale_x_discrete(drop = FALSE) +
    scale_y_discrete(drop = FALSE,
      labels = setNames(sapply(levels(mat$GO_ID), function(id) mat$GO_Label[mat$GO_ID == id][1]),
                        levels(mat$GO_ID))) +
    facet_grid(Ontology ~ ., scales = "free_y", space = "free_y", switch = "y") +
    labs(x = "Type of secreted protein", y = NULL, title = strain, tag = tag) +
    coord_cartesian(clip = "off") + theme_template +
    theme(
      strip.placement = "outside",
      strip.background = element_rect(fill = "#F0F3F5", colour = NA),
      strip.text.y.left = element_text(size = 7, face = "bold", colour = "#203040"),
      panel.spacing.y = unit(3, "pt"),
      plot.title = element_text(size = 9, face = "bold.italic", colour = "#203040", margin = margin(b = 4))
    )

  n_rows <- length(unique(mat$GO_ID))
  n_types <- length(unique(mat$SecType))
  fig_h <- max(4.5, n_rows * 0.35 + 1.5)
  fig_w <- max(5, n_types * 0.9 + 2.5)

  ggsave(file.path(output_dir, paste0(strain, "_GO_bubble.pdf")), p,
         width = fig_w, height = fig_h, device = "pdf", bg = "white")
  ggsave(file.path(output_dir, paste0(strain, "_GO_bubble.png")), p,
         width = fig_w, height = fig_h, dpi = 300, bg = "white")
  cat(sprintf("  Saved (%d rows × %d cols, %.1f×%.1f in)\n", n_rows, n_types, fig_w, fig_h))
  return(p)
}

# =========================================================================
# Run for NC_003197.2 — full per-type GO bubble matrix
# =========================================================================
p1 <- build_bubble("NC_003197.2", "NC_003197.2_results/GO_", "features_.csv", "a")

cat("\n===== PAO1 =====\n")
cat("  PAO1 GO uses PA locus tags; secretion type labels not available for gene-level breakdown\n")

cat("\n===== NC_002942.5 =====\n")
cat("  GO enrichment: 0 significant terms — cannot plot\n")

cat("\n===== Done =====\nOutput:", output_dir, "\n")
