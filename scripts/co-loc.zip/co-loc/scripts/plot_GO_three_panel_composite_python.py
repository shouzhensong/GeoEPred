from pathlib import Path
import argparse

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "GO_three_panel_composite_python"
OUT.mkdir(exist_ok=True)

BLUE = "#4B95C3"
TEAL = "#5BB6B1"
PURPLE = "#8D7CAF"
EMPTY = "#E9EEF0"
EDGE = "#5E7079"

SHORT_LABELS = {
    "GO:0042710": "biofilm formation",
    "GO:0033103": "type VI secretion",
    "GO:0009306": "protein secretion",
    "GO:0071806": "transmembrane protein transport",
    "GO:0015628": "type II secretion",
    "GO:0044419": "interspecies interaction",
    "GO:0030254": "type III secretion",
    "GO:0043952": "Sec-dependent protein transport",
    "GO:0016788": "ester-bond hydrolase activity",
    "GO:0008237": "metallopeptidase activity",
    "GO:0016298": "lipase activity",
    "GO:0004620": "phospholipase activity",
    "GO:1990404": "NAD+ ADP-ribosyltransferase",
    "GO:0042597": "periplasmic space",
    "GO:0009289": "pilus",
    "GO:0030257": "type III secretion complex",
    "GO:0005576": "extracellular region",
    "GO:0033104": "type VI secretion complex",
    "GO:0046903": "secretion",
    "GO:0006026": "aminoglycan catabolism",
    "GO:0007155": "cell adhesion",
    "GO:0044409": "symbiont entry into host",
    "GO:0016998": "cell-wall macromolecule catabolism",
    "GO:0043708": "biofilm-associated cell adhesion",
    "GO:0061783": "peptidoglycan muralytic activity",
    "GO:0016798": "glycosyl-bond hydrolase activity",
    "GO:0004553": "O-glycosyl hydrolase activity",
    "GO:0008146": "sulfotransferase activity",
    "GO:0005509": "calcium ion binding",
    "GO:0004062": "aryl sulfotransferase activity",
    "GO:0019867": "outer membrane",
    "GO:0030430": "host-cell cytoplasm",
    "GO:0042995": "cell projection",
    "GO:0009986": "cell surface",
}

mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.size": 7,
        "font.weight": "normal",
        "axes.titleweight": "normal",
        "axes.linewidth": 0.75,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def bubble_size(count):
    # 3–47 genes -> 22–128 pt^2; visibly distinct but below the row-spacing limit.
    return 15 + np.asarray(count, dtype=float) * 2.4


def draw_upset(fig, cell, data):
    gs = cell.subgridspec(2, 1, height_ratios=[3.25, 1.05], hspace=0.0)
    ax_bar = fig.add_subplot(gs[0])
    ax_mat = fig.add_subplot(gs[1], sharex=ax_bar)
    x = data["X"].to_numpy()
    genes = data["Genes"].to_numpy()

    ax_bar.bar(x, genes, width=0.62, color=BLUE, edgecolor="none")
    for xi, value in zip(x, genes):
        ax_bar.text(xi, value + 0.55, str(int(value)), ha="center", va="bottom", fontsize=5.6)
    ax_bar.set_ylim(0, 37)
    ax_bar.set_yticks([0, 10, 20, 30])
    ax_bar.set_ylabel("Genes", fontsize=6.2, labelpad=3)
    ax_bar.tick_params(axis="y", labelsize=5.8, width=0.6, length=2.5)
    ax_bar.tick_params(axis="x", bottom=False, labelbottom=False)

    row_y = {"B": 2, "M": 1, "C": 0}
    for xi, combination in zip(x, data["Combination"]):
        active_y = [row_y[c] for c in "BMC" if c in combination]
        if len(active_y) > 1:
            ax_mat.plot([xi, xi], [min(active_y), max(active_y)], color=BLUE, linewidth=0.85, zorder=1)
        for code in "BMC":
            active = code in combination
            ax_mat.scatter(xi, row_y[code], s=24, facecolor=BLUE if active else EMPTY,
                           edgecolor=EDGE, linewidth=0.4, zorder=2)
    ax_mat.set_ylim(-0.55, 2.55)
    ax_mat.set_yticks([2, 1, 0])
    ax_mat.set_yticklabels(["BP", "MF", "CC"], fontsize=6, fontweight="normal")
    ax_mat.set_xticks([])
    ax_mat.tick_params(axis="y", length=0, pad=3)
    for spine in ax_mat.spines.values():
        spine.set_visible(False)
    ax_bar.set_xlim(0.4, float(x.max()) + 0.6)
    ax_bar.set_title("Shared enriched genes", fontsize=8, fontweight="normal", pad=7)


def draw_landscape(ax, data):
    order = ["BP", "MF", "CC"]
    colors = {"BP": BLUE, "MF": TEAL, "CC": PURPLE}
    data = data.set_index("Ontology").loc[order].reset_index()
    y = np.arange(len(data))
    bars = ax.barh(y, data["SignificantTerms"], height=0.54,
                   color=[colors[o] for o in data["Ontology"]], edgecolor="none")
    ax.set_yticks(y)
    ax.set_yticklabels(order, fontsize=6.2, fontweight="normal")
    ax.invert_yaxis()
    ax.set_xlim(0, 66)
    ax.set_xticks([0, 20, 40, 60])
    ax.set_xlabel("Significant GO terms", fontsize=6.2, labelpad=3)
    ax.tick_params(axis="x", labelsize=5.8, width=0.6, length=2.5)
    ax.tick_params(axis="y", length=0, pad=2)
    ax.spines["left"].set_visible(False)
    for bar, terms, genes in zip(bars, data["SignificantTerms"], data["EnrichedGenes"]):
        y_mid = bar.get_y() + bar.get_height() / 2
        number_x = bar.get_width() + 2.10
        word_x = number_x + 0.60
        line_offset = 0.085
        # Separate number and word columns so 1- and 2-digit values align identically.
        ax.text(number_x, y_mid - line_offset, str(int(terms)), ha="right", va="center", fontsize=5.5)
        ax.text(word_x, y_mid - line_offset, "terms", ha="left", va="center", fontsize=5.5)
        ax.text(number_x, y_mid + line_offset, str(int(genes)), ha="right", va="center", fontsize=5.5)
        ax.text(word_x, y_mid + line_offset, "genes", ha="left", va="center", fontsize=5.5)
    ax.set_title("Ontology landscape", loc="center", fontsize=8, fontweight="normal", pad=7)


def draw_bubble(fig, cell, data):
    gs = cell.subgridspec(1, 2, width_ratios=[2.35, 2.15], wspace=0.025)
    ax_label = fig.add_subplot(gs[0])
    ax = fig.add_subplot(gs[1])
    data = data.copy()
    data["DisplayTerm"] = data["ID"].map(SHORT_LABELS)
    data["Ontology"] = pd.Categorical(data["Ontology"], ["BP", "MF", "CC"], ordered=True)
    data = data.sort_values(["Ontology", "FoldEnrichment"], ascending=[True, False], kind="stable")

    records, cursor = [], 0.0
    for ontology in ["BP", "MF", "CC"]:
        for _, row in data[data["Ontology"] == ontology].iterrows():
            records.append((cursor, row))
            cursor += 1.0
        cursor += 0.72
    y = np.array([r[0] for r in records])
    ordered = pd.DataFrame([r[1] for r in records]).reset_index(drop=True)
    x = ordered["FoldEnrichment"].to_numpy(float)

    cmap = LinearSegmentedColormap.from_list("fdr_blue", ["#E9EEF0", "#9BC8DD", BLUE])
    fdr_max = max(10.0, float(np.ceil(ordered["NegLog10FDR"].max() / 5.0) * 5.0))
    norm = Normalize(vmin=1.0, vmax=fdr_max)
    ax.hlines(y, 1.0, x, color="#D7E0E4", linewidth=0.9, zorder=1)
    ax.scatter(x, y, s=bubble_size(ordered["Count"]),
               c=ordered["NegLog10FDR"], cmap=cmap, norm=norm,
               edgecolor="#19313D", linewidth=0.45, zorder=3)
    ax.set_xlim(1, 17.6)
    ax.set_ylim(-0.5, y.max() + 0.5)
    ax.invert_yaxis()
    ax.set_xticks([1, 5, 10, 15])
    ax.set_xlabel("Fold enrichment", fontsize=8, labelpad=4)
    ax.set_yticks([])
    ax.tick_params(axis="x", labelsize=7, width=0.7, length=3)
    ax.spines["left"].set_color("#9EADB4")
    ax.spines["left"].set_linestyle((0, (2, 3)))
    ax.spines["left"].set_linewidth(0.7)

    ax_label.set_xlim(0, 1)
    ax_label.set_ylim(ax.get_ylim())
    ax_label.axis("off")
    for yi, term in zip(y, ordered["DisplayTerm"]):
        ax_label.text(0.985, yi, term, ha="right", va="center", fontsize=6.3, color="#13242D")

    # Vertical FDR legend placed in the open right-hand area, matching the reference layout.
    cax = ax.inset_axes([0.67, 0.56, 0.095, 0.15])
    cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation="vertical")
    cb.set_ticks([5, 10] if fdr_max <= 15 else [10, 20])
    cb.ax.yaxis.set_ticks_position("right")
    cb.ax.tick_params(labelsize=5.5, length=0, pad=2)
    cb.outline.set_edgecolor(EDGE)
    cb.outline.set_linewidth(0.55)
    cax.set_title("−log10(FDR)", fontsize=5.5, fontweight="normal", pad=4)

    ax_label.set_title("Representative enriched terms", fontsize=8, fontweight="normal", pad=7, x=1.22)


def main():
    parser = argparse.ArgumentParser(description="Build the compact three-panel GO figure.")
    parser.add_argument("--dataset", choices=["PAO1", "NC_003197.2"], default="PAO1")
    args = parser.parse_args()
    source_dir = ROOT / ("GO_nature_multipanel" if args.dataset == "PAO1" else "NC_003197.2_GO_nature_multipanel")
    output_dir = OUT if args.dataset == "PAO1" else ROOT / "NC_003197.2_GO_three_panel_composite_python"
    output_dir.mkdir(exist_ok=True)

    upset = pd.read_csv(source_dir / "Source_Data_panel_c_intersections.csv").sort_values("X")
    landscape = pd.read_csv(source_dir / "Source_Data_panel_b_ontology_summary.csv")
    bubble = pd.read_csv(source_dir / "Source_Data_panel_a_representative_terms.csv")
    missing_labels = set(bubble["ID"]).difference(SHORT_LABELS)
    if missing_labels:
        raise ValueError(f"Missing short labels for: {sorted(missing_labels)}")

    fig = plt.figure(figsize=(183 / 25.4, 130 / 25.4))
    outer = fig.add_gridspec(2, 2, width_ratios=[0.98, 1.02], height_ratios=[1, 1],
                             wspace=0.035, hspace=0.20)
    draw_upset(fig, outer[0, 0], upset)
    draw_landscape(fig.add_subplot(outer[1, 0]), landscape)
    draw_bubble(fig, outer[:, 1], bubble)
    fig.subplots_adjust(left=0.060, right=0.985, top=0.935, bottom=0.09)
    fig.text(0.018, 0.958, "A", fontsize=8.5, fontweight="normal", ha="left", va="top")
    fig.text(0.018, 0.505, "B", fontsize=8.5, fontweight="normal", ha="left", va="top")
    fig.text(0.515, 0.958, "C", fontsize=8.5, fontweight="normal", ha="left", va="top")

    upset.to_csv(output_dir / "Source_Data_panel_upset.csv", index=False, encoding="utf-8-sig")
    landscape.to_csv(output_dir / "Source_Data_panel_landscape.csv", index=False, encoding="utf-8-sig")
    bubble.to_csv(output_dir / "Source_Data_panel_bubble.csv", index=False, encoding="utf-8-sig")
    stem = output_dir / f"{args.dataset}_GO_three_panel_composite_FDR_scaled"
    fig.savefig(f"{stem}.png", dpi=300, facecolor="white")
    fig.savefig(f"{stem}.svg", facecolor="white")
    fig.savefig(f"{stem}.pdf", facecolor="white")
    fig.savefig(f"{stem}.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {output_dir}")


if __name__ == "__main__":
    main()
