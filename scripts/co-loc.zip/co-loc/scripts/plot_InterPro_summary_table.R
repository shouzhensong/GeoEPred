setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(patchwork)
  library(ragg)
})

output_dir <- "Nature_InterPro_multipanel"
if (!dir.exists(output_dir)) dir.create(output_dir)

# =========================================================================
# Build master domain table across all three strains
# =========================================================================

# Key effector domains to report
domains <- c(
  # T6SE structural
  "PF04717", "PF05954", "PF05591", "PF05593", "PF05488",
  "PF05638", "PF22178", "PF07484",
  # T4SE effector
  "PF08238", "PF00023",
  # T3SE effector
  "PF03496", "PF03545", "PF03497", "PF09025",
  # T2SE
  "PF00419", "PF01447", "PF02868", "PF06903",
  # T1SE
  "PF00353",
  # Other effector-associated
  "PF00665", "PF00561", "PF05506", "PF05935", "PF10685"
)

domain_names <- c(
  "PF04717"="Phage-baseplate injector OB (T6SS)",
  "PF05954"="Phage tail baseplate hub (T6SS)",
  "PF05591"="T6SS sheath TssB/VipA",
  "PF05593"="RHS repeat (T6SS effector)",
  "PF05488"="PAAR motif (T6SS spike)",
  "PF05638"="T6SS effector Hcp",
  "PF22178"="Phage T4 gp5 trimerization",
  "PF07484"="Phage Tail Collar Domain",
  "PF08238"="Sel1 repeat (T4SE hallmark)",
  "PF00023"="Ankyrin repeat (T4SE)",
  "PF03496"="ADP-ribosyltransferase exotoxin",
  "PF03545"="YopE GAP domain (T3SE)",
  "PF03497"="Anthrax toxin LF subunit",
  "PF09025"="YopR T3SS needle regulator",
  "PF00419"="Fimbrial protein",
  "PF01447"="Thermolysin metallopeptidase (cat.)",
  "PF02868"="Thermolysin metallopeptidase (hel.)",
  "PF06903"="VirK protein",
  "PF00353"="RTX calcium-binding repeat (T1SS)",
  "PF00665"="Integrase core domain",
  "PF00561"="alpha/beta hydrolase fold",
  "PF05506"="Bacterial phospholipase C",
  "PF05935"="Arylsulfotransferase (ASST)",
  "PF10685"="Stress-induced acidophilic repeat"
)

domain_targets <- c(
  "PF04717"="T6SE","PF05954"="T6SE","PF05591"="T6SE","PF05593"="T6SE",
  "PF05488"="T6SE","PF05638"="T6SE","PF22178"="T6SE","PF07484"="T6SE",
  "PF08238"="T4SE","PF00023"="T4SE",
  "PF03496"="T3SE","PF03545"="T3SE","PF03497"="T3SE","PF09025"="T3SE",
  "PF00419"="T2SE","PF01447"="T2SE","PF02868"="T2SE","PF06903"="T2SE",
  "PF00353"="T1SE",
  "PF00665"="T4SE/T6SE","PF00561"="T2SE/T3SE","PF05506"="T2SE",
  "PF05935"="T2SE","PF10685"="T1SE"
)

# =========================================================================
# Read enrichment results from all three strains
# =========================================================================

read_pfam <- function(dir) {
  files <- list.files(dir, pattern="Pfam_enrich_.*\\.csv$", full.names=TRUE)
  do.call(rbind, lapply(files, function(f) {
    tab <- read.csv(f, stringsAsFactors=FALSE)
    if(!"SecType" %in% names(tab)) {
      tab$SecType <- gsub(".*Pfam_enrich_(.+)\\.csv$", "\\1", basename(f))
    }
    tab
  }))
}

pao1  <- read_pfam("PAO1_InterPro_results");    pao1$Strain  <- "PAO1"
nc003 <- read_pfam("NC_003197.2_InterPro_results");  nc003$Strain <- "NC_003197.2"
nc002 <- read_pfam("NC_002942.5_InterPro_results"); nc002$Strain <- "NC_002942.5"

all <- rbind(pao1, nc003, nc002)
all$term <- if("ID" %in% names(all)) all$ID else all$term

# Filter to our key domains
tab_data <- all[all$term %in% domains, ]

# Build summary row per domain x strain
summary_list <- list()
for (pf in domains) {
  for (st in c("PAO1","NC_003197.2","NC_002942.5")) {
    rows <- tab_data[tab_data$term == pf & tab_data$Strain == st, ]
    if (nrow(rows) == 0) {
      summary_list[[length(summary_list)+1]] <- data.frame(
        Pfam=pf, Strain=st, SecType=domain_targets[pf],
        Fold=NA_real_, Padj=NA_real_, Count=0L, Sig="",
        stringsAsFactors=FALSE
      )
      next
    }
    best <- rows[which.min(rows$p.adjust), ]
    summary_list[[length(summary_list)+1]] <- data.frame(
      Pfam=pf, Strain=st,
      SecType=paste(unique(rows$SecType), collapse="/"),
      Fold=as.numeric(best$FoldEnrichment),
      Padj=as.numeric(best$p.adjust),
      Count=as.integer(best$Count),
      Sig=ifelse(!is.na(best$p.adjust) && best$p.adjust < 0.05,
                 ifelse(best$p.adjust < 0.01, "**", "*"), ""),
      stringsAsFactors=FALSE
    )
  }
}
summary_rows <- do.call(rbind, summary_list)

summary_rows$Pfam <- factor(summary_rows$Pfam, levels=rev(domains))
summary_rows$Strain <- factor(summary_rows$Strain, levels=c("PAO1","NC_003197.2","NC_002942.5"))

# =========================================================================
# Panel A: Domain presence heatmap (Count × Strain, colored by significance)
# =========================================================================

# Pivot to wide for heatmap
hm_data <- summary_rows
hm_data$Label <- ifelse(hm_data$Count > 0,
  sprintf("%d", hm_data$Count),
  "")
hm_data$SigLevel <- ifelse(hm_data$Padj < 0.05 & !is.na(hm_data$Padj), "p<0.05",
                     ifelse(hm_data$Count > 0, "Present", "Absent"))

p_a <- ggplot(hm_data, aes(Strain, Pfam)) +
  geom_tile(aes(fill = SigLevel), colour = "white", linewidth = 0.5) +
  geom_text(aes(label = Label), size = 3.2, colour = "#26343C") +
  scale_fill_manual(values = c(
    "p<0.05"  = "#1A4A5E",
    "Present" = "#8AB5C4",
    "Absent"  = "#EEF2F5"
  ), name = NULL) +
  scale_x_discrete(expand = c(0,0)) +
  scale_y_discrete(
    expand = c(0,0),
    labels = setNames(sapply(levels(hm_data$Pfam), function(pf) {
      domain_names[pf]
    }), levels(hm_data$Pfam))
  ) +
  labs(title = "Pfam domain presence across three genomes",
       subtitle = "Number = protein count; blue fill = significant (p.adj<0.05)",
       tag = "a") +
  theme_minimal(base_size = 8) +
  theme(
    panel.grid = element_blank(),
    axis.text.x = element_text(size = 7.5, face = "bold.italic", colour = "#26343C"),
    axis.text.y = element_text(size = 6.5, colour = "#26343C", lineheight = 0.9),
    axis.title = element_blank(),
    legend.position = "bottom",
    legend.text = element_text(size = 6.5),
    plot.title = element_text(size = 9, face = "bold"),
    plot.subtitle = element_text(size = 6.5, colour = "#6F7B82"),
    plot.tag = element_text(size = 10, face = "bold")
  )

# =========================================================================
# Panel B: Fold enrichment bubble summary
# =========================================================================

bubble_data <- summary_rows[summary_rows$Count > 0 & !is.na(summary_rows$Fold), ]
bubble_data$NegLog10P <- -log10(pmax(bubble_data$Padj, 1e-30))
bubble_data$Label <- ifelse(bubble_data$Padj < 0.05,
  sprintf("%.0f× *", bubble_data$Fold),
  sprintf("%.0f×", bubble_data$Fold))

p_b <- ggplot(bubble_data, aes(Strain, Pfam)) +
  geom_point(aes(size = Count, fill = NegLog10P),
             shape = 21, colour = "#26343C", stroke = 0.3) +
  geom_text(aes(label = Label), size = 2.8, hjust = -0.3, colour = "#6F7B82") +
  scale_size_continuous(range = c(1.5, 7), name = "Proteins",
                        breaks = c(3, 10, 20, 40)) +
  scale_fill_gradientn(
    colours = c("#F4F8FC","#DCEAF4","#9ECAE1","#4292C6","#08519C"),
    name = expression(-log[10](P[adj])),
    na.value = "#E8E8E8"
  ) +
  scale_x_discrete(expand = expansion(mult = c(0.1, 0.35))) +
  scale_y_discrete(
    labels = setNames(sapply(levels(bubble_data$Pfam), function(pf) {
      domain_names[pf]
    }), levels(bubble_data$Pfam))
  ) +
  labs(title = "Fold enrichment of effector-associated Pfam domains",
       subtitle = "Bubble size = protein count; color = significance; * = p.adj<0.05",
       tag = "b") +
  theme_minimal(base_size = 8) +
  theme(
    panel.grid = element_blank(),
    axis.text.x = element_text(size = 7.5, face = "bold.italic", colour = "#26343C"),
    axis.text.y = element_blank(),
    axis.title = element_blank(),
    legend.position = "right",
    legend.title = element_text(size = 6),
    legend.text = element_text(size = 5.5),
    plot.title = element_text(size = 9, face = "bold"),
    plot.subtitle = element_text(size = 6.5, colour = "#6F7B82"),
    plot.tag = element_text(size = 10, face = "bold")
  )

# =========================================================================
# Assemble + export
# =========================================================================
figure <- p_a | p_b

w <- 14; h <- 8
ggsave(file.path(output_dir, "InterPro_Summary_Table.pdf"), figure,
       width = w, height = h, device = "pdf", bg = "white")
ggsave(file.path(output_dir, "InterPro_Summary_Table.png"), figure,
       width = w, height = h, dpi = 300, bg = "white")

cat("Saved to:", output_dir, "\n")
