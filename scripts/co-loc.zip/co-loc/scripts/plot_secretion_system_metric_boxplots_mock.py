from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Patch


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "secretion_system_boxplots_mock"
OUT.mkdir(exist_ok=True)

SYSTEMS = ["T3SE", "T4SE", "T6SE"]
METRICS = ["REC", "PR", "ACC", "F1", "MCC"]
METHODS = ["AT", "3Di", "DP", "MSA", "ESM2", "CLEF"]
COLORS = {
    "AT": "#F26B61",
    "3Di": "#E7AE4A",
    "DP": "#8DBE59",
    "MSA": "#B07AA8",
    "ESM2": "#3E9C92",
    "CLEF": "#69B9CC",
}

# Provisional means chosen to reproduce the visual pattern of the supplied example.
MEANS = {
    "T3SE": {
        "REC": [0.82, 0.68, 0.65, 0.76, 0.77, 0.80],
        "PR":  [0.91, 0.84, 0.87, 0.92, 0.94, 0.95],
        "ACC": [0.96, 0.96, 0.95, 0.96, 0.96, 0.96],
        "F1":  [0.86, 0.72, 0.75, 0.83, 0.82, 0.84],
        "MCC": [0.85, 0.70, 0.73, 0.82, 0.80, 0.82],
    },
    "T4SE": {
        "REC": [0.69, 0.62, 0.67, 0.70, 0.72, 0.74],
        "PR":  [0.81, 0.78, 0.84, 0.82, 0.81, 0.84],
        "ACC": [0.92, 0.92, 0.92, 0.92, 0.92, 0.93],
        "F1":  [0.75, 0.70, 0.74, 0.76, 0.75, 0.77],
        "MCC": [0.70, 0.68, 0.72, 0.71, 0.72, 0.74],
    },
    "T6SE": {
        "REC": [0.58, 0.75, 0.69, 0.65, 0.79, 0.82],
        "PR":  [0.98, 0.96, 0.92, 0.97, 0.93, 0.97],
        "ACC": [0.97, 0.98, 0.98, 0.97, 0.98, 0.98],
        "F1":  [0.69, 0.82, 0.81, 0.79, 0.84, 0.89],
        "MCC": [0.69, 0.82, 0.81, 0.79, 0.84, 0.88],
    },
}

SPREAD = {"REC": 0.035, "PR": 0.028, "ACC": 0.008, "F1": 0.026, "MCC": 0.026}

mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.titleweight": "normal",
        "axes.labelweight": "normal",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.75,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def simulate_data(seed=20260807, replicates=10):
    rng = np.random.default_rng(seed)
    records = []
    for system in SYSTEMS:
        for metric in METRICS:
            for method, mean in zip(METHODS, MEANS[system][metric]):
                values = rng.normal(mean, SPREAD[metric], size=replicates)
                values = np.clip(values, 0.50, 0.995)
                for replicate, value in enumerate(values, start=1):
                    records.append(
                        {
                            "System": system,
                            "Metric": metric,
                            "Method": method,
                            "Replicate": replicate,
                            "Score": value,
                        }
                    )
    return pd.DataFrame(records)


def draw_panel(ax, data, system):
    centers = np.arange(len(METRICS), dtype=float)
    offsets = np.linspace(-0.30, 0.30, len(METHODS))
    width = 0.105

    for method, offset in zip(METHODS, offsets):
        color = COLORS[method]
        for metric_index, metric in enumerate(METRICS):
            values = data.loc[
                (data["System"] == system)
                & (data["Metric"] == metric)
                & (data["Method"] == method),
                "Score",
            ].to_numpy()
            ax.boxplot(
                [values],
                positions=[centers[metric_index] + offset],
                widths=width,
                patch_artist=True,
                manage_ticks=False,
                showfliers=True,
                boxprops={"facecolor": "white", "edgecolor": color, "linewidth": 0.65},
                medianprops={"color": color, "linewidth": 0.8},
                whiskerprops={"color": color, "linewidth": 0.55},
                capprops={"color": color, "linewidth": 0.55},
                flierprops={
                    "marker": "o",
                    "markerfacecolor": color,
                    "markeredgecolor": color,
                    "markersize": 1.8,
                    "alpha": 0.95,
                },
            )

    ax.set_title(system, fontsize=8.5, fontweight="normal", pad=7)
    ax.set_xlim(-0.60, len(METRICS) - 0.40)
    ax.set_ylim(0.50, 1.00)
    ax.set_xticks(centers)
    ax.set_xticklabels(METRICS, fontsize=7, fontweight="normal")
    ax.set_yticks(np.arange(0.5, 1.01, 0.1))
    ax.tick_params(axis="both", labelsize=6.5, width=0.65, length=3, pad=2)
    ax.spines["left"].set_color("#24333A")
    ax.spines["bottom"].set_color("#24333A")


def main():
    data = simulate_data()
    data.to_csv(OUT / "Source_Data_mock_scores.csv", index=False, encoding="utf-8-sig")

    fig, axes = plt.subplots(1, 3, figsize=(183 / 25.4, 70 / 25.4), sharey=True)
    for ax, system in zip(axes, SYSTEMS):
        draw_panel(ax, data, system)
    for ax in axes:
        ax.tick_params(axis="y", labelleft=True)

    legend_handles = [
        Patch(facecolor="white", edgecolor=COLORS[method], linewidth=0.7, label=method)
        for method in METHODS
    ]
    axes[-1].legend(
        handles=legend_handles,
        loc="center left",
        bbox_to_anchor=(1.03, 0.50),
        frameon=False,
        fontsize=6.8,
        handlelength=1.2,
        handleheight=0.8,
        borderaxespad=0,
        labelspacing=0.45,
    )

    fig.subplots_adjust(left=0.055, right=0.88, top=0.88, bottom=0.17, wspace=0.20)
    stem = OUT / "T3SE_T4SE_T6SE_metric_boxplots_mock"
    fig.savefig(f"{stem}.png", dpi=300, facecolor="white")
    fig.savefig(f"{stem}.svg", facecolor="white")
    fig.savefig(f"{stem}.pdf", facecolor="white")
    fig.savefig(f"{stem}.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
