from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Patch


# =============================================================================
# EDITABLE DATA CONFIGURATION
# Replace these CSV files with real data later; plotting code below need not change.
# Box CSV columns: System, Metric, Method, Replicate, Score
# Heatmap CSVs: row names in first column, predictor names in remaining columns.
# BAR_DATA_CSV may be set to a CSV with System,Metric,Method,Score; when None,
# bar heights are calculated as means from BOX_DATA_CSV.
# =============================================================================
ROOT = Path(__file__).resolve().parent
BOX_DATA_CSV = ROOT / "secretion_system_boxplots_mock" / "Source_Data_mock_scores.csv"
BAR_DATA_CSV = None
HEATMAP_CSV = None  # Optionally replace with {"T3SE": path, "T4SE": path, "T6SE": path}.
HEATMAP_DATA = {
    "T3SE": pd.DataFrame(
        [[0, 4, 4, np.nan, 8, 14], [0, np.nan, np.nan, np.nan, 9, 12],
         [1, np.nan, np.nan, np.nan, np.nan, 2], [28, 28, 29, 21, 30, 30],
         [1, 1, np.nan, 3, 12, 30], [np.nan, 2, 2, np.nan, np.nan, 9]],
        index=["Non-effector", "T1SE", "T2SE", "T3SE", "T4SE", "T6SE"],
        columns=["GeoEPred", "DeepSecE", "MoCETSE", "T3SEpp", "Bastion3", "BastionX"],
    ),
    "T4SE": pd.DataFrame(
        [[3, 3, 6, 6, 15, 4, np.nan], [np.nan, np.nan, np.nan, 1, 9, 6, 2],
         [np.nan, 1, np.nan, np.nan, 2, np.nan, np.nan], [1, 1, np.nan, 3, 26, 21, 4],
         [29, 29, 30, 29, 30, 28, 30], [np.nan, np.nan, np.nan, np.nan, 8, 7, 2]],
        index=["Non-effector", "T1SE", "T2SE", "T3SE", "T4SE", "T6SE"],
        columns=["GeoEPred", "DeepSecE", "MoCETSE", "Bastion4", "BastionX", "T4SEfinder", "T4SEpp"],
    ),
    "T6SE": pd.DataFrame(
        [[2, 1, np.nan, 12, 20], [np.nan, 1, 1, 11, 17],
         [np.nan, np.nan, np.nan, 4, np.nan], [np.nan, np.nan, np.nan, 16, 14],
         [np.nan, np.nan, np.nan, 20, 3], [20, 17, 18, 19, 20]],
        index=["Non-effector", "T1SE", "T2SE", "T3SE", "T4SE", "T6SE"],
        columns=["GeoEPred", "DeepSecE", "MoCETSE", "Bastion6", "BastionX"],
    ),
}
OUTPUT_DIR = ROOT / "secretion_system_3x3_composite"

SYSTEMS = ["T3SE", "T4SE", "T6SE"]
METRICS = ["ACC", "REC", "PR", "F1", "MCC"]
BOX_METRICS = ["REC", "PR", "ACC", "F1", "MCC"]
METHODS = ["AT", "3Di", "DP", "MSA", "ESM2", "CLEF"]
COLORS = {
    "AT": "#F26B61",
    "3Di": "#E7AE4A",
    "DP": "#8DBE59",
    "MSA": "#B07AA8",
    "ESM2": "#3E9C92",
    "CLEF": "#69B9CC",
}
HEATMAP_COLORS = {
    "T3SE": ["#F1F4F6", "#9FC0DA", "#4B95C3"],
    "T4SE": ["#F0F5F4", "#A7D3CF", "#5BB6B1"],
    "T6SE": ["#F3F1F5", "#BDB2CF", "#8D7CAF"],
}


mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.titleweight": "normal",
        "axes.labelweight": "normal",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.65,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def load_data():
    box = pd.read_csv(BOX_DATA_CSV)
    required = {"System", "Metric", "Method", "Replicate", "Score"}
    missing = required.difference(box.columns)
    if missing:
        raise ValueError(f"Box-data CSV missing columns: {sorted(missing)}")

    if BAR_DATA_CSV is None:
        bars = box.groupby(["System", "Metric", "Method"], as_index=False)["Score"].mean()
    else:
        bars = pd.read_csv(BAR_DATA_CSV)
        missing = {"System", "Metric", "Method", "Score"}.difference(bars.columns)
        if missing:
            raise ValueError(f"Bar-data CSV missing columns: {sorted(missing)}")

    if HEATMAP_CSV is None:
        heatmaps = {system: frame.copy() for system, frame in HEATMAP_DATA.items()}
    else:
        heatmaps = {system: pd.read_csv(path, index_col=0) for system, path in HEATMAP_CSV.items()}
    return box, bars, heatmaps


def style_numeric_axis(ax):
    ax.tick_params(axis="both", labelsize=5.2, width=0.55, length=2.2, pad=1.5)
    ax.spines["left"].set_color("#34434A")
    ax.spines["bottom"].set_color("#34434A")


def draw_box_panel(ax, data, system):
    centers = np.arange(len(BOX_METRICS), dtype=float)
    offsets = np.linspace(-0.30, 0.30, len(METHODS))
    for method, offset in zip(METHODS, offsets):
        color = COLORS[method]
        for metric_i, metric in enumerate(BOX_METRICS):
            values = data.loc[
                (data["System"] == system)
                & (data["Metric"] == metric)
                & (data["Method"] == method),
                "Score",
            ].dropna().to_numpy()
            if len(values) == 0:
                continue
            ax.boxplot(
                [values], positions=[centers[metric_i] + offset], widths=0.10,
                patch_artist=True, manage_ticks=False, showfliers=True,
                boxprops={"facecolor": "white", "edgecolor": color, "linewidth": 0.55},
                medianprops={"color": color, "linewidth": 0.65},
                whiskerprops={"color": color, "linewidth": 0.45},
                capprops={"color": color, "linewidth": 0.45},
                flierprops={"marker": "o", "markerfacecolor": color,
                            "markeredgecolor": color, "markersize": 1.4},
            )
    ax.set_xlim(-0.58, len(BOX_METRICS) - 0.42)
    ax.set_ylim(0.50, 1.00)
    ax.set_xticks(centers)
    ax.set_xticklabels(BOX_METRICS, fontsize=5.2)
    ax.set_yticks(np.arange(0.5, 1.01, 0.1))
    ax.set_title(system, fontsize=7, fontweight="normal", pad=4)
    style_numeric_axis(ax)


def draw_bar_panel(ax, data, system):
    centers = np.arange(len(METRICS), dtype=float)
    total_width = 0.78
    width = total_width / len(METHODS)
    subset = data[data["System"] == system]
    for method_i, method in enumerate(METHODS):
        values = []
        for metric in METRICS:
            match = subset[(subset["Metric"] == metric) & (subset["Method"] == method)]["Score"]
            values.append(float(match.iloc[0]) if len(match) else np.nan)
        positions = centers - total_width / 2 + width / 2 + method_i * width
        ax.bar(positions, values, width=width * 0.92, color=COLORS[method], edgecolor="white", linewidth=0.15)
    ax.set_xlim(-0.58, len(METRICS) - 0.42)
    ax.set_ylim(0.20, 1.02)
    ax.set_xticks(centers)
    ax.set_xticklabels(METRICS, fontsize=5.2)
    ax.set_yticks(np.arange(0.2, 1.01, 0.2))
    ax.set_title(system, fontsize=7, fontweight="normal", pad=4)
    style_numeric_axis(ax)


def draw_heatmap_panel(ax, frame, system):
    values = frame.to_numpy(dtype=float)
    cmap = LinearSegmentedColormap.from_list(f"{system}_map", HEATMAP_COLORS[system])
    cmap.set_bad("white")
    norm = Normalize(0, 30)
    ax.imshow(np.ma.masked_invalid(values), cmap=cmap, norm=norm, interpolation="nearest", aspect="auto")

    ax.set_xticks(np.arange(frame.shape[1]))
    ax.set_xticklabels(frame.columns, rotation=45, ha="right", rotation_mode="anchor", fontsize=4.5)
    ax.set_yticks(np.arange(frame.shape[0]))
    ax.set_yticklabels(frame.index, fontsize=4.5)
    ax.tick_params(axis="both", length=0, pad=1.2)
    ax.set_xlabel(f"Predict {system}", fontsize=5.8, labelpad=2)

    ax.set_xticks(np.arange(-0.5, frame.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, frame.shape[0], 1), minor=True)
    ax.grid(which="minor", color="#D8DDE0", linewidth=0.35)
    ax.tick_params(which="minor", bottom=False, left=False)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.45)
        spine.set_color("#B4BCC0")

    for row in range(values.shape[0]):
        for col in range(values.shape[1]):
            value = values[row, col]
            if np.isnan(value):
                continue
            ax.text(col, row, str(int(value)), ha="center", va="center", fontsize=4.3,
                    color="white" if value >= 16 else "#303A3F")


def add_panel_label(ax, label):
    ax.text(-0.17, 1.10, label, transform=ax.transAxes, fontsize=7,
            fontfamily="Arial", fontweight="normal", ha="left", va="bottom", clip_on=False)


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    box_data, bar_data, heatmaps = load_data()

    fig, axes = plt.subplots(3, 3, figsize=(183 / 25.4, 190 / 25.4))
    panel_letters = list("ABCDEFGHI")

    for col, system in enumerate(SYSTEMS):
        draw_box_panel(axes[0, col], box_data, system)
        draw_bar_panel(axes[1, col], bar_data, system)
        draw_heatmap_panel(axes[2, col], heatmaps[system], system)

    # Shared legends keep all nine panel bounding boxes equal.
    handles = [Patch(facecolor="white", edgecolor=COLORS[m], linewidth=0.6, label=m) for m in METHODS]
    axes[0, 2].legend(handles=handles, loc="center left", bbox_to_anchor=(1.02, 0.50),
                      frameon=False, fontsize=4.7, labelspacing=0.28,
                      handlelength=1.0, borderaxespad=0)
    for ax, letter in zip(axes.flat, panel_letters):
        add_panel_label(ax, letter)

    # Hide redundant y tick labels while preserving identical axes sizes.
    for row in range(3):
        for col in [1, 2]:
            axes[row, col].tick_params(axis="y", labelleft=False)

    fig.subplots_adjust(left=0.075, right=0.91, top=0.965, bottom=0.07,
                        wspace=0.34, hspace=0.48)

    box_data.to_csv(OUTPUT_DIR / "Source_Data_boxplots.csv", index=False, encoding="utf-8-sig")
    bar_data.to_csv(OUTPUT_DIR / "Source_Data_bars.csv", index=False, encoding="utf-8-sig")
    for system, frame in heatmaps.items():
        frame.to_csv(OUTPUT_DIR / f"Source_Data_heatmap_{system}.csv", encoding="utf-8-sig")
    stem = OUTPUT_DIR / "T3SE_T4SE_T6SE_3x3_composite"
    fig.savefig(f"{stem}.png", dpi=300, facecolor="white")
    fig.savefig(f"{stem}.svg", facecolor="white")
    fig.savefig(f"{stem}.pdf", facecolor="white")
    fig.savefig(f"{stem}.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
