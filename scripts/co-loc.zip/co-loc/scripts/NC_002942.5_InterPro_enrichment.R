setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(ggplot2)
})

output_dir <- "NC_002942.5_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

# 1. 加载基因列表 ============================================================
candidate_ids <- readLines("NC_002942.5_T4SE/candidate_genes_effector.txt", warn = FALSE)
background_ids <- readLines("NC_002942.5_T4SE/background_genes_all.txt", warn = FALSE)
candidate_ids <- unique(toupper(trimws(candidate_ids)))
candidate_ids <- candidate_ids[!is.na(candidate_ids) & candidate_ids != ""]
background_ids <- unique(toupper(trimws(background_ids)))
background_ids <- background_ids[!is.na(background_ids) & background_ids != ""]

clean_candidates <- unique(sub("([LPGRS0-9_]+).*", "\\1", candidate_ids))
clean_background <- unique(sub("([LPGRS0-9_]+).*", "\\1", background_ids))
cat("Candidate genes:", length(clean_candidates), "\n")
cat("Background genes:", length(clean_background), "\n")

# 2. gene symbol → locus_tag 映射 ===========================================
features <- read.csv("NC_002942.5_T4SE/features_.csv", stringsAsFactors = FALSE)
gene_to_locus <- setNames(features$locus_tag, toupper(features$gene))
cat("Gene→locus mappings:", sum(!is.na(gene_to_locus)), "\n")

# 3. 解析 QuickGO GAF，从 With_From (第8列) 提取 InterPro ID =================
cat("\nParsing QuickGO GAF for InterPro domains...\n")
gaf_file <- file.path(output_dir, "LEGPN_QuickGO.gaf")
gaf_lines <- readLines(gaf_file, warn = FALSE)
data_lines <- gaf_lines[!grepl("^!", gaf_lines)]
cat("GAF annotation lines:", length(data_lines), "\n")

# Parse GAF columns
parts_list <- strsplit(data_lines, "\t")

# Extract: symbol(3), GO_ID(5), evidence(7), with_from(8), aspect(9), assigned_by(15)
gaf_df <- data.frame(
  symbol    = sapply(parts_list, function(p) if(length(p)>=3) p[3] else NA),
  GO_ID     = sapply(parts_list, function(p) if(length(p)>=5) p[5] else NA),
  evidence  = sapply(parts_list, function(p) if(length(p)>=7) p[7] else NA),
  with_from = sapply(parts_list, function(p) if(length(p)>=8) p[8] else NA),
  aspect    = sapply(parts_list, function(p) if(length(p)>=9) p[9] else NA),
  assigned  = sapply(parts_list, function(p) if(length(p)>=15) p[15] else NA),
  stringsAsFactors = FALSE
)

# Keep only InterPro-assigned annotations
ipr_rows <- grepl("InterPro", gaf_df$assigned, ignore.case = TRUE)
ipr_df <- gaf_df[ipr_rows, ]
cat("InterPro annotations:", nrow(ipr_df), "\n")

# Extract InterPro IDs from With_From field
# Format: "InterPro:IPR000183|InterPro:IPR009006" or similar
extract_ipr_ids <- function(wf) {
  if (is.na(wf) || wf == "") return(character(0))
  matches <- regmatches(wf, gregexpr("IPR[0-9]{6,}", wf, perl = TRUE))[[1]]
  unique(matches)
}

ipr_df$ipr_ids <- lapply(ipr_df$with_from, extract_ipr_ids)
ipr_df$n_ipr <- sapply(ipr_df$ipr_ids, length)
cat("Annotations with InterPro ID in With_From:", sum(ipr_df$n_ipr > 0), "\n")
cat("Total InterPro IDs extracted:", length(unique(unlist(ipr_df$ipr_ids))), "\n")

# Expand: one row per InterPro ID
ipr_expanded <- do.call(rbind, lapply(seq_len(nrow(ipr_df)), function(i) {
  ids <- ipr_df$ipr_ids[[i]]
  if (length(ids) == 0) return(NULL)
  data.frame(
    symbol    = ipr_df$symbol[i],
    GO_ID     = ipr_df$GO_ID[i],
    aspect    = ipr_df$aspect[i],
    evidence  = ipr_df$evidence[i],
    ipr_id    = ids,
    stringsAsFactors = FALSE
  )
}))
cat("Expanded InterPro annotations:", nrow(ipr_expanded), "\n")

# Map gene symbol → locus_tag
ipr_expanded$locus_tag <- sapply(toupper(ipr_expanded$symbol), function(sym) {
  if (is.na(sym) || sym == "") return(NA_character_)
  idx <- which(names(gene_to_locus) == sym)
  if (length(idx) == 0) return(NA_character_)
  gene_to_locus[idx[1]]
})

ipr_mapped <- ipr_expanded[!is.na(ipr_expanded$locus_tag), ]
cat("Mapped to locus_tag:", nrow(ipr_mapped), "\n")
cat("Unique locus_tags with InterPro:", length(unique(ipr_mapped$locus_tag)), "\n")
cat("Unique InterPro IDs:", length(unique(ipr_mapped$ipr_id)), "\n")

# 4. Get InterPro domain names ===============================================
cat("\nFetching InterPro domain names...\n")
ipr_ids <- unique(ipr_mapped$ipr_id)
cat("Total unique IPR IDs:", length(ipr_ids), "\n")

# Batch fetch InterPro entries via API (50 per batch)
ipr_names <- list()
batch_size <- 50
for (i in seq(1, length(ipr_ids), by = batch_size)) {
  batch <- ipr_ids[i:min(i+batch_size-1, length(ipr_ids))]
  url <- paste0("https://www.ebi.ac.uk/interpro/api/entry/InterPro/?accession=",
                paste(batch, collapse = ","), "&page_size=50")
  tryCatch({
    resp <- jsonlite::fromJSON(url)
    for (r in resp$results) {
      acc <- r$metadata$accession
      name <- r$metadata$name
      if (!is.null(acc) && !is.null(name)) {
        ipr_names[[acc]] <- name
      }
    }
    cat(sprintf("  Batch %d/%d: got %d names\n",
        (i-1)%/%batch_size+1, ceiling(length(ipr_ids)/batch_size), length(batch)))
  }, error = function(e) {
    cat(sprintf("  Batch %d/%d: API error, using IDs as names\n",
        (i-1)%/%batch_size+1, ceiling(length(ipr_ids)/batch_size)))
  })
  Sys.sleep(0.3)
}
cat("Fetched", length(ipr_names), "InterPro names\n")

# 5. Build InterPro term2gene & term2name ====================================
ipr_mapped$domain_name <- sapply(ipr_mapped$ipr_id, function(id) {
  if (id %in% names(ipr_names)) ipr_names[[id]] else id
})

term2gene_ipr <- unique(ipr_mapped[, c("ipr_id", "locus_tag")])
colnames(term2gene_ipr) <- c("term", "gene")

term2name_ipr <- unique(ipr_mapped[, c("ipr_id", "domain_name")])
colnames(term2name_ipr) <- c("term", "name")

cat("\nterm2gene:", nrow(term2gene_ipr), "rows\n")
cat("term2name:", nrow(term2name_ipr), "rows\n")

# Stats
cand_ipr <- term2gene_ipr[term2gene_ipr$gene %in% clean_candidates, ]
bg_ipr <- term2gene_ipr[term2gene_ipr$gene %in% clean_background, ]
cat("\nCandidate genes with InterPro domains:",
    length(unique(cand_ipr$gene)), "/", length(clean_candidates), "\n")
cat("Background genes with InterPro domains:",
    length(unique(bg_ipr$gene)), "/", length(clean_background), "\n")

# 6. InterPro domain enrichment ==============================================
cat("\n===== InterPro Domain Enrichment =====\n")
ipr_result <- clusterProfiler::enricher(
  gene          = clean_candidates,
  universe      = clean_background,
  TERM2GENE     = term2gene_ipr,
  TERM2NAME     = term2name_ipr,
  pAdjustMethod = "BH",
  pvalueCutoff  = 1,
  qvalueCutoff  = 1,
  minGSSize     = 3,
  maxGSSize     = 500
)

ipr_table <- as.data.frame(ipr_result)
ipr_table <- ipr_table[order(ipr_table$p.adjust, ipr_table$pvalue), ]

cat("Total enriched InterPro domains:", nrow(ipr_table), "\n")

# Filter significant
ipr_sig <- ipr_table[
  !is.na(ipr_table$p.adjust) & ipr_table$p.adjust < 0.05 &
  !is.na(ipr_table$qvalue)  & ipr_table$qvalue  < 0.20,
  , drop = FALSE
]
cat("Significant domains (p<0.05, q<0.20):", nrow(ipr_sig), "\n")

# 7. Add fold enrichment =====================================================
parse_ratio <- function(x) {
  vapply(strsplit(as.character(x), "/", fixed = TRUE),
         function(p) as.numeric(p[1])/as.numeric(p[2]), numeric(1))
}

if (nrow(ipr_table) > 0) {
  ipr_table$GeneRatio_num <- parse_ratio(ipr_table$GeneRatio)
  ipr_table$BgRatio_num <- parse_ratio(ipr_table$BgRatio)
  ipr_table$FoldEnrichment <- ipr_table$GeneRatio_num / ipr_table$BgRatio_num

  write.csv(ipr_table, file.path(output_dir, "InterPro_all_results.csv"), row.names = FALSE)

  if (nrow(ipr_sig) > 0) {
    ipr_sig$GeneRatio_num <- parse_ratio(ipr_sig$GeneRatio)
    ipr_sig$BgRatio_num <- parse_ratio(ipr_sig$BgRatio)
    ipr_sig$FoldEnrichment <- ipr_sig$GeneRatio_num / ipr_sig$BgRatio_num
    write.csv(ipr_sig, file.path(output_dir, "InterPro_significant.csv"), row.names = FALSE)
  }

  show_cols <- c("ID", "Description", "GeneRatio", "BgRatio", "FoldEnrichment",
                 "pvalue", "p.adjust", "qvalue", "Count")
  cols <- intersect(show_cols, colnames(ipr_table))

  cat("\n===== Top 20 InterPro Domains =====\n")
  print(head(ipr_table[, cols, drop = FALSE], 20))

  # Bubble plot
  plot_data <- head(ipr_table, min(20, nrow(ipr_table)))
  plot_data$NegLog10FDR <- -log10(pmax(plot_data$p.adjust, .Machine$double.xmin))
  plot_data$ID <- factor(plot_data$ID, levels = rev(plot_data$ID))

  p <- ggplot(plot_data, aes(FoldEnrichment, ID)) +
    geom_vline(xintercept = 1, linewidth = 0.3, linetype = "dashed", colour = "grey60") +
    geom_point(aes(size = Count, fill = NegLog10FDR), shape = 21, colour = "grey20", stroke = 0.3) +
    scale_size_continuous(name = "Genes", range = c(2, 8)) +
    scale_fill_viridis_c(name = expression(-log[10](FDR)), option = "C", direction = 1) +
    labs(x = "Fold enrichment", y = NULL,
         title = "NC_002942.5 InterPro Domain Enrichment") +
    theme_classic(base_size = 10) +
    theme(axis.text.y = element_text(size = 7.5, colour = "black"),
          plot.title = element_text(size = 11, face = "bold"))

  ggsave(file.path(output_dir, "NC_002942.5_InterPro_enrichment.pdf"), p,
         width = 11, height = 7, device = "pdf")
  ggsave(file.path(output_dir, "NC_002942.5_InterPro_enrichment.png"), p,
         width = 11, height = 7, dpi = 300)

  cat("\nPlots saved to:", output_dir, "\n")
}

cat("\n===== Done =====\n")
