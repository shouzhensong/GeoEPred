from pathlib import Path
import textwrap

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.patches import Patch


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "GO_grouped_bar_python"
OUT.mkdir(exist_ok=True)

FILES = {
    "BP": ROOT / "GO_BP_significant.csv",
    "CC": ROOT / "GO_CC_significant.csv",
    "MF": ROOT / "GO_MF_significant.csv",
}
TOP_N = {"BP": 10, "CC": 10, "MF": 10}
COLORS = {"BP": "#2A9D8F", "CC": "#E07425", "MF": "#6875B7"}
FULL_NAMES = {
    "BP": "Biological process",
    "CC": "Cellular component",
    "MF": "Molecular function",
}

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "font.size": 8,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def load_terms() -> pd.DataFrame:
    frames = []
    for ontology, path in FILES.items():
        data = pd.read_csv(path)
        required = {"ID", "Description", "Count", "p.adjust"}
        missing = required.difference(data.columns)
        if missing:
            raise ValueError(f"{path.name} is missing columns: {sorted(missing)}")
        data = data.sort_values(
            ["Count", "p.adjust", "Description"],
            ascending=[False, True, True],
            kind="stable",
        ).head(TOP_N[ontology])
        data = data.assign(Ontology=ontology)
        frames.append(data[["Ontology", "ID", "Description", "Count", "p.adjust"]])
    return pd.concat(frames, ignore_index=True)


def wrap_label(label: str, width: int = 32) -> str:
    return "\n".join(textwrap.wrap(label, width=width, break_long_words=False))


def plot(data: pd.DataFrame) -> plt.Figure:
    positions, colors, labels = [], [], []
    group_bounds = {}
    cursor = 0.0
    gap = 1.15

    for ontology in FILES:
        subset = data[data["Ontology"] == ontology]
        start = cursor
        for _, row in subset.iterrows():
            positions.append(cursor)
            colors.append(COLORS[ontology])
            labels.append(wrap_label(row["Description"]))
            cursor += 1.0
        end = cursor - 1.0
        group_bounds[ontology] = (start, end)
        cursor += gap

    fig, ax = plt.subplots(figsize=(183 / 25.4, 140 / 25.4), constrained_layout=False)
    bars = ax.bar(
        positions,
        data["Count"].to_numpy(),
        width=0.78,
        color=colors,
        edgecolor="white",
        linewidth=0.45,
        zorder=3,
    )

    ymax = float(data["Count"].max())
    ax.set_ylim(0, ymax * 1.14)
    ax.set_ylabel("Gene count", fontsize=9)
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, rotation=75, ha="right", rotation_mode="anchor", fontsize=5.6)
    ax.tick_params(axis="x", length=0, pad=3)
    ax.tick_params(axis="y", labelsize=7.5, width=0.7, length=3)
    ax.yaxis.grid(True, color="#D9D9D9", linewidth=0.55, alpha=0.75, zorder=0)
    ax.set_axisbelow(True)
    ax.spines["left"].set_color("#333333")
    ax.spines["bottom"].set_color("#333333")

    for bar, value in zip(bars, data["Count"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + ymax * 0.018,
            str(int(value)),
            ha="center",
            va="bottom",
            fontsize=5.8,
            color="#333333",
        )

    transform = ax.get_xaxis_transform()
    for ontology, (start, end) in group_bounds.items():
        mid = (start + end) / 2
        ax.text(
            mid,
            -0.59,
            FULL_NAMES[ontology],
            ha="center",
            va="top",
            transform=transform,
            color=COLORS[ontology],
            fontsize=8.2,
            fontweight="bold",
            clip_on=False,
        )
        ax.plot(
            [start - 0.43, end + 0.43],
            [-0.55, -0.55],
            transform=transform,
            color=COLORS[ontology],
            linewidth=1.0,
            clip_on=False,
        )

    legend = [Patch(facecolor=COLORS[key], label=key) for key in FILES]
    ax.legend(handles=legend, loc="upper right", fontsize=7.5, handlelength=1.4)
    ax.margins(x=0.012)
    fig.subplots_adjust(left=0.075, right=0.985, top=0.96, bottom=0.55)
    return fig


def main() -> None:
    data = load_terms()
    data.to_csv(OUT / "Source_Data_GO_grouped_bar.csv", index=False, encoding="utf-8-sig")
    fig = plot(data)
    stem = OUT / "PAO1_GO_grouped_bar"
    fig.savefig(stem.with_suffix(".png"), dpi=300, facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(f"Saved figure bundle to: {OUT}")


if __name__ == "__main__":
    main()
