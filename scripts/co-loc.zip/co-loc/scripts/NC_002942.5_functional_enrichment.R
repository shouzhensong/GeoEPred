# ============================================================================
# NC_002942.5 功能富集分析 — KEGG + COG + InterPro
# Legionella pneumophila Philadelphia-1
# GO注释不完备 → 换用其他功能分类系统
# ============================================================================

# 0. 环境设置 ================================================================
setwd("D:/全基因组测试的数据集/PAO1_GO_enrichment")
output_dir <- "NC_002942.5_results"
if (!dir.exists(output_dir)) dir.create(output_dir)

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("clusterProfiler", quietly = TRUE)) BiocManager::install("clusterProfiler")
if (!requireNamespace("enrichplot", quietly = TRUE)) BiocManager::install("enrichplot")
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
if (!requireNamespace("httr", quietly = TRUE)) install.packages("httr")
if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite")

library(clusterProfiler)
library(enrichplot)
library(ggplot2)
library(httr)
library(jsonlite)

# 1. 加载基因列表 ============================================================
candidate_ids <- readLines("NC_002942.5_T4SE/candidate_genes_effector.txt", warn = FALSE)
background_ids <- readLines("NC_002942.5_T4SE/background_genes_all.txt", warn = FALSE)

candidate_ids <- unique(toupper(trimws(candidate_ids)))
candidate_ids <- candidate_ids[!is.na(candidate_ids) & candidate_ids != ""]
background_ids <- unique(toupper(trimws(background_ids)))
background_ids <- background_ids[!is.na(background_ids) & background_ids != ""]

clean_candidates <- unique(sub("([LPGRS0-9_]+).*", "\\1", candidate_ids))
clean_background <- unique(sub("([LPGRS0-9_]+).*", "\\1", background_ids))

cat("候选基因:", length(clean_candidates), "\n")
cat("背景基因:", length(clean_background), "\n\n")

# =============================================================================
# 方案A: KEGG 通路富集
# =============================================================================
cat("===== 方案A: KEGG 通路富集 =====\n")

# KEGG 使用 locus_tag 格式 (去掉 RS 中间的下划线或转换格式)
# KEGG Legionella pneumophila Phil-1 code: lpn
# KEGG gene IDs 可能是: lpgXXXX (LPG + 4位数字，无RS)

# 尝试转换: LPG_RS00005 → lpg0005
to_kegg_id <- function(locus_tag) {
  # LPG_RS00095 → lpg0095
  # 提取最后5位数字作为基因编号
  num_match <- regmatches(locus_tag, regexpr("[0-9]{5}$", locus_tag))
  if (length(num_match) > 0 && nchar(num_match) == 5) {
    num_int <- as.integer(num_match)
    return(sprintf("lpg%04d", num_int))
  }
  # 回退: 去掉所有非字母数字字符
  clean <- gsub("[^A-Za-z0-9]", "", locus_tag)
  tolower(clean)
}

kegg_candidates <- unique(sapply(clean_candidates, to_kegg_id))
kegg_background <- unique(sapply(clean_background, to_kegg_id))

cat("KEGG ID 示例:", head(kegg_candidates, 5), "\n")

# 尝试 KEGG 富集
kegg_result <- NULL
tryCatch({
  kegg_result <- enrichKEGG(
    gene     = kegg_candidates,
    universe = kegg_background,
    organism = "lpn",
    keyType  = "kegg",
    pAdjustMethod = "BH",
    pvalueCutoff  = 1,
    qvalueCutoff  = 1,
    minGSSize = 3,
    maxGSSize = 500
  )
  cat("KEGG 成功! 条目数:", nrow(as.data.frame(kegg_result)), "\n")
}, error = function(e) {
  cat("KEGG 失败:", e$message, "\n")
})

# =============================================================================
# 方案B: InterPro 蛋白结构域富集 (via QuickGO API)
# =============================================================================
cat("\n===== 方案B: InterPro 结构域富集 =====\n")

# 从 QuickGO 下载 InterPro annotations for Legionella
cat("下载 InterPro 注释...\n")
interpro_url <- "https://www.ebi.ac.uk/QuickGO/services/annotation/downloadSearch?taxonId=272624&taxonUsage=exact&limit=200"

ipr_gaf_file <- file.path(output_dir, "LEGPN_InterPro.gaf")
download_success <- tryCatch({
  system2("curl.exe", c("-s", "-o", shQuote(ipr_gaf_file),
       "-H", shQuote("Accept: text/gaf"),
       shQuote(interpro_url)), wait = TRUE)
  file.exists(ipr_gaf_file) && file.info(ipr_gaf_file)$size > 1000
}, error = function(e) FALSE)

# 如果不是首次下载（已有 QuickGO GAF），直接使用
ipr_file <- file.path(output_dir, "LEGPN_QuickGO.gaf")
if (!file.exists(ipr_file) || file.info(ipr_file)$size < 1000) {
  cat("需要重新下载...\n")
} else {
  cat("使用已有 QuickGO GAF\n")
}

# 读取 QuickGO GAF，提取 InterPro 条目
gaf_lines <- readLines(ipr_file, warn = FALSE)
data_lines <- gaf_lines[!grepl("^!", gaf_lines)]

# 解析 GAF
parse_gaf_simple <- function(lines) {
  parts_list <- strsplit(lines, "\t")
  data.frame(
    DB_Object_Symbol = sapply(parts_list, function(p) if(length(p)>=3) p[3] else NA),
    GO_ID            = sapply(parts_list, function(p) if(length(p)>=5) p[5] else NA),
    Aspect           = sapply(parts_list, function(p) if(length(p)>=9) p[9] else NA),
    Evidence_Code    = sapply(parts_list, function(p) if(length(p)>=7) p[7] else NA),
    Assigned_By      = sapply(parts_list, function(p) if(length(p)>=15) p[15] else NA),
    DB_Reference     = sapply(parts_list, function(p) if(length(p)>=6) p[6] else NA),
    stringsAsFactors = FALSE
  )
}

quickgo_df <- parse_gaf_simple(data_lines)
cat("QuickGO 总注释:", nrow(quickgo_df), "\n")

# 筛选 InterPro 注释 (Assigned_By = InterPro)
ipr_annotations <- quickgo_df[grepl("InterPro", quickgo_df$Assigned_By, ignore.case = TRUE), ]
cat("InterPro 注释:", nrow(ipr_annotations), "\n")

# 从 GO_ID 映射到 InterPro
# InterPro 注释的 GO_REF 列可能包含 InterPro ID
ipr_annotations$InterPro_ID <- sapply(strsplit(ipr_annotations$DB_Reference, ":"), function(p) {
  if (length(p) >= 2 && p[1] == "InterPro") p[2] else NA
})

cat("带 InterPro ID 的注释:", sum(!is.na(ipr_annotations$InterPro_ID)), "\n")

# 构建 InterPro term2gene
features <- read.csv("NC_002942.5_T4SE/features_.csv", stringsAsFactors = FALSE)
gene_to_locus <- setNames(features$locus_tag, toupper(features$gene))

ipr_annotations$locus_tag <- sapply(toupper(ipr_annotations$DB_Object_Symbol), function(sym) {
  if (is.na(sym) || sym == "") return(NA_character_)
  idx <- which(names(gene_to_locus) == sym)
  if (length(idx) == 0) return(NA_character_)
  gene_to_locus[idx[1]]
})

ipr_mapped <- ipr_annotations[!is.na(ipr_annotations$locus_tag) & !is.na(ipr_annotations$GO_ID), ]
cat("InterPro 映射到 locus_tag:", nrow(ipr_mapped), "\n")
cat("  唯一 locus_tag:", length(unique(ipr_mapped$locus_tag)), "\n")

# =============================================================================
# 方案C: eggNOG / COG 富集 (最全面)
# =============================================================================
cat("\n===== 方案C: COG 功能类别富集 =====\n")

# 从 eggNOG API 获取 Legionella 的 COG 注释
# eggNOG 6.0 REST API
cat("查询 eggNOG API...\n")

fetch_eggnog_page <- function(taxid, page) {
  url <- paste0("https://eggnog6.embl.de/api/v1/taxid/", taxid, "/members?page=", page, "&page_size=100")
  resp <- GET(url, timeout(30))
  if (status_code(resp) == 200) {
    fromJSON(rawToChar(resp$content))
  } else {
    NULL
  }
}

# 尝试获取 eggNOG 数据
eggnog_annotations <- list()
tryCatch({
  page <- 1
  while (TRUE) {
    data <- fetch_eggnog_page(272624, page)
    if (is.null(data) || length(data$results) == 0) break
    eggnog_annotations[[page]] <- data$results
    if (length(data$results) < 100) break
    page <- page + 1
  }
  cat("eggNOG API 成功! 页数:", length(eggnog_annotations), "\n")
}, error = function(e) {
  cat("eggNOG API 不可用:", e$message, "\n")
})

# 如果 eggNOG API 不可用，使用本地 COG 数据
if (length(eggnog_annotations) == 0) {
  cat("使用内置 COG 类别进行富集...\n")

  # NCBI COG 功能类别定义
  cog_categories <- list(
    "J" = "Translation, ribosomal structure and biogenesis",
    "A" = "RNA processing and modification",
    "K" = "Transcription",
    "L" = "Replication, recombination and repair",
    "B" = "Chromatin structure and dynamics",
    "D" = "Cell cycle control, cell division, chromosome partitioning",
    "Y" = "Nuclear structure",
    "V" = "Defense mechanisms",
    "T" = "Signal transduction mechanisms",
    "M" = "Cell wall/membrane/envelope biogenesis",
    "N" = "Cell motility",
    "Z" = "Cytoskeleton",
    "W" = "Extracellular structures",
    "U" = "Intracellular trafficking, secretion, and vesicular transport",
    "O" = "Posttranslational modification, protein turnover, chaperones",
    "X" = "Mobilome: prophages, transposons",
    "C" = "Energy production and conversion",
    "G" = "Carbohydrate transport and metabolism",
    "E" = "Amino acid transport and metabolism",
    "F" = "Nucleotide transport and metabolism",
    "H" = "Coenzyme transport and metabolism",
    "I" = "Lipid transport and metabolism",
    "P" = "Inorganic ion transport and metabolism",
    "Q" = "Secondary metabolites biosynthesis, transport and catabolism",
    "R" = "General function prediction only",
    "S" = "Function unknown"
  )

  # 从 UniProt/InterPro 注释推断 COG 类别
  # 使用 QuickGO 中的 GO 条目映射到 COG 类别
  # [简化方案: 直接使用 GO 注释中覆盖率最高的部分]

  # 从 features 文件提取注释信息
  cat("\n从 NCBI 注释中提取功能信息...\n")

  # NC_002942.5 features 的 annotation 列包含功能描述
  annotation_keywords <- list(
    "secretion"     = "T4SE/Secretion systems",
    "effector"      = "Effector proteins",
    "virulence"     = "Virulence-associated",
    "adhesion"      = "Adhesion",
    "biofilm"       = "Biofilm formation",
    "flagell"       = "Flagellar/Motility",
    "chemotaxis"    = "Chemotaxis",
    "pilus"         = "Pilus/Fimbria",
    "toxin"         = "Toxin",
    "invasion"      = "Invasion",
    "phagocytos"    = "Phagocytosis",
    "type I"        = "Type I secretion",
    "type II"       = "Type II secretion",
    "type III"      = "Type III secretion",
    "type IV"       = "Type IV secretion",
    "type VI"       = "Type VI secretion",
    "T4SS"          = "Type IV secretion system",
    "Dot/Icm"       = "Dot/Icm T4SS",
    "conjugal"      = "Conjugal transfer",
    "conjugat"      = "Conjugation",
    "transport"     = "Transport",
    "membrane"      = "Membrane protein",
    "outer membrane" = "Outer membrane",
    "inner membrane" = "Inner membrane",
    "periplasm"     = "Periplasmic",
    "kinase"        = "Kinase",
    "phosphatas"    = "Phosphatase",
    "protease"      = "Protease/Peptidase",
    "peptidase"     = "Protease/Peptidase",
    "glycosyl"      = "Glycosyltransferase",
    "hydrolase"     = "Hydrolase",
    "transferase"   = "Transferase",
    "lipase"        = "Lipase/Esterase",
    "nuclease"      = "Nuclease",
    "helicase"      = "Helicase",
    "ATPase"        = "ATPase",
    "chaperone"     = "Chaperone",
    "stress"        = "Stress response",
    "oxidative"     = "Oxidative stress",
    "DNA"           = "DNA metabolism",
    "RNA"           = "RNA metabolism",
    "ribosom"       = "Ribosomal",
    "tRNA"          = "tRNA",
    "modification"  = "Post-translational modification",
    "methyl"        = "Methyltransferase",
    "acetyl"        = "Acetyltransferase",
    "sensor"        = "Sensor/Regulator",
    "regulat"       = "Regulatory protein",
    "transcript"    = "Transcriptional regulator",
    "two-component" = "Two-component system",
    "ABC"           = "ABC transporter",
    "MFS"           = "MFS transporter",
    "channel"       = "Channel/Porin",
    "porin"         = "Porin",
    "lipoprotein"   = "Lipoprotein",
    "peptidoglycan" = "Peptidoglycan metabolism",
    "cell wall"     = "Cell wall biogenesis",
    "antitoxin"     = "Antitoxin/Toxin-antitoxin",
    "CRISPR"        = "CRISPR/Cas system",
    "phage"         = "Phage-related",
    "transpos"      = "Transposase/Mobile element",
    "integrase"     = "Integrase/Recombinase",
    "hypothetical"  = "Hypothetical/Uncharacterized"
  )

  # 为每个候选基因标注功能类别
  features$annotation_lower <- tolower(features$annotation)

  classify_gene <- function(annot) {
    if (is.na(annot) || annot == "") return(NA_character_)
    annot_lower <- tolower(annot)
    hits <- character()
    for (kw in names(annotation_keywords)) {
      if (grepl(kw, annot_lower, fixed = TRUE)) {
        hits <- c(hits, annotation_keywords[[kw]])
      }
    }
    if (length(hits) == 0) return(NA_character_)
    paste(unique(hits), collapse = "; ")
  }

  features$FuncCategory <- sapply(features$annotation, classify_gene)

  # 构建 term2gene 用于 clusterProfiler
  term2gene_list <- list()
  for (i in seq_len(nrow(features))) {
    lt <- features$locus_tag[i]
    cat_str <- features$FuncCategory[i]
    if (!is.na(cat_str) && cat_str != "") {
      cats <- strsplit(cat_str, "; ")[[1]]
      for (cc in cats) {
        term2gene_list[[length(term2gene_list) + 1]] <- data.frame(
          term = cc,
          gene = lt,
          stringsAsFactors = FALSE
        )
      }
    }
  }

  term2gene_func <- do.call(rbind, term2gene_list)
  term2gene_func <- unique(term2gene_func)

  cat("功能分类 term2gene:", nrow(term2gene_func), "\n")
  cat("  唯一类别:", length(unique(term2gene_func$term)), "\n")
  cat("  唯一基因:", length(unique(term2gene_func$gene)), "\n")

  # 候选基因的功能类别覆盖
  candidate_cats <- term2gene_func[term2gene_func$gene %in% clean_candidates, ]
  cat("  候选基因有分类的:", length(unique(candidate_cats$gene)), "/", length(clean_candidates), "\n")

  # 类别分布
  cat("\n功能类别分布 (候选基因):\n")
  cat_counts <- sort(table(candidate_cats$term), decreasing = TRUE)
  for (i in seq_len(min(20, length(cat_counts)))) {
    cat(sprintf("  %-40s %d\n", names(cat_counts)[i], cat_counts[i]))
  }

  # 使用 clusterProfiler::enricher 做富集
  term2name_func <- unique(term2gene_func[, "term", drop = FALSE])
  term2name_func$name <- term2name_func$term

  func_result <- clusterProfiler::enricher(
    gene          = clean_candidates,
    universe      = clean_background,
    TERM2GENE     = term2gene_func,
    TERM2NAME     = term2name_func,
    pAdjustMethod = "BH",
    pvalueCutoff  = 1,
    qvalueCutoff  = 1,
    minGSSize     = 3,
    maxGSSize     = 500
  )

  func_table <- as.data.frame(func_result)
  func_table <- func_table[order(func_table$p.adjust, func_table$pvalue), ]

  cat("\n===== 功能富集结果 =====\n")
  cat("总条目:", nrow(func_table), "\n")

  # 筛选显著
  func_sig <- func_table[
    !is.na(func_table$p.adjust) & func_table$p.adjust < 0.05 &
    !is.na(func_table$qvalue) & func_table$qvalue < 0.20, , drop = FALSE
  ]
  cat("显著条目:", nrow(func_sig), "\n")

  # 添加 Fold Enrichment
  if (nrow(func_table) > 0) {
    parse_ratio <- function(x) {
      vapply(strsplit(as.character(x), "/", fixed = TRUE),
             function(p) as.numeric(p[1])/as.numeric(p[2]), numeric(1))
    }
    func_table$GeneRatio_num <- parse_ratio(func_table$GeneRatio)
    func_table$BgRatio_num <- parse_ratio(func_table$BgRatio)
    func_table$FoldEnrichment <- func_table$GeneRatio_num / func_table$BgRatio_num

    write.csv(func_table, file.path(output_dir, "FuncCategory_all_results.csv"), row.names = FALSE)

    if (nrow(func_sig) > 0) {
      func_sig$GeneRatio_num <- parse_ratio(func_sig$GeneRatio)
      func_sig$BgRatio_num <- parse_ratio(func_sig$BgRatio)
      func_sig$FoldEnrichment <- func_sig$GeneRatio_num / func_sig$BgRatio_num
      write.csv(func_sig, file.path(output_dir, "FuncCategory_significant.csv"), row.names = FALSE)
    }

    # 显示 Top 20
    result_cols <- c("ID", "Description", "GeneRatio", "BgRatio", "FoldEnrichment", "pvalue", "p.adjust", "qvalue", "Count")
    show_cols <- intersect(result_cols, colnames(func_table))
    cat("\nTop 20 功能富集:\n")
    print(head(func_table[, show_cols, drop = FALSE], 20))

    # 气泡图
    plot_data <- head(func_table, 20)
    plot_data$NegLog10FDR <- -log10(pmax(plot_data$p.adjust, .Machine$double.xmin))
    plot_data$ID <- factor(plot_data$ID, levels = rev(plot_data$ID))

    p <- ggplot(plot_data, aes(FoldEnrichment, ID)) +
      geom_vline(xintercept = 1, linewidth = 0.3, linetype = "dashed", colour = "grey60") +
      geom_point(aes(size = Count, fill = NegLog10FDR), shape = 21, colour = "grey20", stroke = 0.3) +
      scale_size_continuous(name = "Genes", range = c(2, 8)) +
      scale_fill_viridis_c(name = expression(-log[10](FDR)), option = "C", direction = 1) +
      labs(x = "Fold enrichment", y = NULL, title = "NC_002942.5 Functional Category Enrichment") +
      theme_classic(base_size = 10) +
      theme(
        axis.text.y = element_text(size = 8, colour = "black"),
        plot.title = element_text(size = 11, face = "bold")
      )

    ggsave(file.path(output_dir, "NC_002942.5_func_enrichment.pdf"), p, width = 10, height = 8, device = "pdf")
    ggsave(file.path(output_dir, "NC_002942.5_func_enrichment.png"), p, width = 10, height = 8, dpi = 300)

    cat("\n图表保存到:", output_dir, "\n")
  }
}

cat("\n===== 分析完成 =====\n")
