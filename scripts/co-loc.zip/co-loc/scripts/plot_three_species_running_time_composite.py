"""Three-panel cumulative inference-time figure built from raw timing tables."""

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import pandas as pd


DATA_DIR = Path("running_time_figure")
OUTPUT_DIR = DATA_DIR / "three_species_composite"
OUTPUT_STEM = OUTPUT_DIR / "three_species_running_time_composite"
TIME_COLUMN = "prediction_time_ms"

# Edit file paths, checkpoints, titles, and axis limits here when needed.
PANELS = [
    {
        "letter": "A",
        "species": "Pseudomonas aeruginosa PAO1",
        "title": "Pseudomonas aeruginosa PAO1",
        "input": DATA_DIR / "PAO1_predictions_time.csv",
        "checkpoints": [1000, 2000, 3000, 4000, 5000, 5571],
        "xlim": (0, 6200),
        "xticks": [100, 1000, 2000, 3000, 4000, 5000, 6000],
        "ylim": (0, 40),
        "yticks": [0, 10, 20, 30, 40],
    },
    {
        "letter": "B",
        "species": "Salmonella enterica subsp. enterica serovar Typhimurium str. LT2",
        "title": "Salmonella enterica subsp. enterica\nserovar Typhimurium str. LT2",
        "input": DATA_DIR / "Salmonella_predictions_time.csv",
        "checkpoints": [100, 500, 1000, 2000, 2972],
        "xlim": (0, 3075),
        "xticks": [100, 500, 1000, 2000, 3000],
        "ylim": (0, 10),
        "yticks": [0, 2.5, 5.0, 7.5, 10.0],
    },
    {
        "letter": "C",
        "species": "Legionella pneumophila subsp. pneumophila str. Philadelphia 1",
        "title": "Legionella pneumophila subsp.\npneumophila str. Philadelphia 1",
        "input": DATA_DIR / "Legionella _predictions_time.csv",
        "checkpoints": [100, 500, 1000, 2000, 3000],
        "xlim": (0, 3075),
        "xticks": [100, 500, 1000, 2000, 3000],
        "ylim": (0, 10),
        "yticks": [0, 2.5, 5.0, 7.5, 10.0],
    },
]


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial"],
        "font.weight": "normal",
        "axes.labelweight": "normal",
        "axes.titleweight": "normal",
        "axes.linewidth": 0.75,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.major.width": 0.75,
        "ytick.major.width": 0.75,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def cumulative_at_checkpoints(panel: dict) -> pd.DataFrame:
    raw = pd.read_csv(panel["input"])
    if TIME_COLUMN not in raw.columns:
        raise KeyError(f"{panel['input']}: missing {TIME_COLUMN}")
    times = pd.to_numeric(raw[TIME_COLUMN], errors="coerce")
    if times.isna().any() or (times < 0).any():
        raise ValueError(f"{panel['input']}: invalid inference times")
    cumulative_s = times.cumsum().to_numpy() / 1000.0
    checkpoints = [n for n in panel["checkpoints"] if 0 < n <= len(raw)]
    result = pd.DataFrame(
        {
            "Species": panel["species"],
            "Protein count": checkpoints,
            "Running time (s)": [cumulative_s[n - 1] for n in checkpoints],
        }
    )
    return result


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    source_frames = [cumulative_at_checkpoints(panel) for panel in PANELS]
    pd.concat(source_frames, ignore_index=True).to_csv(
        OUTPUT_DIR / "Source_Data_three_species_running_time.csv", index=False
    )

    fig, axes = plt.subplots(1, 3, figsize=(183 / 25.4, 63 / 25.4))
    orange = "#D86B16"
    pale_orange = "#F3D8C3"

    for ax, panel, data in zip(axes, PANELS, source_frames):
        ax.plot(
            data["Protein count"],
            data["Running time (s)"],
            color=pale_orange,
            linewidth=1.8,
            zorder=1,
        )
        ax.scatter(
            data["Protein count"],
            data["Running time (s)"],
            s=28,
            facecolor=orange,
            edgecolor="#F5C69F",
            linewidth=0.9,
            zorder=2,
        )
        ax.set_xlim(*panel["xlim"])
        ax.set_ylim(*panel["ylim"])
        ax.set_xticks(panel["xticks"])
        ax.set_yticks(panel["yticks"])
        ax.yaxis.set_major_formatter(FormatStrFormatter("%.1f"))
        ax.set_xlabel("Protein count", fontsize=8, labelpad=5)
        ax.set_ylabel("Running time (s)", fontsize=8, labelpad=5)
        ax.set_title(
            panel["title"],
            fontsize=8.4,
            fontstyle="italic",
            fontweight="normal",
            pad=10,
            linespacing=1.15,
        )
        ax.tick_params(axis="both", labelsize=6.2, colors="#333333", pad=2)
        ax.spines["left"].set_color("#333333")
        ax.spines["bottom"].set_color("#333333")
        ax.text(
            -0.28,
            1.22,
            panel["letter"],
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=9,
            fontweight="normal",
            fontstyle="normal",
        )

    # Compact gaps while retaining enough room for each y-axis title.
    fig.subplots_adjust(left=0.065, right=0.99, bottom=0.20, top=0.79, wspace=0.48)

    fig.savefig(OUTPUT_STEM.with_suffix(".png"), dpi=600, facecolor="white")
    fig.savefig(OUTPUT_STEM.with_suffix(".svg"), facecolor="white")
    fig.savefig(OUTPUT_STEM.with_suffix(".pdf"), facecolor="white")
    fig.savefig(
        OUTPUT_STEM.with_suffix(".tiff"),
        dpi=600,
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


if __name__ == "__main__":
    main()
